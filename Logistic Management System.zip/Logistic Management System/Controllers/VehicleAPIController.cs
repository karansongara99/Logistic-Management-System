﻿using Logistic_Management_System.Interfaces.Vehicle.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Logistic_Management_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VehicleAPIController : ControllerBase
    {
        private readonly IVehicleService _vehicleService;
        public VehicleAPIController(IVehicleService vehicleService)
        {
            this._vehicleService = vehicleService;
        }
        [HttpGet("List")]
        public async Task<IActionResult> GetAllVehicles()
        {
            return Ok(await _vehicleService.GetAllVehicles());
        }

        [HttpPost("Create")]
        public async Task<IActionResult> CreateVehicle([FromBody] Models.MstVehicle mstVehicle)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            await _vehicleService.CreateVehicle(mstVehicle);
            return CreatedAtAction(nameof(CreateVehicle), new { id = mstVehicle.VehicleId }, mstVehicle);
        }



        [HttpGet("TopTens")]
        public async Task<IActionResult> TopTens()
        {
            return Ok(await _vehicleService.TopTens());
        }

        [HttpGet("TotalCount")]
        public async Task<IActionResult> TotalCounts()
        {
            return Ok(await _vehicleService.GetTotalVehicleCount());
        }

        [HttpGet("VehicleSearch")]
        public async Task<IActionResult> SearchVehicles(string? name, string? type, string? vnumber)
        {
            return Ok(await _vehicleService.SearchVehicles(name, type, vnumber));

        }

        [HttpDelete("Delete/{id}")]
        public async Task<IActionResult> DeleteShipment(int id)
        {
            try
            {
                var result = await _vehicleService.DeleteVehicle(id);
                if (result)
                {
                    return NoContent();
                }
                else
                {
                    return NotFound(new { message = "Shipment not found or unauthorized." });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while deleting the Vehicle.", detail = ex.Message });
            }
        }

        [HttpDelete("DeleteAll")]
        public async Task<IActionResult> DeleteAllVehicles()
        {
            try
            {
                var result = await _vehicleService.DeleteAllVehicle();
                if (result)
                {
                    return NoContent();
                }
                else
                {
                    return NotFound(new { message = "No vehicles found to delete." });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while deleting all vehicles.", detail = ex.Message });
            }
        }

        [HttpGet("GetById/{id}")]
        public async Task<IActionResult> GetVehicleById(int id)
        {
            var vehicle = await _vehicleService.GetVehicleById(id);
            if (vehicle == null)
            {
                return NotFound(new { message = "Vehicle not found." });
            }
            return Ok(vehicle);
        }

        [HttpPut("Update/{id}")]
        public async Task<IActionResult> UpdateVehicle(int id, [FromBody] Models.MstVehicle mstVehicle)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            var updatedVehicle = await _vehicleService.UpdateVehicle(id, mstVehicle);
            if (updatedVehicle == null)
            {
                return NotFound(new { message = "Vehicle not found or unauthorized." });
            }
            return Ok(updatedVehicle);
        }
    }
}
