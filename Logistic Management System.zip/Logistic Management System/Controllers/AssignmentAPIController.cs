﻿using Logistic_Management_System.Interfaces.Assignment.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Logistic_Management_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AssignmentAPIController : ControllerBase
    {
        private IAssignmentService _assignmentService;

        public AssignmentAPIController(IAssignmentService assignmentService)
        {
            this._assignmentService = assignmentService;
        }

        [HttpGet("List")]
        public async Task<IActionResult> GetAllAssignments()
        {
            return Ok(await _assignmentService.GetAllAssignments());
        }

        [HttpGet("TopTens")]
        public async Task<IActionResult> TopTens()
        {
            return Ok(await _assignmentService.TopTens());
        }

        [HttpGet("TotalCount")]
        public async Task<IActionResult> GetTotalAssignmentCount()
        {
            return Ok(await _assignmentService.GetTotalAssignmentCount());
        }
        [HttpPost("Create")]
        public async Task<IActionResult> CreateAssignment([FromBody] Models.MstAssignment mstAssignment)
        {
            if (mstAssignment == null)
            {
                return BadRequest("Invalid assignment data.");
            }
            var createdAssignment = await _assignmentService.CreateAssignment(mstAssignment);
            return CreatedAtAction(nameof(GetAllAssignments), new { id = createdAssignment.AssignmentId }, createdAssignment);
        }
        [HttpDelete("Delete/{id}")]
        public async Task<IActionResult> DeleteAssignment(int id)
        {
            var result = await _assignmentService.DeleteAssignment(id);
            if (result)
            {
                return NoContent();
            }
            return NotFound("Assignment not found or you do not have permission to delete it.");
        }
        [HttpDelete("DeleteAll")]
        public async Task<IActionResult> DeleteAllAssignments()
        {
            var result = await _assignmentService.DeleteAllAssignment();
            if (result)
            {
                return NoContent();
            }
            return NotFound("No assignments found or you do not have permission to delete them.");
        }
        [HttpGet("GetById/{id}")]
        public async Task<IActionResult> GetAssignmentById(int id)
        {
            var assignment = await _assignmentService.GetAssignmentById(id);
            if (assignment == null)
            {
                return NotFound("Assignment not found.");
            }
            return Ok(assignment);
        }
        [HttpPut("Update/{id}")]
        public async Task<IActionResult> UpdateAssignment(int id, [FromBody] Models.MstAssignment mstAssignment)
        {
            if (mstAssignment == null)
            {
                return BadRequest("Invalid assignment data.");
            }
            var updatedAssignment = await _assignmentService.UpdateAssignment(id, mstAssignment);
            if (updatedAssignment == null)
            {
                return NotFound("Assignment not found or you do not have permission to update it.");
            }
            return Ok(updatedAssignment);
        }

        [HttpGet("AssignmentSearch")]
        public async Task<IActionResult> SearchAssignment([FromQuery] string vehiclename)
        {
            if (string.IsNullOrEmpty(vehiclename))
            {
                return BadRequest("Vehicle name cannot be empty.");
            }
            var assignments = await _assignmentService.SearchAssignment(vehiclename);
            if (assignments == null || !assignments.Any())
            {
                return NotFound("No assignments found for the given vehicle name.");
            }
            return Ok(assignments);
        }
    }
}
