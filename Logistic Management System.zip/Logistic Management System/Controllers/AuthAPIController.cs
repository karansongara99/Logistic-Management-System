﻿using Logistic_Management_System.Interfaces.Admin.Services;
using Logistic_Management_System.Models.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Logistic_Management_System.Controllers
{
    [AllowAnonymous]
    [Route("api/[controller]")]
    [ApiController]
    public class AuthAPIController : ControllerBase
    {
        private readonly IAdminService adminService;

        public AuthAPIController(IAdminService adminService)
        {
            this.adminService = adminService;
        }

        [HttpPost("Login")]
        public async Task<IActionResult> Login(AdminAuthDto adminAuthDto)
        {
            var JWTToken = await adminService.GetJWTToken(adminAuthDto);

            if (JWTToken is not null)
            {
                return Ok(JWTToken);
            }

            return Unauthorized();
        }

        [HttpPost("Register")]
        public async Task<IActionResult> Register(AdminRegisterDto adminRegisterDto)
        {
            var result = await adminService.RegisterAdminUser(adminRegisterDto);

            if (result)
            {
                return Created("api/AuthAPI/Register", new { message = "Admin registered successfully" });
            }

            return BadRequest("EmailId is already registered in website. Please choose another email for registration.");
        }
    }
}
