﻿using Logistic_Management_System.Interfaces.Package.Services;
using Logistic_Management_System.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Logistic_Management_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PackageAPIController : ControllerBase
    {
        private readonly IPackageService _packageService;
        public PackageAPIController(IPackageService packageService)
        {
            this._packageService = packageService;
        }

        [HttpGet("List")]
        public async Task<IActionResult> GetAllPackages()
        {
            return Ok(await _packageService.GetAllPackages());
        }

        [HttpGet("TopTens")]
        public async Task<IActionResult> GetTopTens()
        {
            return Ok(await _packageService.TopTens());
        }

        [HttpGet("TotalCount")]
        public async Task<IActionResult> GetTotalPackageCount()
        {
            return Ok(await _packageService.GetTotalPackageCount());
        }

        [HttpGet("PackageSearch")]
        public async Task<IActionResult> SearchPackages(string? shipcode, string? description)
        {
            return Ok(await _packageService.SearchPackages(shipcode, description));
        }

        [HttpPost("Create")]
        public async Task<IActionResult> CreatePackage([FromBody] Models.MstPackage mstPackage)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            await _packageService.CreatePackage(mstPackage);
            return CreatedAtAction(nameof(CreatePackage), new { id = mstPackage.PackageId }, mstPackage);
        }

        [HttpDelete("Delete/{id}")]
        public async Task<IActionResult> DeletePackage(int id)
        {
            try
            {
                var result = await _packageService.DeletePackage(id);
                if (result)
                {
                    return NoContent();
                }
                else
                {
                    return NotFound(new { message = "Shipment not found or unauthorized." });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while deleting the package.", detail = ex.Message });
            }
        }

        [HttpDelete("DeleteAll")]
        public async Task<IActionResult> DeleteAllPackages()
        {
            try
            {
                var result = await _packageService.DeleteAllPackages();
                if (result)
                {
                    return NoContent();
                }
                else
                {
                    return NotFound(new { message = "No packages found or unauthorized." });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while deleting all packages.", detail = ex.Message });
            }
        }

        [HttpPut("Update/{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] MstPackage mstPackage)
        {
            if (mstPackage == null || id <= 0)
                return BadRequest(new { message = "Invalid package data." });

            var updated = await _packageService.UpdatePackage(id, mstPackage);
            if (updated == null)
                return NotFound(new { message = "Package not found." });

            return Ok(updated);
        }


        [HttpGet("GetById/{id}")]
        public async Task<IActionResult> GetPackageById(int id)
        {
            try
            {
                var package = await _packageService.GetPackageById(id);
                if (package == null)
                {
                    return NotFound(new { message = "Package not found." });
                }
                return Ok(package);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while retrieving the package.", detail = ex.Message });
            }
        }
    }
}
