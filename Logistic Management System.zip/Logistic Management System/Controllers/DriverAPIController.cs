﻿using Logistic_Management_System.Interfaces.Driver.Repositories;
using Logistic_Management_System.Interfaces.Driver.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Logistic_Management_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DriverAPIController : ControllerBase
    {
        private readonly IDriverService _driverService;
        public DriverAPIController(IDriverService driverService)
        {
            _driverService = driverService;
        }

        [HttpGet("List")]
        public async Task<IActionResult> GetAllDrivers()
        {
            return Ok(await _driverService.GetAllDrivers());

        }

        [HttpGet("TopTens")]
        public async Task<IActionResult> TopTens()
        {
            return Ok(await _driverService.TopTens());
        }

        [HttpGet("TotalCount")]
        public async Task<IActionResult> GetTotalDriverCount()
        {
            return Ok(await _driverService.GetTotalDriverCount());
        }

        [HttpPost("Create")]
        public async Task<IActionResult> CreateDriver([FromBody] Models.MstDriver mstDriver)
        {
            if (mstDriver == null)
            {
                return BadRequest("Driver data is null.");
            }
            var createdDriver = await _driverService.CreateDriver(mstDriver);
            return CreatedAtAction(nameof(GetAllDrivers), new { id = createdDriver.DriverId }, createdDriver);
        }

        [HttpGet("DriverSearch")]
        public async Task<IActionResult> SearchDrivers(string? name, string? contactno, string? address)
        {
            return Ok(await _driverService.SearchDrivers(name, contactno, address));
        }

        [HttpDelete("Delete/{id}")]
        public async Task<IActionResult> DeleteDriver(int id)
        {
            try
            {
                var result = await _driverService.DeleteDriver(id);
                if (result)
                {
                    return NoContent();
                }
                else
                {
                    return NotFound(new { message = "Shipment not found or unauthorized." });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while deleting the Driver.", detail = ex.Message });
            }
        }

        [HttpDelete("DeleteAll")]
        public async Task<IActionResult> DeleteAllDrivers()
        {
            try
            {
                var result = await _driverService.DeleteAllDrivers();
                if (result)
                {
                    return NoContent();
                }
                else
                {
                    return NotFound(new { message = "No drivers found to delete." });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while deleting all drivers.", detail = ex.Message });
            }
        }

        [HttpGet("GetById/{id}")]
        public async Task<IActionResult> GetDriverById(int id)
        {
            var driver = await _driverService.GetDriverById(id);
            if (driver == null)
            {
                return NotFound(new { message = "Driver not found." });
            }
            return Ok(driver);
        }
        [HttpPut("Update/{id}")]
        public async Task<IActionResult> UpdateDriver(int id, [FromBody] Models.MstDriver mstDriver)
        {
            if (mstDriver == null)
            {
                return BadRequest("Driver data is null.");
            }
            var result = await _driverService.UpdateDriver(id, mstDriver);
            if (result)
            {
                return NoContent();
            }
            else
            {
                return NotFound(new { message = "Driver not found or unauthorized." });
            }
        }
    }
}
