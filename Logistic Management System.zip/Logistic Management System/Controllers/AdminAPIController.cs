﻿using Logistic_Management_System.Interfaces.Admin.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Logistic_Management_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminAPIController : ControllerBase
    {
        private readonly IAdminService _adminService;

        public AdminAPIController(IAdminService adminService)
        {
            this._adminService = adminService;
        }

        [HttpGet("Profile")]
        public async Task<IActionResult> GetAdminProfile()
        {
            var adminProfile = await _adminService.GetAdminProfile();
            if (adminProfile is not null)
            {
                return Ok(adminProfile);
            }

            return NotFound("Admin profile not found.");
        }
    }
}
