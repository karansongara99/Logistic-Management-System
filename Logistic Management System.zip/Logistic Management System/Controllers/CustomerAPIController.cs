﻿using Logistic_Management_System.Interfaces.Customer.Services;
using Logistic_Management_System.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Logistic_Management_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerAPIController : ControllerBase
    {
        private readonly ICustomerService _customerService;

        public CustomerAPIController(ICustomerService customerService)
        {
            this._customerService = customerService;
        }

        [HttpGet("List")]
        public async Task<IActionResult> GetAllCustomers()
        {
            return Ok(await _customerService.GetAllCustomers());
        }

        [HttpGet("TopTens")]
        public async Task<IActionResult> TopTens()
        {
            return Ok(await _customerService.TopTens());
        }

        [HttpGet("TotalCount")]
        public async Task<IActionResult> GetTotalCustomerCount()
        {
            return Ok(await _customerService.GetTotalCustomerCount());
        }

        [HttpGet("CustomerSearch")]
        public async Task<IActionResult> SearchCustomers([FromQuery] string? name, [FromQuery] string? contactNo)
        {
            var result = await _customerService.SearchCustomers(name, contactNo);
            return Ok(result);
        }

        [HttpGet("Pagination/{pageNumber}/{pageSize}")]
        public async Task<IActionResult> GetCustomersPaginated(int pageNumber = 1, int pageSize = 10)
        {
            var (customers, totalCount) = await _customerService.GetCustomersPagination(pageNumber, pageSize);

            int totalPages = (int)Math.Ceiling((double)totalCount / pageSize);

            var response = new
            {
                PageNumber = pageNumber,
                PageSize = pageSize,
                TotalRecords = totalCount,
                TotalPages = totalPages,
                Data = customers
            };

            return Ok(response);
        }

        // Soft Delete
        [HttpPatch("Soft-Delete/{id}")]
        public async Task<IActionResult> SoftDeleteCustomer(int id)
        {
            var result = await _customerService.SoftDeleteCustomer(id);
            if (!result)
                return NotFound(new { Message = "Customer not found or already deleted." });

            return Ok(new { Message = "Customer soft-deleted successfully." });
        }

        // Hard Delete
        [HttpDelete("Hard-Delete/{id}")]
        public async Task<IActionResult> HardDeleteCustomer(int id)
        {
            var result = await _customerService.HardDeleteCustomer(id);
            if (!result)
                return NotFound(new { Message = "Customer not found." });

            return Ok(new { Message = "Customer hard-deleted successfully." });
        }

        [HttpDelete("DeleteAll")]
        public async Task<IActionResult> DeleteAllCustomers()
        {
            try
            {
                var result = await _customerService.DeleteAllCustomers();
                if (result)
                {
                    return NoContent();
                }
                else
                {
                    return NotFound(new { message = "No Customers found or unauthorized." });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while deleting all Customers.", detail = ex.Message });
            }
        }

        [HttpPost("Create")]
        public async Task<IActionResult> CreateCustomer([FromBody] MstCustomer mstCustomer)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            await _customerService.CreateCustomer(mstCustomer);
            return CreatedAtAction(nameof(CreateCustomer), new { id = mstCustomer.CustomerId }, mstCustomer);
        }

        [HttpGet("GetById/{id}")]
        public async Task<IActionResult> GetCustomerById(int id)
        {
            var customer = await _customerService.GetCustomerById(id);
            if (customer == null)
            {
                return NotFound(new { message = "Customer not found." });
            }
            return Ok(customer);
        }

        [HttpPut("Update/{id}")]
        public async Task<IActionResult> UpdateCustomer(int id, [FromBody] MstCustomer mstCustomer)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            try
            {
                var updatedCustomer = await _customerService.UpdateCustomer(id, mstCustomer);
                return Ok(updatedCustomer);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while updating the Customer.", detail = ex.Message });
            }
        }
    }
}