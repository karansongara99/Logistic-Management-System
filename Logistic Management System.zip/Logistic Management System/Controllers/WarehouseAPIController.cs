﻿using Logistic_Management_System.Interfaces.Warehouse.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Logistic_Management_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class WarehouseAPIController : ControllerBase
    {
        private readonly IWarehouseService _warehouseService;
        public WarehouseAPIController(IWarehouseService warehouseService)
        {
            this._warehouseService = warehouseService;
        }

        [HttpGet("List")]
        public async Task<IActionResult> GetAllWarehoues()
        {
            return Ok(await _warehouseService.GetAllWarehouses());
        }

        [HttpGet("TopTens")]
        public async Task<IActionResult> GetTopTens()
        {
            return Ok(await _warehouseService.TopTens());
        }

        [HttpPost("Create")]
        public async Task<IActionResult> CreateWarehouse([FromBody] Models.MstWarehouse mstWarehouse)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            await _warehouseService.CreateWarehouse(mstWarehouse);
            return CreatedAtAction(nameof(CreateWarehouse), new { id = mstWarehouse.WarehouseId }, mstWarehouse);
        }

        [HttpGet("TotalCount")]
        public async Task<IActionResult> GetTotalWarehouseCount()
        {
            return Ok(await _warehouseService.GetTotalWarehouseCount());
        }

        [HttpGet("WarehouseSearch")]
        public async Task<IActionResult> SearchWarehouses(string? name, string? conatactno, string? managername, string? address)
        {
            return Ok(await _warehouseService.SearchWarehouses(name, conatactno, managername, address));
        }

        [HttpDelete("Delete/{id}")]
        public async Task<IActionResult> DeleteWarehouse(int id)
        {
            try
            {
                var result = await _warehouseService.DeleteWarehouse(id);
                if (result)
                {
                    return NoContent();
                }
                else
                {
                    return NotFound(new { message = "Shipment not found or unauthorized." });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while deleting the Warehouse.", detail = ex.Message });
            }
        }

        [HttpDelete("DeleteAll")]
        public async Task<IActionResult> DeleteAllWarehouse()
        {
            try
            {
                var result = await _warehouseService.DeleteAllWarehouse();
                if (result)
                {
                    return NoContent();
                }
                else
                {
                    return NotFound(new { message = "No Warehouses found or unauthorized." });
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception deleting warehouses: " + ex.Message);

                return StatusCode(500, new
                {
                    message = "An error occurred while deleting all Warehouses.",
                    detail = ex.Message
                });
            }
        }

        [HttpPut("Update/{id}")]
        public async Task<IActionResult> UpdateWarehouse(int id, [FromBody] Models.MstWarehouse mstWarehouse)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            try
            {
                var updatedWarehouse = await _warehouseService.UpdateWarehouse(id, mstWarehouse);
                if (updatedWarehouse == null)
                {
                    return NotFound(new { message = "Warehouse not found or unauthorized." });
                }
                return Ok(updatedWarehouse);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while updating the Warehouse.", detail = ex.Message });
            }
        }

        [HttpGet("GetById/{id}")]
        public async Task<IActionResult> GetWarehouseById(int id)
        {
            try
            {
                var warehouse = await _warehouseService.GetWarehouseById(id);
                if (warehouse == null)
                {
                    return NotFound(new { message = "Warehouse not found." });
                }
                return Ok(warehouse);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while retrieving the Warehouse.", detail = ex.Message });
            }
        }
    }
}