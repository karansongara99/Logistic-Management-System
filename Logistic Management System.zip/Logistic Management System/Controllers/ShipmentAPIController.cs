﻿using Logistic_Management_System.Interfaces.Shipment.Services;
using Logistic_Management_System.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Logistic_Management_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ShipmentAPIController : ControllerBase
    {
        private readonly IShipmentService _shipmentService;

        public ShipmentAPIController(IShipmentService shipmentService)
        {
            this._shipmentService = shipmentService;
        }

        [HttpPost("Create")]
        public async Task<IActionResult> CreateShipment([FromBody] MstShipment mstShipment)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            await _shipmentService.CreateShipment(mstShipment);
            return CreatedAtAction(nameof(CreateShipment), new { id = mstShipment.ShipmentId }, mstShipment);
        }

        [HttpDelete("DeleteAll")]
        public async Task<IActionResult> DeleteAllPackages()
        {
            try
            {
                var result = await _shipmentService.DeleteAllShipments();
                if (result)
                {
                    return NoContent();
                }
                else
                {
                    return NotFound(new { message = "No Shipments found or unauthorized." });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while deleting all Shipments.", detail = ex.Message });
            }
        }

        [HttpGet("List")]
        public async Task<IActionResult> GetAllShipments()
        {
            return Ok(await _shipmentService.GetAllShipments());
        }

        [HttpGet("TopTens")]
        public async Task<IActionResult> TopTens()
        {
            return Ok(await _shipmentService.TopTens());
        }

        [HttpGet("TotalCount")]
        public async Task<IActionResult> GetTotalShipmentCount()
        {
            return Ok(await _shipmentService.GetTotalShipmentCount());
        }

        [HttpGet("ShipmentsSearch")]
        public async Task<IActionResult> SearchShipments([FromQuery] string? shipcode, [FromQuery] string? customername)
        {
            var result = await _shipmentService.SearchShipments(shipcode, customername);
            return Ok(result);
        }

        [HttpDelete("Delete/{id}")]
        public async Task<IActionResult> DeleteShipment(int id)
        {
            try
            {
                var result = await _shipmentService.DeleteShipment(id);
                if (result)
                {
                    return NoContent();
                }
                else
                {
                    return NotFound(new { message = "Shipment not found or unauthorized." });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while deleting the shipment.", detail = ex.Message });
            }
        }

        [HttpGet("GetById/{id}")]
        public async Task<IActionResult> GetShipmentById(int id)
        {
            var shipment = await _shipmentService.GetShipmentById(id);
            if (shipment == null)
            {
                return NotFound(new { message = "Shipment not found." });
            }
            return Ok(shipment);
        }

        [HttpPut("Update/{id}")]
        public async Task<IActionResult> UpdateShipment(int id, [FromBody] MstShipment mstShipment)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            try
            {
                var updatedShipment = await _shipmentService.UpdateShipment(id, mstShipment);
                return Ok(updatedShipment);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while updating the shipment.", detail = ex.Message });
            }
        }
    }
}
