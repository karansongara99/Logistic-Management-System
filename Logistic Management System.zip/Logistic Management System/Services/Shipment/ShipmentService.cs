﻿using Logistic_Management_System.Interfaces.Shipment.Repositories;
using Logistic_Management_System.Interfaces.Shipment.Services;
using Logistic_Management_System.Models;

namespace Logistic_Management_System.Services.Shipment
{
    public class ShipmentService : IShipmentService
    {
        private readonly IShipmentRepository _shipmentRepository;
        public ShipmentService(IShipmentRepository shipmentRepository)
        {
            this._shipmentRepository = shipmentRepository;
        }

        public Task<List<MstShipment>> GetAllShipments()
        {
            return _shipmentRepository.GetAllShipments();
        }

        public Task<List<MstShipment>> TopTens()
        {
            return _shipmentRepository.TopTens();
        }

        public Task<bool> DeleteAllShipments()
        {
            return _shipmentRepository.DeleteAllShipments();
        }

        public Task<int> GetTotalShipmentCount()
        {
            return _shipmentRepository.GetTotalShipmentCount();
        }
        public Task<List<MstShipment>> SearchShipments(string? shipcode, string? customername)
        {
            return _shipmentRepository.SearchShipments(shipcode, customername);
        }

        public Task<MstShipment> CreateShipment(MstShipment mstShipment)
        {
            return _shipmentRepository.CreateShipment(mstShipment);
        }

        public async Task<bool> DeleteShipment(int shipmentId)
        {
            return await _shipmentRepository.DeleteShipment(shipmentId);
        }

        public async Task<MstShipment> UpdateShipment(int shipmentId, MstShipment mstShipment)
        {
            return await _shipmentRepository.UpdateShipment(shipmentId, mstShipment);
        }
        public async Task<MstShipment?> GetShipmentById(int shipmentId)
        {
            return await _shipmentRepository.GetShipmentById(shipmentId);
        }
    }
}
