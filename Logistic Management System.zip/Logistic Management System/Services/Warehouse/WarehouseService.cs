﻿using Logistic_Management_System.Interfaces.Warehouse.Repositories;
using Logistic_Management_System.Interfaces.Warehouse.Services;
using Logistic_Management_System.Models;

namespace Logistic_Management_System.Services.Warehouse
{
    public class WarehouseService : IWarehouseService
    {
        private readonly IWarehouseRepository _warehouseRepository;

        public WarehouseService(IWarehouseRepository warehouseRepository)
        {
            this._warehouseRepository = warehouseRepository;
        }

        public Task<List<MstWarehouse>> GetAllWarehouses()
        {
            return _warehouseRepository.GetAllWarehouses();
        }
        public Task<List<MstWarehouse>> TopTens()
        {
            return _warehouseRepository.TopTens();
        }

        public Task<int> GetTotalWarehouseCount()
        {
            return _warehouseRepository.GetTotalWarehouseCount();
        }

        public async Task<bool> DeleteAllWarehouse()
        {
            return await _warehouseRepository.DeleteAllWarehouse();
        }

        public Task<List<MstWarehouse>> SearchWarehouses(string? name, string? conatactno, string? managername, string? address)
        {
            return _warehouseRepository.SearchWarehouses(name, conatactno, managername, address);
        }

        public Task<MstWarehouse> CreateWarehouse(MstWarehouse mstWarehouse)
        {
            return _warehouseRepository.CreateWarehouse(mstWarehouse);
        }

        public async Task<bool> DeleteWarehouse(int warehouseID)
        {
            return await _warehouseRepository.DeleteWarehouse(warehouseID);
        }

        public Task<MstWarehouse> UpdateWarehouse(int warehouseId, MstWarehouse mstWarehouse)
        {
            return _warehouseRepository.UpdateWarehouse(warehouseId, mstWarehouse);
        }

        public Task<MstWarehouse?> GetWarehouseById(int warehouseId)
        {
            return _warehouseRepository.GetWarehouseById(warehouseId);


        }
    }
}
