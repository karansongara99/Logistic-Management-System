﻿using Logistic_Management_System.Interfaces.Vehicle.Repositories;
using Logistic_Management_System.Interfaces.Vehicle.Services;
using Logistic_Management_System.Models;

namespace Logistic_Management_System.Services.Vehicle
{
    public class VehicleService : IVehicleService
    {
        private readonly IVehicleRepository _vehicleRepository;
        public VehicleService(IVehicleRepository vehicleRepository)
        {
            this._vehicleRepository = vehicleRepository;
        }
        public Task<List<MstVehicle>> GetAllVehicles()
        {
            return _vehicleRepository.GetAllVehicles();
        }

        public Task<List<MstVehicle>> TopTens()
        {
            return _vehicleRepository.TopTens();
        }

        public Task<int> GetTotalVehicleCount()
        {
            return _vehicleRepository.GetTotalVehicleCount();
        }

        public Task<List<MstVehicle>> SearchVehicles(string? name, string? type, string? vnumber)
        {
            return _vehicleRepository.SearchVehicles(name, type, vnumber);
        }

        public Task<bool> DeleteAllVehicle()
        {
            return _vehicleRepository.DeleteAllVehicle();
        }

        public Task<MstVehicle> CreateVehicle(MstVehicle mstVehicle)
        {
            return _vehicleRepository.CreateVehicle(mstVehicle);
        }

        public async Task<bool> DeleteVehicle(int vehicleID)
        {
            return await _vehicleRepository.DeleteVehicle(vehicleID);
        }

        public async Task<MstVehicle> UpdateVehicle(int vehicleId, MstVehicle mstVehicle)
        {
            return await _vehicleRepository.UpdateVehicle(vehicleId, mstVehicle);
        }

        public Task<MstVehicle?> GetVehicleById(int vehicleId)
        {
            return _vehicleRepository.GetVehicleById(vehicleId);
        }
    }
}