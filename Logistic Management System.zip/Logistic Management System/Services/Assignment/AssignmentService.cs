﻿using Logistic_Management_System.Interfaces.Assignment.Repositories;
using Logistic_Management_System.Interfaces.Assignment.Services;
using Logistic_Management_System.Models;

namespace Logistic_Management_System.Services.Assignment
{
    public class AssignmentService : IAssignmentService
    {

        private readonly IAssignmentRepository _assignmentRepository;

        public AssignmentService(IAssignmentRepository assignmentRepository)
        {
            this._assignmentRepository = assignmentRepository;
        }

        public Task<List<MstAssignment>> GetAllAssignments()
        {
            return _assignmentRepository.GetAllAssignments();
        }

        public Task<List<MstAssignment>> TopTens()
        {
            return _assignmentRepository.TopTens();
        }

        public Task<int> GetTotalAssignmentCount()
        {
            return _assignmentRepository.GetTotalAssignmentCount();
        }
        public Task<MstAssignment> CreateAssignment(MstAssignment mstAssignment)
        {
            return _assignmentRepository.CreateAssignment(mstAssignment);
        }
        public Task<bool> DeleteAssignment(int assignmentID)
        {
            return _assignmentRepository.DeleteAssignment(assignmentID);
        }
        public Task<bool> DeleteAllAssignment()
        {
            return _assignmentRepository.DeleteAllAssignment();
        }
        public Task<MstAssignment?> GetAssignmentById(int assignmentID)
        {
            return _assignmentRepository.GetAssignmentById(assignmentID);
        }
        public Task<MstAssignment> UpdateAssignment(int assignmentID, MstAssignment mstAssignment)
        {
            return _assignmentRepository.UpdateAssignment(assignmentID, mstAssignment);
        }

        public Task<List<MstAssignment>> SearchAssignment(string vehiclename)
        {
            return _assignmentRepository.SearchAssignment(vehiclename);
        }
    }
}
