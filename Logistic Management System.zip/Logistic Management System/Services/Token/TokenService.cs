﻿using System.IdentityModel.Tokens.Jwt;
using Logistic_Management_System.Interfaces.Token.Services;
using Logistic_Management_System.Utils;

namespace Logistic_Management_System.Services.Token
{
    public class TokenService : ITokenService
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        public TokenService(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        private string? GetJwtToken()
        {
            var authHeader = _httpContextAccessor.HttpContext?.Request?.Headers["Authorization"].FirstOrDefault();

            if (!string.IsNullOrEmpty(authHeader) && authHeader.StartsWith("Bearer "))
            {
                return authHeader.Replace("Bearer ", "").Trim();
            }

            return null;
        }

        public double GetAdminIdFromToken()
        {
            var token = GetJwtToken();

            if (string.IsNullOrEmpty(token))
            {
                return -1;
            }

            var claims = JWTMethods.GetClaimsFromToken(token);

            claims.TryGetValue(JwtRegisteredClaimNames.NameId, out string adminId);

            if (string.IsNullOrEmpty(adminId))
            {
                return -1;
            }

            return double.Parse(adminId);
        }
    }
}