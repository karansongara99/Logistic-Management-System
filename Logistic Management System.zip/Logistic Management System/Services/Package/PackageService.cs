﻿using Logistic_Management_System.Interfaces.Package.Repositories;
using Logistic_Management_System.Interfaces.Package.Services;
using Logistic_Management_System.Models;

namespace Logistic_Management_System.Services.Package
{
    public class PackageService : IPackageService
    {
        private readonly IPackageRepository _packageRepository;
        public PackageService(IPackageRepository packageRepository)
        {
            this._packageRepository = packageRepository;
        }
        public Task<List<MstPackage>> GetAllPackages()
        {
            return _packageRepository.GetAllPackages();
        }

        public Task<List<MstPackage>> TopTens()
        {
            return _packageRepository.TopTens();
        }

        public Task<int> GetTotalPackageCount()
        {
            return _packageRepository.GetTotalPackageCount();
        }

        public Task<List<MstPackage>> SearchPackages(string? shipcode, string? description)
        {
            return _packageRepository.SearchPackages(shipcode, description);
        }

        public Task<MstPackage> CreatePackage(MstPackage mstPackage)
        {
            return _packageRepository.CreatePackage(mstPackage);
        }

        public async Task<bool> DeletePackage(int packageID)
        {
            return await _packageRepository.DeletePackage(packageID);
        }

        public async Task<bool> DeleteAllPackages()
        {
            return await _packageRepository.DeleteAllPackages();
        }

        public Task<MstPackage> UpdatePackage(int packageId, MstPackage mstPackage)
        {
            return _packageRepository.UpdatePackage(packageId, mstPackage);
        }

        public Task<MstPackage> GetPackageById(int packageId)
        {
            return _packageRepository.GetPackageById(packageId);

        }
    }
}
