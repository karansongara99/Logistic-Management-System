﻿using Logistic_Management_System.Interfaces.Customer.Repositories;
using Logistic_Management_System.Interfaces.Customer.Services;
using Logistic_Management_System.Models;

namespace Logistic_Management_System.Services.Customer
{
    public class CustomerService : ICustomerService
    {
        private readonly ICustomerRepository _customerRepository;

        public CustomerService(ICustomerRepository customerRepository)
        {
            this._customerRepository = customerRepository;
        }

        public Task<List<MstCustomer>> GetAllCustomers()
        {
            return _customerRepository.GetAllCustomers();
        }

        public Task<List<MstCustomer>> TopTens()
        {
            return _customerRepository.TopTens();
        }

        public Task<int> GetTotalCustomerCount()
        {
            return _customerRepository.GetTotalCustomerCount();
        }

        public Task<List<MstCustomer>> SearchCustomers(string? name, string? contactNo)
        {
            return _customerRepository.SearchCustomers(name, contactNo);
        }

        public Task<(List<MstCustomer> Customers, int TotalCount)> GetCustomersPagination(int pageNumber, int pageSize)
        {
            return _customerRepository.GetCustomersPagination(pageNumber, pageSize);
        }

        public Task<bool> DeleteAllCustomers()
        {
            return _customerRepository.DeleteAllCustomers();
        }

        public Task<bool> SoftDeleteCustomer(int customerId)
        {
            return _customerRepository.SoftDeleteCustomer(customerId);
        }
        public Task<bool> HardDeleteCustomer(int customerId)
        {
            return _customerRepository.HardDeleteCustomer(customerId);
        }

        public Task<MstCustomer> AddCustomer(MstCustomer customer)
        {
            return _customerRepository.AddCustomer(customer);
        }
        public async Task<bool> UpdateCustomer(MstCustomer customer)
        {
            return await _customerRepository.UpdateCustomer(customer);
        }

    }
}
