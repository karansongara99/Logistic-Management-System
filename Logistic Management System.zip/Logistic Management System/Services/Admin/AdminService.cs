﻿using Logistic_Management_System.Interfaces.Admin.Repositories;
using Logistic_Management_System.Interfaces.Admin.Services;
using Logistic_Management_System.Models;
using Logistic_Management_System.Models.Admin;
using Logistic_Management_System.Models.Authentication;
using Logistic_Management_System.Utils;

namespace Logistic_Management_System.Services.Admin
{
    public class AdminService : IAdminService
    {
        private readonly IAdminRepository adminRepository;
        private readonly IConfiguration configuration;

        public AdminService(IAdminRepository adminRepository, IConfiguration configuration)
        {
            this.adminRepository = adminRepository;
            this.configuration = configuration;
        }

        public Task<MstAdmin?> GetAdminByAuthModel(AdminAuthDto adminAuthDto)
        {
            return adminRepository.GetAdminByAuthModel(adminAuthDto);
        }

        public async Task<AdminProfileDto?> GetAdminProfile()
        {
            var adminProfile = await adminRepository.GetAdminProfile();
            if (adminProfile is not null)
            {
                return new AdminProfileDto
                {
                    Name = adminProfile.Name,
                    EmailId = adminProfile.EmailId
                };
            }

            return null;
        }

        public async Task<JWTAuthDto?> GetJWTToken(AdminAuthDto adminAuthDto)
        {
            MstAdmin? mstAdmin = await GetAdminByAuthModel(adminAuthDto);
            if (mstAdmin is not null)
            {
                return JWTMethods.GenerateJSONWebToken(configuration, mstAdmin);
            }

            return null;
        }

        public Task<bool> RegisterAdminUser(AdminRegisterDto adminRegisterDto)
        {
            return adminRepository.RegisterAdminUser(adminRegisterDto);
        }
    }
}
