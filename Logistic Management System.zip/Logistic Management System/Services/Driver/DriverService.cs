﻿using Logistic_Management_System.Interfaces.Driver.Repositories;
using Logistic_Management_System.Interfaces.Driver.Services;
using Logistic_Management_System.Models;

namespace Logistic_Management_System.Services.Driver
{
    public class DriverService : IDriverService
    {
        private readonly IDriverRepository _driverRepository;
        public DriverService(IDriverRepository driverRepository)
        {
            this._driverRepository = driverRepository;
        }

        public Task<List<MstDriver>> GetAllDrivers()
        {
            return _driverRepository.GetAllDrivers();

        }

        public Task<List<MstDriver>> TopTens()
        {
            return _driverRepository.TopTens();
        }

        public Task<int> GetTotalDriverCount()
        {
            return _driverRepository.GetTotalDriverCount();
        }

        public Task<List<MstDriver>> SearchDrivers(string? name, string? contactno, string? address)
        {
            return _driverRepository.SearchDrivers(name, contactno, address);
        }

        public Task<MstDriver> CreateDriver(MstDriver mstDriver)
        {
            return _driverRepository.CreateDriver(mstDriver);
        }

        public async Task<bool> DeleteDriver(int driverID)
        {
            return await _driverRepository.DeleteDriver(driverID);
        }

        public async Task<bool> DeleteAllDrivers()
        {
            return await _driverRepository.DeleteAllDrivers();
        }

        public Task<MstDriver?> GetDriverById(int driverID)
        {
            return _driverRepository.GetDriverById(driverID);
        }

        public async Task<bool> UpdateDriver(int driverID, MstDriver mstDriver)
        {
            return await _driverRepository.UpdateDriver(driverID, mstDriver);
        }
    }
}
