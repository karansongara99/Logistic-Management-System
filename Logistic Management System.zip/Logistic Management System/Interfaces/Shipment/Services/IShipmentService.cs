﻿using System.Threading.Tasks;
using Logistic_Management_System.Models;
using Logistic_Management_System.Models.ShipmentGraph;

namespace Logistic_Management_System.Interfaces.Shipment.Services
{
    public interface IShipmentService
    {
        Task<List<MstShipment>> GetAllShipments();
        Task<List<MstShipment>> TopTens();
        Task<int> GetTotalShipmentCount();
        Task<List<MstShipment>> SearchShipments(string? shipcode, string? customername);
        Task<MstShipment> CreateShipment(MstShipment mstShipment);
        Task<bool> DeleteShipment(int shipmentId);
        Task<bool> DeleteAllShipments();
        Task<MstShipment?> GetShipmentById(int shipmentId);
        Task<MstShipment> UpdateShipment(int shipmentId, MstShipment mstShipment);
        Task<List<Models.ShipmentGraph.ShipmentCountByDateDto>> GetShipmentCountByDate();
        Task<List<Models.ShipmentGraph.ShipmentStatusDto>> GetShipmentStatusDistribution();
        Task<List<ShipmentCostDto>> GetShipmentCostOverTime();


    }
}
