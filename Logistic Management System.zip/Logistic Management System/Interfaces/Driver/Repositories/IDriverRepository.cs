﻿using Logistic_Management_System.Models;

namespace Logistic_Management_System.Interfaces.Driver.Repositories
{
    public interface IDriverRepository
    {
        Task<List<MstDriver>> GetAllDrivers();
        Task<List<MstDriver>> TopTens();
        Task<int> GetTotalDriverCount();
        Task<List<MstDriver>> SearchDrivers(string? name, string? contactno, string? address);
        Task<MstDriver> CreateDriver(MstDriver mstDriver);
        Task<bool> DeleteDriver(int driverID);
        Task<bool> DeleteAllDrivers();
        Task<MstDriver?> GetDriverById(int driverID);
        Task<bool> UpdateDriver(int driverID,MstDriver mstDriver);

    }
}
