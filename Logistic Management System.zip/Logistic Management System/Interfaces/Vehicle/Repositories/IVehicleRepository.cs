﻿using Logistic_Management_System.Models;

namespace Logistic_Management_System.Interfaces.Vehicle.Repositories
{
    public interface IVehicleRepository
    {
        Task<List<MstVehicle>> GetAllVehicles();
        Task<List<MstVehicle>> TopTens();
        Task<int> GetTotalVehicleCount();
        Task<List<MstVehicle>> SearchVehicles(string? name, string? type, string? vnumber);
        Task<MstVehicle> CreateVehicle(MstVehicle mstVehicle);
        Task<bool> DeleteVehicle(int vehicleID);
        Task<bool> DeleteAllVehicle();

        Task<MstVehicle> UpdateVehicle(int vehicleId, MstVehicle mstVehicle);
        Task<MstVehicle?> GetVehicleById(int vehicleId);
    }
}
