﻿using Logistic_Management_System.Models;

namespace Logistic_Management_System.Interfaces.Package.Repositories
{
    public interface IPackageRepository
    {
        Task<List<MstPackage>> GetAllPackages();
        Task<List<MstPackage>> TopTens();
        Task<int> GetTotalPackageCount();
        Task<List<MstPackage>> SearchPackages(string? shipcode, string? description);
        Task<MstPackage> CreatePackage(MstPackage mstPackage);
        Task<bool> DeletePackage(int packageID);
        Task<bool> DeleteAllPackages();
        Task<MstPackage> UpdatePackage(int packageId, MstPackage mstPackage);
        Task<MstPackage> GetPackageById(int packageId);
    }
}
