﻿namespace Logistic_Management_System.Interfaces.Token.Services
{
    public interface ITokenService
    {
        double GetAdminIdFromToken();
    }
}
