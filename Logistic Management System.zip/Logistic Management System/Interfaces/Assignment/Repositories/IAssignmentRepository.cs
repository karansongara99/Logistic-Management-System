﻿using Logistic_Management_System.Models;

namespace Logistic_Management_System.Interfaces.Assignment.Repositories
{
    public interface IAssignmentRepository
    {
        Task<List<MstAssignment>> GetAllAssignments();
        Task<List<MstAssignment>> TopTens();
        Task<int> GetTotalAssignmentCount();
        Task<List<MstAssignment>> SearchAssignment(string vehiclename);
        Task<MstAssignment> CreateAssignment(MstAssignment mstAssignment);
        Task<bool> DeleteAssignment(int assignmentID);
        Task<bool> DeleteAllAssignment();
        Task<MstAssignment?> GetAssignmentById(int assignmentID);
        Task<MstAssignment> UpdateAssignment(int assignmentID,MstAssignment mstAssignment);


    }
}
