﻿using Logistic_Management_System.Models;

namespace Logistic_Management_System.Interfaces.Warehouse.Repositories
{
    public interface IWarehouseRepository
    {
        Task<List<MstWarehouse>> GetAllWarehouses();
        Task<List<MstWarehouse>> TopTens();
        Task<int> GetTotalWarehouseCount();
        Task<List<MstWarehouse>> SearchWarehouses(string? name, string? conatactno, string? managername, string? address);
        Task<MstWarehouse> CreateWarehouse(MstWarehouse mstWarehouse);
        Task<bool> DeleteWarehouse(int warehouseID);
        Task<bool> DeleteAllWarehouse();

        Task<MstWarehouse> UpdateWarehouse(int warehouseId, MstWarehouse mstWarehouse);
        Task<MstWarehouse?> GetWarehouseById(int warehouseId);
    }
}
