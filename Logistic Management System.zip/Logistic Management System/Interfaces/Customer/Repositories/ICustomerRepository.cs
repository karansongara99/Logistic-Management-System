﻿using Braintree;
using Logistic_Management_System.Models;

namespace Logistic_Management_System.Interfaces.Customer.Repositories
{
    public interface ICustomerRepository
    {
        Task<List<MstCustomer>> GetAllCustomers();
        Task<List<MstCustomer>> TopTens();
        Task<int> GetTotalCustomerCount();
        Task<List<MstCustomer>> SearchCustomers(string? name, string? contactNo);
        Task<(List<MstCustomer> Customers, int TotalCount)> GetCustomersPagination(int pageNumber, int pageSize);
        Task<bool> SoftDeleteCustomer(int customerId);
        Task<bool> HardDeleteCustomer(int customerId);
        Task<MstCustomer> AddCustomer(MstCustomer customer);
        Task<bool> UpdateCustomer(MstCustomer customer);
        Task<bool> DeleteAllCustomers();


    }
}
