﻿using Logistic_Management_System.Models;
using Logistic_Management_System.Models.Admin;
using Logistic_Management_System.Models.Authentication;

namespace Logistic_Management_System.Interfaces.Admin.Services
{
    public interface IAdminService
    {
        Task<JWTAuthDto?> GetJWTToken(AdminAuthDto adminAuthDto);
        Task<bool> RegisterAdminUser(AdminRegisterDto adminRegisterDto);
        Task<AdminProfileDto?> GetAdminProfile();
    }
}
