﻿using Logistic_Management_System.Models;
using Logistic_Management_System.Models.Authentication;

namespace Logistic_Management_System.Interfaces.Admin.Repositories
{
    public interface IAdminRepository
    {
        Task<MstAdmin?> GetAdminByAuthModel(AdminAuthDto adminAuthDto);
        Task<bool> RegisterAdminUser(AdminRegisterDto adminRegisterDto);
        Task<bool> IsEmailAlreadyExists(string emailId);
        Task<MstAdmin?> GetAdminProfile();
    }
}
