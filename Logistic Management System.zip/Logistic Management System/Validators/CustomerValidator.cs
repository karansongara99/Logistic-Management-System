﻿using FluentValidation;
using Logistic_Management_System.Models;

namespace Logistic_Management_System.Validators
{
    public class CustomerValidator : AbstractValidator<MstCustomer>
    {
        public CustomerValidator()
        {
            RuleFor(customer => customer.FullName)
                .NotEmpty().WithMessage("Customer name is required.")
                .MaximumLength(100).WithMessage("Customer name cannot exceed 100 characters.");
            RuleFor(customer => customer.ContactNo)
                .EmailAddress().WithMessage("Invalid email format.")
                .MaximumLength(100).WithMessage("Email cannot exceed 100 characters.");
            RuleFor(customer => customer.AlternateNo)
                .Matches(@"^\d{10}$").WithMessage("Phone number must be 10 digits long.")
                .When(customer => !string.IsNullOrEmpty(customer.AlternateNo));
            RuleFor(customer => customer.Address)
                .MaximumLength(250).WithMessage("Address cannot exceed 250 characters.")
                .When(customer => !string.IsNullOrEmpty(customer.Address));
            RuleFor(customer => customer.EmailId)
               .EmailAddress().WithMessage("Invalid email format.")
               .MaximumLength(100).WithMessage("Email cannot exceed 100 characters.")
               .When(customer => !string.IsNullOrEmpty(customer.EmailId));
            RuleFor(customer => customer.Pincode)
                .Matches(@"^\d{6}$").WithMessage("Pincode must be 6 digits long.")
                .When(customer => !string.IsNullOrEmpty(customer.Pincode));
            RuleFor(customer => customer.Gstno)
                .Matches(@"^([0-9]{2})([A-Z]{5})([0-9]{4})([A-Z]{1})([1-9A-Z]{1})([Z]{1})([0-9A-Z]{1})$")
                .WithMessage("Invalid GST number format.")
                .When(customer => !string.IsNullOrEmpty(customer.Gstno));
        }
    }
}
