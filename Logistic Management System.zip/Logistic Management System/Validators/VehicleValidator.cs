﻿using FluentValidation;
using Logistic_Management_System.Models;

namespace Logistic_Management_System.Validators
{
    public class VehicleValidator : AbstractValidator<MstVehicle>
    {
        public VehicleValidator() 
        {
            RuleFor(vehicle => vehicle.Name)
                .NotEmpty().WithMessage("Vehicle name is required.")
                .MaximumLength(100).WithMessage("Vehicle name cannot exceed 100 characters.");
            RuleFor(vehicle => vehicle.Type)
                .NotEmpty().WithMessage("Vehicle type is required.")
                .MaximumLength(50).WithMessage("Vehicle type cannot exceed 50 characters.");
            RuleFor(vehicle => vehicle.VehicleNo)
                .NotEmpty().WithMessage("Vehicle number is required.")
                .Matches(@"^[A-Z0-9-]+$").WithMessage("Vehicle number can only contain uppercase letters, numbers, and hyphens.")
                .MaximumLength(20).WithMessage("Vehicle number cannot exceed 20 characters.");
            RuleFor(vehicle => vehicle.Status)
                .NotEmpty().WithMessage("Status is required.")
                .Must(status => status == "Active" || status == "Inactive")
                .WithMessage("Status must be either 'Active' or 'Inactive'.");
        }
    }
}
