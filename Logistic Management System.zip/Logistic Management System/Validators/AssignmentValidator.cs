﻿using FluentValidation;
using Logistic_Management_System.Models;

namespace Logistic_Management_System.Validators
{
    public class AssignmentValidator : AbstractValidator<MstAssignment>
    {
        public AssignmentValidator() 
        {
            RuleFor(x => x.ShipmentId)
                .NotNull()
                .WithMessage("Shipment ID is required.");
            RuleFor(x => x.DriverId)
                .NotNull()
                .WithMessage("Driver ID is required.");
            RuleFor(x => x.VehicleId)
                .NotNull()
                .WithMessage("Vehicle ID is required.");
            RuleFor(x => x.AssignDate)
                .NotNull()
                .WithMessage("Assign Date is required.")
                .LessThanOrEqualTo(DateTime.Now)
                .WithMessage("Assign Date cannot be in the future.");
        }
    }
}
