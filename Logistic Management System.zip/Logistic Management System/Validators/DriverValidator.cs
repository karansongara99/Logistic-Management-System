﻿using FluentValidation;
using Logistic_Management_System.Models;

namespace Logistic_Management_System.Validators
{
    public class DriverValidator : AbstractValidator<MstDriver>
    {
        public DriverValidator() 
        {
            RuleFor(driver => driver.Name)
                .NotEmpty().WithMessage("Driver name is required.")
                .MaximumLength(100).WithMessage("Driver name cannot exceed 100 characters.");
            RuleFor(driver => driver.ContactNo)
                .NotEmpty().WithMessage("Contact number is required.")
                .Matches(@"^\d{10}$").WithMessage("Contact number must be 10 digits.");
            RuleFor(driver => driver.Address)
                .NotEmpty().WithMessage("Address is required.")
                .MaximumLength(200).WithMessage("Address cannot exceed 200 characters.");
            RuleFor(driver => driver.LicenceNo)
                .NotEmpty().WithMessage("Licence number is required.")
                .MaximumLength(50).WithMessage("Licence number cannot exceed 50 characters.");
            RuleFor(driver => driver.AlternateNo)
                .Matches(@"^\d{10}$").WithMessage("Alternate number must be 10 digits.")
                .When(driver => !string.IsNullOrEmpty(driver.AlternateNo));
            RuleFor(driver => driver.RenewDate)
                .GreaterThanOrEqualTo(DateTime.Now).WithMessage("Renew date must be today or in the future.")
                .When(driver => driver.RenewDate.HasValue);
            RuleFor(driver => driver.DOB)
                .NotEmpty().WithMessage("Date of Birth is required.")
                .LessThan(DateTime.Now).WithMessage("Date of Birth must be in the past.")
                .When(driver => driver.DOB.HasValue);
            RuleFor(driver => driver.Age)
                .GreaterThan(0).WithMessage("Age must be greater than 0.")
                .When(driver => driver.Age.HasValue);
            RuleFor(driver => driver.Photo)
                .NotEmpty().WithMessage("Photo is required.")
                .Must(photo => photo.EndsWith(".jpg") || photo.EndsWith(".png"))
                .WithMessage("Photo must be a valid image file (jpg or png).")
                .When(driver => !string.IsNullOrEmpty(driver.Photo));
        }
    }
}
