﻿using FluentValidation;
using Logistic_Management_System.Models;

namespace Logistic_Management_System.Validators
{
    public class PackageValidator : AbstractValidator<MstPackage>
    {
        public PackageValidator() 
        {
            RuleFor(x => x.Describe)
                .NotEmpty().WithMessage("Description is required.")
                .MaximumLength(500).WithMessage("Description cannot exceed 500 characters.");
            RuleFor(x => x.Weight)
                .NotEmpty().WithMessage("Weight is required.")
                .Matches(@"^\d+(\.\d{1,2})?$").WithMessage("Weight must be a valid number with up to two decimal places.");
            RuleFor(x => x.Status)
                .NotEmpty().WithMessage("Status is required.")
                .Must(status => status == "Pending" || status == "Shipped" || status == "Delivered")
                .WithMessage("Status must be either 'Pending', 'Shipped', or 'Delivered'.");
            RuleFor(x => x.TotalBox)
                .GreaterThan(0).WithMessage("Total box count must be greater than zero.");
        }
    }
}
