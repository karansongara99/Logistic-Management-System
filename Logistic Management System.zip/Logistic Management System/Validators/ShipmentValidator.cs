﻿using FluentValidation;
using Logistic_Management_System.Models;

namespace Logistic_Management_System.Validators
{
    public class ShipmentValidator : AbstractValidator<MstShipment>
    {
        public ShipmentValidator()
        {
            RuleFor(x => x.ShipCode)
                .NotEmpty().WithMessage("Ship Code is required.")
                .Length(1, 50).WithMessage("Ship Code must be between 1 and 50 characters.");
            RuleFor(x => x.Arrival)
                .NotEmpty().WithMessage("Arrival is required.")
                .Length(1, 100).WithMessage("Arrival must be between 1 and 100 characters.");
            RuleFor(x => x.Deparature)
                .NotEmpty().WithMessage("Deparature is required.")
                .Length(1, 100).WithMessage("Deparature must be between 1 and 100 characters.");
            RuleFor(x => x.Status)
                .NotEmpty().WithMessage("Status is required.")
                .Length(1, 50).WithMessage("Status must be between 1 and 50 characters.");
            RuleFor(x => x.ShipDate)
                .NotNull().WithMessage("Ship Date is required.");
            RuleFor(x => x.DeliveryDate)
                .NotNull().WithMessage("Delivery Date is required.");
        }
    }
}
