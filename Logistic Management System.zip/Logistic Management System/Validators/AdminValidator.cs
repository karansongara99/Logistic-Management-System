﻿using FluentValidation;
using Logistic_Management_System.Models;

namespace Logistic_Management_System.Validators
{
    public class AdminValidator : AbstractValidator<MstAdmin>
    {
        public AdminValidator() 
        {
            RuleFor(admin => admin.Name)
                .NotEmpty().WithMessage("Admin Name is required.")
                .Length(2, 50).WithMessage("Admin Name must be between 2 and 50 characters.");
            RuleFor(admin => admin.EmailId)
                .NotEmpty().WithMessage("Admin Email is required.")
                .EmailAddress().WithMessage("Invalid email format.");
            RuleFor(admin => admin.Password)
                .NotEmpty().WithMessage("Admin Password is required.")
                .MinimumLength(6).WithMessage("Admin Password must be at least 6 characters long.");
        }
    }
}
