﻿using FluentValidation;
using Logistic_Management_System.Models;

namespace Logistic_Management_System.Validators
{
    public class WarehouseValidator : AbstractValidator<MstWarehouse>
    {
        public WarehouseValidator() 
        {
            RuleFor(x => x.Name)
                .NotEmpty().WithMessage("Warehouse name is required.")
                .MaximumLength(100).WithMessage("Warehouse name cannot exceed 100 characters.");
            RuleFor(x => x.Address)
                .NotEmpty().WithMessage("Address is required.")
                .MaximumLength(200).WithMessage("Address cannot exceed 200 characters.");
            RuleFor(x => x.Capacity)
                .NotEmpty().WithMessage("Capacity is required.")
                .Matches(@"^\d+$").WithMessage("Capacity must be a valid number.");
            RuleFor(x => x.Pincode)
                .NotEmpty().WithMessage("Pincode is required.")
                .Matches(@"^\d{6}$").WithMessage("Pincode must be a 6-digit number.");
            RuleFor(x => x.ContactNo)
                .NotEmpty().WithMessage("Contact number is required.")
                .Matches(@"^\d{10}$").WithMessage("Contact number must be a 10-digit number.");
            RuleFor(x => x.AlternateNo)
                .Matches(@"^\d{10}$").WithMessage("Alternate number must be a 10-digit number.")
                .When(x => !string.IsNullOrEmpty(x.AlternateNo));
            RuleFor(x => x.ManagerName)
                .NotEmpty().WithMessage("Manager name is required.")
                .MaximumLength(100).WithMessage("Manager name cannot exceed 100 characters.");
        }
    }
}
