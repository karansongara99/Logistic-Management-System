﻿using Logistic_Management_System.Models;
using Logistic_Management_System.Models.Authentication;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace Logistic_Management_System.Utils
{
    public static class JWTMethods
    {
        public static JWTAuthDto GenerateJSONWebToken(IConfiguration configuration, MstAdmin mstAdmin)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(configuration["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new[] {
                new Claim(JwtRegisteredClaimNames.Email, mstAdmin.EmailId),
                new Claim(JwtRegisteredClaimNames.Name, mstAdmin.Name),
                new Claim(JwtRegisteredClaimNames.NameId, mstAdmin.AdminId.ToString()),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
            };

            var tokenExpireTime = DateTime.Now.AddMinutes(int.Parse(configuration["Jwt:ExpireyTime"]));

            var token = new JwtSecurityToken(configuration["Jwt:Issuer"],
                configuration["Jwt:Issuer"],
                claims,
                expires: tokenExpireTime,
                signingCredentials: credentials);

            var JWTToken = new JwtSecurityTokenHandler().WriteToken(token);

            return new JWTAuthDto
            {
                Name = mstAdmin.Name,
                EmailId = mstAdmin.EmailId,
                JWTToken = JWTToken,
                JWTExpireTime = tokenExpireTime,
            };
        }

        public static Dictionary<string, string> GetClaimsFromToken(string jwtToken)
        {
            var TokenInfo = new Dictionary<string, string>();

            var handler = new JwtSecurityTokenHandler();
            var jwtSecurityToken = handler.ReadJwtToken(jwtToken);
            var claims = jwtSecurityToken.Claims.ToList();

            foreach (var claim in claims)
            {
                TokenInfo.Add(claim.Type, claim.Value);
            }

            return TokenInfo;
        }
    }
}
