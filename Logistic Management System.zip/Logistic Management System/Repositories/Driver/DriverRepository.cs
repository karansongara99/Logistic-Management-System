﻿using Logistic_Management_System.Interfaces.Driver.Repositories;
using Logistic_Management_System.Interfaces.Token.Services;
using Logistic_Management_System.Models;
using Microsoft.EntityFrameworkCore;

namespace Logistic_Management_System.Repositories.Driver
{
    public class DriverRepository : IDriverRepository
    {
        private readonly LogisticManagementSystemContext _context;
        private readonly double _adminId;
        public DriverRepository(LogisticManagementSystemContext logisticManagementSystemContext, ITokenService tokenService)
        {
            this._context = logisticManagementSystemContext;
            _adminId = tokenService.GetAdminIdFromToken();
        }
        public Task<List<MstDriver>> GetAllDrivers()
        {
            return _context.MstDrivers
                .Where(driver => driver.AdminId == _adminId)
                .Include(driver => driver.Vehicle)
                .ToListAsync();
        }

        public Task<List<MstDriver>> TopTens()
        {
            return _context.MstDrivers
                .Where(driver => driver.AdminId == _adminId)
                .Include(driver => driver.Vehicle)
                .OrderByDescending(driver => driver.Created)
                .Take(10)
                .ToListAsync();
        }

        public Task<int> GetTotalDriverCount()
        {
            return _context.MstDrivers
                .Where(driver => driver.AdminId == _adminId)
                .CountAsync();
        }

        public async Task<List<MstDriver>> SearchDrivers(string? name, string? contactno, string? address)
        {
            return await _context.MstDrivers
                .Where(c => (string.IsNullOrEmpty(name) || c.Name.Contains(name)) &&
                            (string.IsNullOrEmpty(contactno) || c.ContactNo.Contains(contactno)) &&
                            (string.IsNullOrEmpty(address) || c.Address.Contains(address)))
                .ToListAsync();
        }

        public async Task<MstDriver> CreateDriver(MstDriver mstDriver)
        {
            mstDriver.AdminId = (int)_adminId;
            await _context.MstDrivers.AddAsync(mstDriver);
            await _context.SaveChangesAsync();
            return mstDriver;
        }

        public async Task<bool> DeleteDriver(int driverID)
        {
            var driver = await _context.MstDrivers.FindAsync(driverID);
            if (driver == null || driver.AdminId != _adminId)
            {
                return false; // Driver not found or does not belong to the admin
            }
            _context.MstDrivers.Remove(driver);
            await _context.SaveChangesAsync();
            return true;
        }
    
    public async Task<bool> DeleteAllDrivers()
        {
            var drivers = await _context.MstDrivers
                .Where(driver => driver.AdminId == _adminId)
                .ToListAsync();

            if (drivers.Count == 0)
            {
                return false; // No drivers to delete
            }
            _context.MstDrivers.RemoveRange(drivers);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<MstDriver?> GetDriverById(int driverID)
        {
            return await _context.MstDrivers
                .Where(driver => driver.DriverId == driverID && driver.AdminId == _adminId)
                .Include(driver => driver.Vehicle)
                .FirstOrDefaultAsync();
        }

        public async Task<bool> UpdateDriver(int driverID, MstDriver mstDriver)
        {
            var existingDriver = await _context.MstDrivers.FindAsync(driverID);
            if (existingDriver == null || existingDriver.AdminId != _adminId)
            {
                return false; // Driver not found or does not belong to the admin
            }
            // Update the existing driver's properties
            existingDriver.Name = mstDriver.Name;
            existingDriver.VehicleId = mstDriver.VehicleId;
            existingDriver.ContactNo = mstDriver.ContactNo;
            existingDriver.Address = mstDriver.Address;
            existingDriver.Photo = mstDriver.Photo;
            existingDriver.LicenceNo = mstDriver.LicenceNo;
            existingDriver.AlternateNo = mstDriver.AlternateNo;
            existingDriver.RenewDate = mstDriver.RenewDate;
            existingDriver.DOB = mstDriver.DOB;
            existingDriver.Age = mstDriver.Age;
            _context.MstDrivers.Update(existingDriver);
            await _context.SaveChangesAsync();
            return true;
        }
    }

}