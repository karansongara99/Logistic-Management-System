﻿using Logistic_Management_System.Interfaces.Token.Services;
using Logistic_Management_System.Interfaces.Vehicle.Repositories;
using Logistic_Management_System.Models;
using Microsoft.EntityFrameworkCore;

namespace Logistic_Management_System.Repositories.Vehicle
{
    public class VehicleRepository : IVehicleRepository
    {
        private readonly LogisticManagementSystemContext _context;
        private readonly double _adminId;

        public VehicleRepository(LogisticManagementSystemContext logisticManagementSystemContext, ITokenService tokenService)
        {
            this._context = logisticManagementSystemContext;
            _adminId = tokenService.GetAdminIdFromToken();
        }
        public Task<List<MstVehicle>> GetAllVehicles()
        {
            return _context.MstVehicles.Where(vehicle => vehicle.AdminId == _adminId).Include(vehicle => vehicle.Warehouse).ToListAsync();
        }

        public Task<List<MstVehicle>> TopTens()
        {
            return _context.MstVehicles.Where(vehicle => vehicle.AdminId == _adminId)
                                       .Include(vehicle => vehicle.Warehouse)
                                       .OrderByDescending(vehicle => vehicle.Created)
                                       .Take(10)
                                       .ToListAsync();
        }

        public Task<int> GetTotalVehicleCount()
        {
            return _context.MstVehicles.Where(vehicle => vehicle.AdminId == _adminId).CountAsync();
        }

        public Task<List<MstVehicle>> SearchVehicles(string? name, string? type, string? vnumber)
        {
            return _context.MstVehicles
                .Where(vehicle => vehicle.AdminId == _adminId &&
                                  (string.IsNullOrEmpty(name) || vehicle.Name.Contains(name)) &&
                                  (string.IsNullOrEmpty(type) || vehicle.Type.Contains(type)) &&
                                  (string.IsNullOrEmpty(vnumber) || vehicle.VehicleNo.Contains(vnumber)))
                .Include(vehicle => vehicle.Warehouse)
                .ToListAsync();
        }

        public async Task<MstVehicle> CreateVehicle(MstVehicle mstVehicle)
        {
            mstVehicle.AdminId = (int)_adminId;
            await _context.MstVehicles.AddAsync(mstVehicle);
            await _context.SaveChangesAsync();
            return mstVehicle;
        }

        public async Task<bool> DeleteVehicle(int vehicleID)
        {
            var vehicle = await _context.MstVehicles.FindAsync(vehicleID);
            if (vehicle == null || vehicle.AdminId != _adminId)
            {
                return false; // Vehicle not found or does not belong to the admin
            }
            _context.MstVehicles.Remove(vehicle);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteAllVehicle()
        {
            var vehicles = await _context.MstVehicles.Where(vehicle => vehicle.AdminId == _adminId).ToListAsync();
            if (vehicles.Count == 0)
            {
                return false; // No vehicles to delete
            }
            _context.MstVehicles.RemoveRange(vehicles);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<MstVehicle> UpdateVehicle(int vehicleId, MstVehicle mstVehicle)
        {
            var existingVehicle = await _context.MstVehicles.FindAsync(vehicleId);
            if (existingVehicle == null || existingVehicle.AdminId != _adminId)
            {
                return null; // Vehicle not found or does not belong to the admin
            }
            existingVehicle.Name = mstVehicle.Name;
            existingVehicle.Type = mstVehicle.Type;
            existingVehicle.VehicleNo = mstVehicle.VehicleNo;
            existingVehicle.Status = mstVehicle.Status;
            existingVehicle.WarehouseId = mstVehicle.WarehouseId;
            _context.MstVehicles.Update(existingVehicle);
            await _context.SaveChangesAsync();
            return existingVehicle;
        }

        public Task<MstVehicle?> GetVehicleById(int vehicleId)
        {
            return _context.MstVehicles
                .Where(vehicle => vehicle.VehicleId == vehicleId && vehicle.AdminId == _adminId)
                .Include(vehicle => vehicle.Warehouse)
                .FirstOrDefaultAsync();
        }
    }
}
