﻿using Logistic_Management_System.Interfaces.Admin.Repositories;
using Logistic_Management_System.Interfaces.Token.Services;
using Logistic_Management_System.Models;
using Logistic_Management_System.Models.Authentication;
using Microsoft.EntityFrameworkCore;

namespace Logistic_Management_System.Repositories.Admin
{
    public class AdminRepository : IAdminRepository
    {
        private readonly LogisticManagementSystemContext _context;
        private readonly double _adminId;

        public AdminRepository(LogisticManagementSystemContext logisticManagementSystemContext, ITokenService tokenService)
        {
            _context = logisticManagementSystemContext;
            _adminId = tokenService.GetAdminIdFromToken();
        }

        public async Task<MstAdmin?> GetAdminByAuthModel(AdminAuthDto adminAuthDto)
        {
            var adminUsers = await _context.MstAdmins.ToListAsync();

            var adminUser = adminUsers.Find(model => model.EmailId.ToLower().Equals(adminAuthDto.EmailId.ToLower()) && model.Password.Equals(adminAuthDto.Password));

            if (adminUser is not null)
            {
                return adminUser;
            }

            return null;
        }

        public Task<bool> IsEmailAlreadyExists(string emailId) => _context.MstAdmins.AnyAsync(admin => admin.EmailId.ToLower().Equals(emailId.ToLower()));

        public async Task<bool> RegisterAdminUser(AdminRegisterDto adminRegisterDto)
        {
            var isEmailExists = await IsEmailAlreadyExists(adminRegisterDto.EmailId);

            if (isEmailExists)
            {
                return false;
            }

            MstAdmin mstAdmin = new()
            {
                EmailId = adminRegisterDto.EmailId,
                Password = adminRegisterDto.Password,
                Name = adminRegisterDto.Name,
            };

            await _context.MstAdmins.AddAsync(mstAdmin);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<MstAdmin?> GetAdminProfile()
        {
            return await _context.MstAdmins.FirstOrDefaultAsync(admin => admin.AdminId == _adminId);
        }
    }
}