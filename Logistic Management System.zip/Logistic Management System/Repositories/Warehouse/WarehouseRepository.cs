﻿using Logistic_Management_System.Interfaces.Token.Services;
using Logistic_Management_System.Interfaces.Warehouse.Repositories;
using Logistic_Management_System.Models;
using Microsoft.EntityFrameworkCore;

namespace Logistic_Management_System.Repositories.Warehouse
{
    public class WarehouseRepository : IWarehouseRepository
    {
        private readonly LogisticManagementSystemContext _context;
        private readonly double _adminId;
        public WarehouseRepository(LogisticManagementSystemContext logisticManagementSystemContext, ITokenService tokenService)
        {
            this._context = logisticManagementSystemContext;
            _adminId = tokenService.GetAdminIdFromToken();
        }

        public async Task<List<MstWarehouse>> GetAllWarehouses()
        {
            return await _context.MstWarehouses.Where(warehouse => warehouse.AdminId == _adminId).ToListAsync();
        }

        public async Task<List<MstWarehouse>> TopTens()
        {
            return await _context.MstWarehouses.Where(warehouse => warehouse.AdminId == _adminId)
                                               .OrderByDescending(warehouse => warehouse.Created)
                                               .Take(10)
                                               .ToListAsync();
        }

        public Task<int> GetTotalWarehouseCount()
        {
            return _context.MstWarehouses.Where(warehouse => warehouse.AdminId == _adminId).CountAsync();
        }

        public Task<List<MstWarehouse>> SearchWarehouses(string? name, string? conatactno, string? managername, string? address)
        {
            return _context.MstWarehouses
                .Where(warehouse => warehouse.AdminId == _adminId &&
                                   (string.IsNullOrEmpty(name) || warehouse.Name.Contains(name)) &&
                                   (string.IsNullOrEmpty(conatactno) || warehouse.ContactNo.Contains(conatactno)) &&
                                   (string.IsNullOrEmpty(managername) || warehouse.ManagerName.Contains(managername)) &&
                                   (string.IsNullOrEmpty(address) || warehouse.Address.Contains(address)))
                .ToListAsync();
        }



        public async Task<MstWarehouse> CreateWarehouse(MstWarehouse mstWarehouse)
        {
            mstWarehouse.AdminId = (int)_adminId;
            await _context.MstWarehouses.AddAsync(mstWarehouse);
            await _context.SaveChangesAsync();
            return mstWarehouse;
        }

        public async Task<bool> DeleteWarehouse(int warehouseID)
        {
            var warehouse = await _context.MstWarehouses.FindAsync(warehouseID);
            if (warehouse == null || warehouse.AdminId != _adminId)
            {
                return false; // Warehouse not found or does not belong to the admin
            }
            _context.MstWarehouses.Remove(warehouse);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteAllWarehouse()
        {
            var warehouses = await _context.MstWarehouses
                .Where(warehouse => warehouse.AdminId == _adminId)
                .ToListAsync();
            if (warehouses.Count == 0)
            {
                return false; // No warehouse to delete
            }
            _context.MstWarehouses.RemoveRange(warehouses);
            await _context.SaveChangesAsync();
            return true;
        }



        public async Task<MstWarehouse> UpdateWarehouse(int warehouseId, MstWarehouse mstWarehouse)
        {
            var existingWarehouse = await _context.MstWarehouses.FindAsync(warehouseId);
            if (existingWarehouse == null || existingWarehouse.AdminId != _adminId)
            {
                return null; // Warehouse not found or does not belong to the admin
            }
            existingWarehouse.Name = mstWarehouse.Name;
            existingWarehouse.Address = mstWarehouse.Address;
            existingWarehouse.Capacity = mstWarehouse.Capacity;
            existingWarehouse.Pincode = mstWarehouse.Pincode;
            existingWarehouse.ContactNo = mstWarehouse.ContactNo;
            existingWarehouse.AlternateNo = mstWarehouse.AlternateNo;
            existingWarehouse.ManagerName = mstWarehouse.ManagerName;
            existingWarehouse.Modified = DateTime.Now;
            await _context.SaveChangesAsync();
            return existingWarehouse;
        }

        public async Task<MstWarehouse?> GetWarehouseById(int warehouseId)
        {
            return await _context.MstWarehouses
                .Where(warehouse => warehouse.WarehouseId == warehouseId && warehouse.AdminId == _adminId)
                .FirstOrDefaultAsync();
        }
    }
}
