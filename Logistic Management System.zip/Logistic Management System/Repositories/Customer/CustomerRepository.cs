﻿using Braintree;
using Logistic_Management_System.Interfaces.Customer.Repositories;
using Logistic_Management_System.Interfaces.Token.Services;
using Logistic_Management_System.Models;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;
using OfficeOpenXml;
using OfficeOpenXml.Table;
using System.IO;
using System.Threading.Tasks;

namespace Logistic_Management_System.Repositories.Customer
{
    public class CustomerRepository : ICustomerRepository
    {
        private readonly LogisticManagementSystemContext _context;
        private readonly double _adminId;

        public CustomerRepository(LogisticManagementSystemContext logisticManagementSystemContext, ITokenService tokenService)
        {
            this._context = logisticManagementSystemContext;
            _adminId = tokenService.GetAdminIdFromToken();
        }

        public async Task<List<MstCustomer>> GetAllCustomers()
        {
            return await _context.MstCustomers.Where(customer => customer.AdminId == _adminId).ToListAsync();
        }

        public async Task<List<MstCustomer>> TopTens()
        {
            return await _context.MstCustomers
                .Where(customer => customer.AdminId == _adminId)
                .Take(10)
                .ToListAsync();
        }

        public async Task<int> GetTotalCustomerCount()
        {
            return await _context.MstCustomers
                .Where(customer => customer.AdminId == _adminId)
                .CountAsync();
        }

        public async Task<List<MstCustomer>> SearchCustomers(string? name, string? contactNo)
        {
            return await _context.MstCustomers
                .Where(c => (string.IsNullOrEmpty(name) || c.FullName.Contains(name)) &&
                            (string.IsNullOrEmpty(contactNo) || c.ContactNo.Contains(contactNo)))
                .ToListAsync();
        }

        public async Task<(List<MstCustomer> Customers, int TotalCount)> GetCustomersPagination(int pageNumber, int pageSize)
        {
            var query = _context.MstCustomers
                .Where(customer => customer.AdminId == _adminId);

            int totalCount = await query.CountAsync();

            var customers = await query
                .OrderBy(c => c.FullName)
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            return (customers, totalCount);
        }

        public async Task<bool> SoftDeleteCustomer(int customerId)
        {
            var customer = await _context.MstCustomers
                .FirstOrDefaultAsync(c => c.CustomerId == customerId && c.AdminId == _adminId);

            if (customer == null)
                return false;

            customer.IsActive = !customer.IsActive;

            _context.MstCustomers.Update(customer);
            await _context.SaveChangesAsync();

            return true;
        }


        public async Task<bool> HardDeleteCustomer(int customerId)
        {
            var customer = await _context.MstCustomers
                .FirstOrDefaultAsync(c => c.CustomerId == customerId && c.AdminId == _adminId);

            if (customer == null)
                return false;

            _context.MstCustomers.Remove(customer);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<MstCustomer> AddCustomer(MstCustomer customer)
        {
            customer.AdminId = (int)_adminId;
            customer.Created = DateTime.Now;
            customer.Modified = DateTime.Now;
            _context.MstCustomers.Add(customer);
            await _context.SaveChangesAsync();
            return customer;
        }

        public async Task<bool> UpdateCustomer(MstCustomer updatedCustomer)
        {
            var existingCustomer = await _context.MstCustomers
                .FirstOrDefaultAsync(c => c.CustomerId == updatedCustomer.CustomerId && c.AdminId == _adminId);

            if (existingCustomer == null)
                return false;

            // Update fields
            existingCustomer.FullName = updatedCustomer.FullName;
            existingCustomer.ContactNo = updatedCustomer.ContactNo;
            existingCustomer.AlternateNo = updatedCustomer.AlternateNo;
            existingCustomer.Address = updatedCustomer.Address;
            existingCustomer.EmailId = updatedCustomer.EmailId;
            existingCustomer.Pincode = updatedCustomer.Pincode;
            existingCustomer.Gstno = updatedCustomer.Gstno;
            existingCustomer.IsActive = updatedCustomer.IsActive ?? true; // Default true if null
            existingCustomer.Modified = DateTime.UtcNow;

            _context.MstCustomers.Update(existingCustomer);
            await _context.SaveChangesAsync();

            return true;
        }

        public async Task<bool> DeleteAllCustomers()
        {
            var customer = await _context.MstCustomers
                .Where(c => c.AdminId == _adminId)
                .ToListAsync();
            if (customer.Count == 0)
                return false;
            _context.MstCustomers.RemoveRange(customer);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}