﻿using Braintree;
using Logistic_Management_System.Interfaces.Customer.Repositories;
using Logistic_Management_System.Interfaces.Token.Services;
using Logistic_Management_System.Models;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;
using OfficeOpenXml;
using OfficeOpenXml.Table;
using System.IO;
using System.Threading.Tasks;

namespace Logistic_Management_System.Repositories.Customer
{
    public class CustomerRepository : ICustomerRepository
    {
        private readonly LogisticManagementSystemContext _context;
        private readonly double _adminId;

        public CustomerRepository(LogisticManagementSystemContext logisticManagementSystemContext, ITokenService tokenService)
        {
            this._context = logisticManagementSystemContext;
            _adminId = tokenService.GetAdminIdFromToken();
        }

        public async Task<List<MstCustomer>> GetAllCustomers()
        {
            return await _context.MstCustomers.Where(customer => customer.AdminId == _adminId).ToListAsync();
        }

        public async Task<List<MstCustomer>> TopTens()
        {
            return await _context.MstCustomers
                .Where(customer => customer.AdminId == _adminId)
                .Take(10)
                .ToListAsync();
        }

        public async Task<int> GetTotalCustomerCount()
        {
            return await _context.MstCustomers
                .Where(customer => customer.AdminId == _adminId)
                .CountAsync();
        }

        public async Task<List<MstCustomer>> SearchCustomers(string? name, string? contactNo)
        {
            return await _context.MstCustomers
                .Where(c => (string.IsNullOrEmpty(name) || c.FullName.Contains(name)) &&
                            (string.IsNullOrEmpty(contactNo) || c.ContactNo.Contains(contactNo)))
                .ToListAsync();
        }

        public async Task<(List<MstCustomer> Customers, int TotalCount)> GetCustomersPagination(int pageNumber, int pageSize)
        {
            var query = _context.MstCustomers
                .Where(customer => customer.AdminId == _adminId);

            int totalCount = await query.CountAsync();

            var customers = await query
                .OrderBy(c => c.FullName)
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            return (customers, totalCount);
        }

        public async Task<bool> SoftDeleteCustomer(int customerId)
        {
            var customer = await _context.MstCustomers
                .FirstOrDefaultAsync(c => c.CustomerId == customerId && c.AdminId == _adminId);

            if (customer == null)
                return false;

            customer.IsActive = !customer.IsActive;

            _context.MstCustomers.Update(customer);
            await _context.SaveChangesAsync();

            return true;
        }


        public async Task<bool> HardDeleteCustomer(int customerId)
        {
            var customer = await _context.MstCustomers
                .FirstOrDefaultAsync(c => c.CustomerId == customerId && c.AdminId == _adminId);

            if (customer == null)
                return false;

            _context.MstCustomers.Remove(customer);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<MstCustomer> CreateCustomer(MstCustomer customer)
        {
            customer.AdminId = (int)_adminId;
            await _context.MstCustomers.AddAsync(customer);
            await _context.SaveChangesAsync();
            return customer;
        }


        public async Task<bool> UpdateCustomer(int customerId, MstCustomer updatedCustomer)
        {
            var existingCustomer = await _context.MstCustomers
               .FirstOrDefaultAsync(s => s.CustomerId == customerId && s.AdminId == _adminId);

            if (existingCustomer is null) // Simplified null check to address IDE0270  
            {
                throw new KeyNotFoundException("Customer not found");
            }

            existingCustomer.FullName = updatedCustomer.FullName;
            existingCustomer.ContactNo = updatedCustomer.ContactNo;
            existingCustomer.AlternateNo = updatedCustomer.AlternateNo;
            existingCustomer.Address = updatedCustomer.Address;
            existingCustomer.EmailId = updatedCustomer.EmailId;
            existingCustomer.Pincode = updatedCustomer.Pincode;
            existingCustomer.Gstno = updatedCustomer.Gstno;
            existingCustomer.IsActive = updatedCustomer.IsActive ?? true;
            existingCustomer.Modified = DateTime.UtcNow;

            _context.MstCustomers.Update(existingCustomer);
            await _context.SaveChangesAsync();

            return true; // Fixed CS0029 by returning a boolean instead of the customer object  
        }


        public async Task<bool> DeleteAllCustomers()
        {
            var customer = await _context.MstCustomers
                .Where(c => c.AdminId == _adminId)
                .ToListAsync();
            if (customer.Count == 0)
                return false;
            _context.MstCustomers.RemoveRange(customer);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<MstCustomer?> GetCustomerById(int customerId)
        {
            return await _context.MstCustomers
                .Where(s => s.CustomerId == customerId && s.AdminId == _adminId)
                .FirstOrDefaultAsync();
        }
    }
}