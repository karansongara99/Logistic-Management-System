﻿using DocumentFormat.OpenXml.Wordprocessing;
using Logistic_Management_System.Interfaces.Shipment.Repositories;
using Logistic_Management_System.Interfaces.Token.Services;
using Logistic_Management_System.Models;
using Microsoft.EntityFrameworkCore;

namespace Logistic_Management_System.Repositories.Shipment
{
    public class ShipmentRepository : IShipmentRepository
    {
        private readonly LogisticManagementSystemContext _context;
        private readonly double _adminId;
        public ShipmentRepository(LogisticManagementSystemContext logisticManagementSystemContext, ITokenService tokenService)
        {
            this._context = logisticManagementSystemContext;
            _adminId = tokenService.GetAdminIdFromToken();
        }

        public async Task<List<MstShipment>> GetAllShipments()
        {
            return await _context.MstShipments.Where(shipment => shipment.AdminId == _adminId)
                .Include(shipment => shipment.Customer)
                .ToListAsync();
        }

        public async Task<List<MstShipment>> TopTens()
        {
            return await _context.MstShipments
                .Where(shipment => shipment.AdminId == _adminId)
                .OrderByDescending(shipment => shipment.Created)
                .Take(10)
                .Include(shipment => shipment.Customer)
                .ToListAsync();
        }

        public Task<int> GetTotalShipmentCount()
        {
            return _context.MstShipments.
                Where(shipment => shipment.AdminId == _adminId).CountAsync();
        }
        public async Task<List<MstShipment>> SearchShipments(string? shipcode, string? customername)
        {
            return await _context.MstShipments
                .Where(c => (string.IsNullOrEmpty(shipcode) || c.ShipCode.Contains(shipcode)) &&
                            (string.IsNullOrEmpty(customername) || c.Customer.FullName.Contains(customername)))
                .Include(c => c.Customer)
                .ToListAsync();
        }

        public async Task<MstShipment> CreateShipment(MstShipment mstShipment)
        {
            mstShipment.AdminId = (int)_adminId;
            await _context.MstShipments.AddAsync(mstShipment);
            await _context.SaveChangesAsync();
            return mstShipment;
        }

        public async Task<bool> DeleteShipment(int shipmentId)
        {
            var shipment = await _context.MstShipments
                .FirstOrDefaultAsync(s => s.ShipmentId == shipmentId && s.AdminId == _adminId);
            if (shipment == null)
            {
                return false;
            }
            _context.MstShipments.Remove(shipment);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteAllShipments()
        {
            var shipments = await _context.MstShipments
                .Where(s => s.AdminId == _adminId)
                .ToListAsync();
            if (shipments.Count == 0)
            {
                return false;
            }
            _context.MstShipments.RemoveRange(shipments);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<MstShipment> UpdateShipment(int shipmentId, MstShipment mstShipment)
        {
            var existingShipment = await _context.MstShipments
                .FirstOrDefaultAsync(s => s.ShipmentId == shipmentId && s.AdminId == _adminId);
            if (existingShipment == null)
            {
                throw new KeyNotFoundException("Shipment not found");
            }
            existingShipment.ShipCode = mstShipment.ShipCode;
            existingShipment.Arrival = mstShipment.Arrival;
            existingShipment.Deparature = mstShipment.Deparature;
            existingShipment.Status = mstShipment.Status;
            existingShipment.ShipDate = mstShipment.ShipDate;
            existingShipment.DeliveryDate = mstShipment.DeliveryDate;
            existingShipment.CustomerId = mstShipment.CustomerId;
            _context.MstShipments.Update(existingShipment);
            await _context.SaveChangesAsync();
            return existingShipment;
        }

        public async Task<MstShipment?> GetShipmentById(int shipmentId)
        {
            return await _context.MstShipments
                .Where(s => s.ShipmentId == shipmentId && s.AdminId == _adminId)
                .Include(s => s.Customer)
                .FirstOrDefaultAsync();
        }
    }
}
