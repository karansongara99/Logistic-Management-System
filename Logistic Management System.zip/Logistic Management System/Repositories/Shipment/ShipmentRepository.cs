﻿using DocumentFormat.OpenXml.Wordprocessing;
using Logistic_Management_System.Interfaces.Shipment.Repositories;
using Logistic_Management_System.Interfaces.Token.Services;
using Logistic_Management_System.Models;
using Logistic_Management_System.Models.ShipmentGraph;
using Microsoft.EntityFrameworkCore;

namespace Logistic_Management_System.Repositories.Shipment
{
    public class ShipmentRepository : IShipmentRepository
    {
        private readonly LogisticManagementSystemContext _context;
        private readonly double _adminId;
        public ShipmentRepository(LogisticManagementSystemContext logisticManagementSystemContext, ITokenService tokenService)
        {
            this._context = logisticManagementSystemContext;
            _adminId = tokenService.GetAdminIdFromToken();
        }

        public async Task<List<MstShipment>> GetAllShipments()
        {
            return await _context.MstShipments.Where(shipment => shipment.AdminId == _adminId)
                .Include(shipment => shipment.Customer)
                .ToListAsync();
        }

        public async Task<List<MstShipment>> TopTens()
        {
            return await _context.MstShipments
                .Where(shipment => shipment.AdminId == _adminId)
                .OrderByDescending(shipment => shipment.Created)
                .Take(10)
                .Include(shipment => shipment.Customer)
                .ToListAsync();
        }

        public Task<int> GetTotalShipmentCount()
        {
            return _context.MstShipments.
                Where(shipment => shipment.AdminId == _adminId).CountAsync();
        }
        public async Task<List<MstShipment>> SearchShipments(string? shipcode, string? customername)
        {
            return await _context.MstShipments
                .Where(c => (string.IsNullOrEmpty(shipcode) || c.ShipCode.Contains(shipcode)) &&
                            (string.IsNullOrEmpty(customername) || c.Customer.FullName.Contains(customername)))
                .Include(c => c.Customer)
                .ToListAsync();
        }

        public async Task<MstShipment> CreateShipment(MstShipment mstShipment)
        {
            mstShipment.AdminId = (int)_adminId;
            await _context.MstShipments.AddAsync(mstShipment);
            await _context.SaveChangesAsync();
            return mstShipment;
        }

        public async Task<bool> DeleteShipment(int shipmentId)
        {
            var shipment = await _context.MstShipments
                .FirstOrDefaultAsync(s => s.ShipmentId == shipmentId && s.AdminId == _adminId);
            if (shipment == null)
            {
                return false;
            }
            _context.MstShipments.Remove(shipment);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteAllShipments()
        {
            var shipments = await _context.MstShipments
                .Where(s => s.AdminId == _adminId)
                .ToListAsync();
            if (shipments.Count == 0)
            {
                return false;
            }
            _context.MstShipments.RemoveRange(shipments);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<MstShipment> UpdateShipment(int shipmentId, MstShipment mstShipment)
        {
            var existingShipment = await _context.MstShipments
                .FirstOrDefaultAsync(s => s.ShipmentId == shipmentId && s.AdminId == _adminId);
            if (existingShipment == null)
            {
                throw new KeyNotFoundException("Shipment not found");
            }
            existingShipment.ShipCode = mstShipment.ShipCode;
            existingShipment.Arrival = mstShipment.Arrival;
            existingShipment.Deparature = mstShipment.Deparature;
            existingShipment.Status = mstShipment.Status;
            existingShipment.ShipDate = mstShipment.ShipDate;
            existingShipment.DeliveryDate = mstShipment.DeliveryDate;
            existingShipment.CustomerId = mstShipment.CustomerId;
            existingShipment.ShipCost = mstShipment.ShipCost;
            _context.MstShipments.Update(existingShipment);
            await _context.SaveChangesAsync();
            return existingShipment;
        }

        public async Task<MstShipment?> GetShipmentById(int shipmentId)
        {
            return await _context.MstShipments
                .Where(s => s.ShipmentId == shipmentId && s.AdminId == _adminId)
                .Include(s => s.Customer)
                .FirstOrDefaultAsync();
        }

        public async Task<List<Models.ShipmentGraph.ShipmentCountByDateDto>> GetShipmentCountByDate()
        {
            return await _context.MstShipments
                .Where(s => s.AdminId == _adminId && s.ShipDate != null)
                .GroupBy(s => s.ShipDate.Value.Date)
                .Select(g => new Models.ShipmentGraph.ShipmentCountByDateDto
                {
                    Date = g.Key,
                    Count = g.Count()
                })
                .OrderBy(d => d.Date)
                .ToListAsync();
        }

        public async Task<List<Models.ShipmentGraph.ShipmentStatusDto>> GetShipmentStatusDistribution()
        {
            return await _context.MstShipments
                .Where(s => s.AdminId == _adminId && s.Status != null)
                .GroupBy(s => s.Status)
                .Select(g => new Models.ShipmentGraph.ShipmentStatusDto
                {
                    Status = g.Key,
                    Count = g.Count()
                })
                .OrderByDescending(g => g.Count)
                .ToListAsync();
        }

        public async Task<List<Models.ShipmentGraph.ShipmentCostDto>> GetShipmentCostOverTime()
        {
            return await _context.MstShipments
                .Where(s => s.AdminId == _adminId && s.ShipDate != null)
                .GroupBy(s => s.ShipDate.Value.Date)
                .Select(g => new Models.ShipmentGraph.ShipmentCostDto
                {
                    Date = g.Key,
                    TotalCost = g.Sum(x => x.ShipCost ?? 0)
                })
                .OrderBy(x => x.Date)
                .ToListAsync();
        }
    }
}
