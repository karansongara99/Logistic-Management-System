﻿using Logistic_Management_System.Interfaces.Assignment.Repositories;
using Logistic_Management_System.Interfaces.Token.Services;
using Logistic_Management_System.Models;
using Microsoft.EntityFrameworkCore;

namespace Logistic_Management_System.Repositories.Assignment
{
    public class AssignmentRepository : IAssignmentRepository
    {
        private readonly LogisticManagementSystemContext _context;
        private readonly double _adminId;
        public AssignmentRepository(LogisticManagementSystemContext logisticManagementSystemContext, ITokenService tokenService)
        {
            this._context = logisticManagementSystemContext;
            _adminId = tokenService.GetAdminIdFromToken();
        }

        public async Task<List<MstAssignment>> GetAllAssignments()
        {
            return await _context.MstAssignments
                .Where(assignment => assignment.AdminId == _adminId).Include(assignment => assignment.Shipment)
                .Include(assignment => assignment.Driver)
                .Include(assignment => assignment.Vehicle)
                .ToListAsync();
        }

        public async Task<List<MstAssignment>> TopTens()
        {
            return await _context.MstAssignments
                .Where(assignment => assignment.AdminId == _adminId)
                .Include(assignment => assignment.Shipment)
                .Include(assignment => assignment.Driver)
                .Include(assignment => assignment.Vehicle)
                .Take(10)
                .ToListAsync();
        }

        public async Task<int> GetTotalAssignmentCount()
        {
            return await _context.MstAssignments
                .Where(assignment => assignment.AdminId == _adminId)
                .CountAsync();
        }
        public async Task<MstAssignment> CreateAssignment(MstAssignment mstAssignment)
        {
            mstAssignment.AdminId = (int)_adminId;
            await _context.MstAssignments.AddAsync(mstAssignment);
            await _context.SaveChangesAsync();
            return mstAssignment;
        }
        public async Task<bool> DeleteAssignment(int assignmentID)
        {
            var assignment = await _context.MstAssignments.FindAsync(assignmentID);
            if (assignment == null || assignment.AdminId != _adminId)
            {
                return false;
            }
            _context.MstAssignments.Remove(assignment);
            await _context.SaveChangesAsync();
            return true;
        }
        public async Task<bool> DeleteAllAssignment()
        {
            var assignments = await _context.MstAssignments
                .Where(assignment => assignment.AdminId == _adminId)
                .ToListAsync();
            if (assignments.Count == 0)
            {
                return false;
            }
            _context.MstAssignments.RemoveRange(assignments);
            await _context.SaveChangesAsync();
            return true;
        }
        public async Task<MstAssignment?> GetAssignmentById(int assignmentID)
        {
            return await _context.MstAssignments
                .Where(assignment => assignment.AssignmentId == assignmentID && assignment.AdminId == _adminId)
                .Include(assignment => assignment.Shipment)
                .Include(assignment => assignment.Driver)
                .Include(assignment => assignment.Vehicle)
                .FirstOrDefaultAsync();
        }
        public async Task<MstAssignment> UpdateAssignment(int assignmentID, MstAssignment mstAssignment)
        {
            var existingAssignment = await _context.MstAssignments
                .Where(assignment => assignment.AssignmentId == assignmentID && assignment.AdminId == _adminId)
                .FirstOrDefaultAsync();
            if (existingAssignment == null)
            {
                throw new KeyNotFoundException("Assignment not found or does not belong to the admin.");
            }
            existingAssignment.ShipmentId = mstAssignment.ShipmentId;
            existingAssignment.DriverId = mstAssignment.DriverId;
            existingAssignment.VehicleId = mstAssignment.VehicleId;
            existingAssignment.AssignDate = mstAssignment.AssignDate;
            _context.MstAssignments.Update(existingAssignment);
            await _context.SaveChangesAsync();
            return existingAssignment;
        }

        public async Task<List<MstAssignment>> SearchAssignment(string vehiclename)
        {
            return await _context.MstAssignments
                .Where(assignment => assignment.AdminId == _adminId &&
                                     (assignment.Vehicle.Name.Contains(vehiclename) ||
                                      assignment.Driver.Name.Contains(vehiclename)))
                .Include(assignment => assignment.Shipment)
                .Include(assignment => assignment.Driver)
                .Include(assignment => assignment.Vehicle)
                .ToListAsync();
        }
    }
}
