﻿using ClosedXML.Excel;
using Logistic_Management_System.Interfaces.Package.Repositories;
using Logistic_Management_System.Interfaces.Token.Services;
using Logistic_Management_System.Models;
using Microsoft.EntityFrameworkCore;

namespace Logistic_Management_System.Repositories.Package
{
    public class PackageRepository : IPackageRepository
    {
        private readonly LogisticManagementSystemContext _context;
        private readonly double _adminId;

        public PackageRepository(LogisticManagementSystemContext logisticManagementSystemContext, ITokenService tokenService)
        {
            this._context = logisticManagementSystemContext;
            _adminId = tokenService.GetAdminIdFromToken();
        }
        public Task<List<MstPackage>> GetAllPackages()
        {
            return _context.MstPackages
                .Where(package => package.AdminId == _adminId).Include(package => package.Shipment).Include(package => package.Warehouse)
                .ToListAsync();
        }

        public Task<List<MstPackage>> TopTens()
        {
            return _context.MstPackages
                .Where(package => package.AdminId == _adminId)
                .OrderByDescending(package => package.Created)
                .Take(10)
                .Include(package => package.Shipment)
                .Include(package => package.Warehouse)
                .ToListAsync();
        }

        public Task<int> GetTotalPackageCount()
        {
            return _context.MstPackages
                .Where(package => package.AdminId == _adminId)
                .CountAsync();
        }

        public async Task<List<MstPackage>> SearchPackages(string? shipcode, string? description)
        {
            return await _context.MstPackages
                .Where(c => (string.IsNullOrEmpty(shipcode) || c.Shipment.ShipCode.Contains(shipcode)) &&
                            (string.IsNullOrEmpty(description) || c.Describe.Contains(description)))
                .ToListAsync();
        }
        public async Task<MstPackage> CreatePackage(MstPackage mstPackage)
        {
            mstPackage.AdminId = (int)_adminId;
            await _context.MstPackages.AddAsync(mstPackage);
            await _context.SaveChangesAsync();
            return mstPackage;
        }

        public async Task<bool> DeletePackage(int packageID)
        {
            var package = await _context.MstPackages.FindAsync(packageID);
            if (package == null || package.AdminId != _adminId)
            {
                return false; // Package not found or does not belong to the admin
            }
            _context.MstPackages.Remove(package);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteAllPackages()
        {
            var packages = await _context.MstPackages
                .Where(package => package.AdminId == _adminId)
                .ToListAsync();
            if (packages.Count == 0)
            {
                return false; // No packages to delete
            }
            _context.MstPackages.RemoveRange(packages);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<MstPackage> UpdatePackage(int packageId, MstPackage mstPackage)
        {
            var existingPackage = await _context.MstPackages.FindAsync(packageId);
            if (existingPackage == null || existingPackage.AdminId != _adminId)
            {
                return null; // Package not found or does not belong to the admin
            }
            existingPackage.ShipmentId = mstPackage.ShipmentId;
            existingPackage.WarehouseId = mstPackage.WarehouseId;
            existingPackage.Describe = mstPackage.Describe;
            existingPackage.Weight = mstPackage.Weight;
            existingPackage.Status = mstPackage.Status;
            existingPackage.TotalBox = mstPackage.TotalBox;
            existingPackage.Modified = DateTime.Now;
            _context.MstPackages.Update(existingPackage);
            await _context.SaveChangesAsync();
            return existingPackage;
        }

        public async Task<MstPackage> GetPackageById(int packageId)
        {
            var package = await _context.MstPackages
                .Where(p => p.PackageId == packageId && p.AdminId == _adminId)
                .Include(p => p.Shipment)
                .Include(p => p.Warehouse)
                .FirstOrDefaultAsync();
            return package;
        }
    }
}
