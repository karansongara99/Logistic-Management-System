using System.Text;
using System.Text.Json.Serialization;
using DocumentFormat.OpenXml.Office2016.Drawing.ChartDrawing;
using Logistic_Management_System.Interfaces.Admin.Repositories;
using Logistic_Management_System.Interfaces.Admin.Services;
using Logistic_Management_System.Interfaces.Assignment.Repositories;
using Logistic_Management_System.Interfaces.Assignment.Services;
using Logistic_Management_System.Interfaces.Customer.Repositories;
using Logistic_Management_System.Interfaces.Customer.Services;
using Logistic_Management_System.Interfaces.Driver.Repositories;
using Logistic_Management_System.Interfaces.Driver.Services;
using Logistic_Management_System.Interfaces.Package.Repositories;
using Logistic_Management_System.Interfaces.Package.Services;
using Logistic_Management_System.Interfaces.Shipment.Repositories;
using Logistic_Management_System.Interfaces.Shipment.Services;
using Logistic_Management_System.Interfaces.Token.Services;
using Logistic_Management_System.Interfaces.Vehicle.Repositories;
using Logistic_Management_System.Interfaces.Vehicle.Services;
using Logistic_Management_System.Interfaces.Warehouse.Repositories;
using Logistic_Management_System.Interfaces.Warehouse.Services;
using Logistic_Management_System.Models;
using Logistic_Management_System.Repositories.Admin;
using Logistic_Management_System.Repositories.Assignment;
using Logistic_Management_System.Repositories.Customer;
using Logistic_Management_System.Repositories.Driver;
using Logistic_Management_System.Repositories.Package;
using Logistic_Management_System.Repositories.Shipment;
using Logistic_Management_System.Repositories.Vehicle;
using Logistic_Management_System.Repositories.Warehouse;
using Logistic_Management_System.Services.Admin;
using Logistic_Management_System.Services.Assignment;
using Logistic_Management_System.Services.Customer;
using Logistic_Management_System.Services.Driver;
using Logistic_Management_System.Services.Package;
using Logistic_Management_System.Services.Shipment;
using Logistic_Management_System.Services.Token;
using Logistic_Management_System.Services.Vehicle;
using Logistic_Management_System.Services.Warehouse;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.Authorization;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers(options =>
{
    var policy = new AuthorizationPolicyBuilder()
        .RequireAuthenticatedUser()
        .Build();

    options.Filters.Add(new AuthorizeFilter(policy)); // Global auth filter
}).AddJsonOptions(options =>
{
    options.JsonSerializerOptions.ReferenceHandler = System.Text.Json.Serialization.ReferenceHandler.IgnoreCycles;
});
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();


//Configuration Added
var provider = builder.Services.BuildServiceProvider();
var config = provider.GetRequiredService<IConfiguration>();
builder.Services.AddDbContext<LogisticManagementSystemContext>(item => item.UseSqlServer(config.GetConnectionString("Connect")));

//React Step up
// CORS policy for React frontend
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowReactApp",
        policy => policy.WithOrigins("http://localhost:5173")
                        .AllowAnyHeader()
                        .AllowAnyMethod());
});


builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
.AddJwtBearer(jwtOptions =>
{
    jwtOptions.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidateLifetime = true,
        ValidateIssuerSigningKey = true,
        ClockSkew = TimeSpan.Zero, // Optional: Set clock skew to zero for immediate expiration
        ValidIssuer = builder.Configuration["Jwt:Issuer"],
        ValidAudience = builder.Configuration["Jwt:Audience"],
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"]))
    };
});

builder.Services.AddHttpContextAccessor();

builder.Services.AddScoped<IAdminRepository, AdminRepository>();
builder.Services.AddScoped<IAdminService, AdminService>();
builder.Services.AddScoped<ICustomerRepository, CustomerRepository>();
builder.Services.AddScoped<ICustomerService, CustomerService>();
builder.Services.AddScoped<IShipmentRepository, ShipmentRepository>();
builder.Services.AddScoped<IShipmentService, ShipmentService>();
builder.Services.AddScoped<IWarehouseRepository, WarehouseRepository>();
builder.Services.AddScoped<IWarehouseService, WarehouseService>();
builder.Services.AddScoped<IVehicleRepository, VehicleRepository>();
builder.Services.AddScoped<IVehicleService, VehicleService>();
builder.Services.AddScoped<IPackageRepository, PackageRepository>();
builder.Services.AddScoped<IPackageService, PackageService>();
builder.Services.AddScoped<IDriverRepository, DriverRepository>();
builder.Services.AddScoped<IDriverService, DriverService>();
builder.Services.AddScoped<IAssignmentRepository, AssignmentRepository>();
builder.Services.AddScoped<IAssignmentService, AssignmentService>();
builder.Services.AddScoped<ITokenService, TokenService>();


var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthentication();

app.UseAuthorization();

app.MapControllers();

app.UseCors("AllowReactApp");

app.Run();
