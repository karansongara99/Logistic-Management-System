﻿namespace Logistic_Management_System.Models
{
    public class MstPackage
    {
        public int PackageId { get; set; }
        public string? Describe { get; set; }
        public string? Weight { get; set; }
        public string? Status { get; set; }
        public int? TotalBox { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }

        public int? AdminId { get; set; }
        public virtual MstAdmin? Admin { get; set; }
        public int? WarehouseId { get; set; }
        public virtual MstWarehouse? Warehouse { get; set; }
        public int? ShipmentId { get; set; }
        public virtual MstShipment? Shipment { get; set; }

    }
}
