﻿namespace Logistic_Management_System.Models;

public partial class MstCustomer
{
    public int CustomerId { get; set; }

    public string? FullName { get; set; }

    public string? ContactNo { get; set; }

    public string? AlternateNo { get; set; }

    public string? Address { get; set; }

    public string? EmailId { get; set; }

    public string? Pincode { get; set; }

    public string? Gstno { get; set; }

    public bool? IsActive { get; set; }

    public DateTime? Created { get; set; }

    public DateTime? Modified { get; set; }

    public int? AdminId { get; set; }

    public virtual MstAdmin? Admin { get; set; }

    public virtual ICollection<MstShipment> MstShipments { get; set; } = new List<MstShipment>();
}
