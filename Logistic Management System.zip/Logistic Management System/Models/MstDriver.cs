﻿namespace Logistic_Management_System.Models
{
    public class MstDriver
    {
        public int? DriverId { get; set; }
        public string? Name { get; set; }
        public string? ContactNo { get; set; }
        public string? Address { get; set; }
        public string? LicenceNo { get; set; }
        public string? AlternateNo { get; set; }
        public DateTime? RenewDate { get; set; }      
        public DateTime? DOB { get; set; }
        public int? Age { get; set; }
        public string? Photo { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }
        public int? AdminId { get; set; }
        public virtual MstAdmin? Admin { get; set; }
        public int? VehicleId { get; set; }
        public virtual MstVehicle? Vehicle { get; set; }
    }
}
