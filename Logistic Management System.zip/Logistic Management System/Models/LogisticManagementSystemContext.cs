﻿using Microsoft.EntityFrameworkCore;

namespace Logistic_Management_System.Models;

public partial class LogisticManagementSystemContext : DbContext
{
    public LogisticManagementSystemContext()
    {
    }

    public LogisticManagementSystemContext(DbContextOptions<LogisticManagementSystemContext> options)
        : base(options)
    {
    }

    public virtual DbSet<MstAdmin> MstAdmins { get; set; }

    public virtual DbSet<MstCustomer> MstCustomers { get; set; }

    public virtual DbSet<MstShipment> MstShipments { get; set; }

    public virtual DbSet<MstWarehouse> MstWarehouses { get; set; }

    public virtual DbSet<MstVehicle> MstVehicles { get; set; }

    public virtual DbSet<MstPackage> MstPackages { get; set; }

    public virtual DbSet<MstDriver> MstDrivers { get; set; }

    public virtual DbSet<MstAssignment> MstAssignments { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("server=KARAN\\SQLEXPRESS;database=Logistic_Management_System;trusted_connection=true;TrustServerCertificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<MstAdmin>(entity =>
        {
            entity.HasKey(e => e.AdminId).HasName("PK__MST_Admi__719FE4E87FEA748C");

            entity.ToTable("MST_Admin");

            entity.Property(e => e.AdminId).HasColumnName("AdminID");
            entity.Property(e => e.Created)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.EmailId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("EmailID");
            entity.Property(e => e.Modified)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Name)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Password)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<MstCustomer>(entity =>
        {
            entity.HasKey(e => e.CustomerId).HasName("PK__MST_Cust__A4AE64B85CE3F434");

            entity.ToTable("MST_Customer");

            entity.Property(e => e.CustomerId).HasColumnName("CustomerID");
            entity.Property(e => e.Address)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.AdminId).HasColumnName("AdminID");
            entity.Property(e => e.AlternateNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ContactNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Created)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.EmailId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("EmailID");
            entity.Property(e => e.FullName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Full Name");
            entity.Property(e => e.Gstno)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("GSTNo");
            entity.Property(e => e.IsActive).HasDefaultValue(true);
            entity.Property(e => e.Modified)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Pincode)
                .HasMaxLength(50)
                .IsUnicode(false);

            entity.HasOne(d => d.Admin).WithMany(p => p.MstCustomers)
                .HasForeignKey(d => d.AdminId)
                .HasConstraintName("FK__MST_Custo__Admin__6383C8BA");
        });

        modelBuilder.Entity<MstShipment>(entity =>
        {
            entity.HasKey(e => e.ShipmentId).HasName("PK__MST_Ship__5CAD378D36212EEF");

            entity.ToTable("MST_Shipments");

            entity.Property(e => e.ShipmentId).HasColumnName("ShipmentID");
            entity.Property(e => e.AdminId).HasColumnName("AdminID");
            entity.Property(e => e.Arrival)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Created)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.CustomerId).HasColumnName("CustomerID");
            entity.Property(e => e.DeliveryDate).HasColumnType("datetime");
            entity.Property(e => e.Deparature)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Modified)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.ShipCost).HasColumnName("ShipCost");
            entity.Property(e => e.ShipCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ShipDate).HasColumnType("datetime");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false);

            entity.HasOne(d => d.Admin).WithMany(p => p.MstShipments)
                .HasForeignKey(d => d.AdminId)
                .HasConstraintName("FK__MST_Shipm__Admin__778AC167");

            entity.HasOne(d => d.Customer).WithMany(p => p.MstShipments)
                .HasForeignKey(d => d.CustomerId)
                .HasConstraintName("FK__MST_Shipm__Custo__787EE5A0");
        });

        modelBuilder.Entity<MstWarehouse>(entity =>
        {
            entity.HasKey(e => e.WarehouseId).HasName("PK__MST_Ware__C1F7D0A3B2E4F5A6");
            entity.ToTable("MST_Warehouse");
            entity.Property(e => e.WarehouseId).HasColumnName("WarehouseID");
            entity.Property(e => e.AdminId).HasColumnName("AdminID");
            entity.Property(e => e.Address)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.AlternateNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Capacity)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ContactNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Created)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.ManagerName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Modified)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Name)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Pincode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.HasOne(d => d.Admin).WithMany(p => p.MstWarehouses)
                .HasForeignKey(d => d.AdminId)
                .HasConstraintName("FK__MST_Wareh__Admin__6A30C649");
        });

        modelBuilder.Entity<MstVehicle>(entity =>
        {
            entity.HasKey(e => e.VehicleId).HasName("PK__MST_Veh__C1F7D0A3B2E4F5A6");
            entity.ToTable("MST_Vehicle");
            entity.Property(e => e.VehicleId).HasColumnName("VehicleID");
            entity.Property(e => e.AdminId).HasColumnName("AdminID");
            entity.Property(e => e.WarehouseId).HasColumnName("WarehouseID");
            entity.Property(e => e.Created)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Modified)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Name)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.VehicleNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.HasOne(d => d.Admin).WithMany(p => p.MstVehicles)
                .HasForeignKey(d => d.AdminId)
                .HasConstraintName("FK__MST_Vehic__Admin__6B24EA82");
            entity.HasOne(d => d.Warehouse).WithMany(p => p.MstVehicles)
                .HasForeignKey(d => d.WarehouseId)
                .HasConstraintName("FK__MST_Vehic__Wareh__6C190EBB");
        });

        modelBuilder.Entity<MstPackage>(entity =>
        {
            entity.HasKey(e => e.PackageId).HasName("PK__MST_Pack__C1F7D0A3B2E4F5A6");
            entity.ToTable("MST_Packages");
            entity.Property(e => e.PackageId).HasColumnName("PackageID");
            entity.Property(e => e.ShipmentId).HasColumnName("ShipmentID");
            entity.Property(e => e.AdminId).HasColumnName("AdminId");
            entity.Property(e => e.WarehouseId).HasColumnName("WarehouseId");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Weight)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Describe)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.TotalBox)
                .HasColumnName("TotalBox") 
                .HasDefaultValue(0);       
            entity.Property(e => e.Created)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Modified)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.HasOne(d => d.Admin).WithMany(p => p.MstPackages)
                .HasForeignKey(d => d.AdminId)
                .HasConstraintName("FK__MST_Packa__Admin__6D0D32F4");
            entity.HasOne(d => d.Shipment).WithMany(p => p.MstPackages)
                .HasForeignKey(d => d.ShipmentId)
                .HasConstraintName("FK__MST_Packa__Shipm__6E01572D");
            entity.HasOne(d => d.Warehouse).WithMany(p => p.MstPackages)
                .HasForeignKey(d => d.WarehouseId)
                .HasConstraintName("FK__MST_Packa__Wareh__6F7B8B9F");
        });

        modelBuilder.Entity<MstDriver>(entity =>
        {
            entity.HasKey(e => e.DriverId).HasName("PK__MST_Driv__C1F7D0A3B2E4F5A6");
            entity.ToTable("MST_Driver");
            entity.Property(e => e.DriverId).HasColumnName("DriverID");
            entity.Property(e => e.VehicleId).HasColumnName("VehicleID");
            entity.Property(e => e.AdminId).HasColumnName("AdminID");
            entity.Property(e => e.Name)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ContactNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.AlternateNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Address)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.LicenceNo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.RenewDate)
                .HasColumnType("date")
                .HasColumnName("RenewDate");
            entity.Property(e => e.DOB)
                .HasColumnType("date")
                .HasColumnName("DOB");
            entity.Property(e => e.Age)
                .HasColumnType("int")
                .HasDefaultValue(0);
            entity.Property(e => e.Photo)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("Photo");
            entity.Property(e => e.Created)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Modified)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.HasOne(d => d.Admin).WithMany(p => p.MstDrivers)
                .HasForeignKey(d => d.AdminId)
                .HasConstraintName("FK__MST_Drive__Admin__7008B0CA");
            entity.HasOne(d => d.Vehicle).WithMany(p => p.MstDrivers)
                .HasForeignKey(d => d.VehicleId)
                .HasConstraintName("FK__MST_Drive__Vehic__6F8D0D7A");
        });

        modelBuilder.Entity<MstAssignment>(entity =>
        {
            entity.HasKey(e => e.AssignmentId).HasName("PK__MST_Assignment__ID");

            entity.ToTable("MST_Assignments");

            entity.Property(e => e.AssignmentId).HasColumnName("AssignmentID");
            entity.Property(e => e.ShipmentId).HasColumnName("ShipmentID");
            entity.Property(e => e.DriverId).HasColumnName("DriverID");
            entity.Property(e => e.VehicleId).HasColumnName("VehicleID");
            entity.Property(e => e.AdminId).HasColumnName("AdminID");
            entity.Property(e => e.AssignDate)
                .HasColumnType("datetime")
                .HasDefaultValueSql();
            entity.Property(e => e.Created)
                .HasColumnType("datetime")
                .HasDefaultValueSql("(getdate())");
            entity.Property(e => e.Modified)
                .HasColumnType("datetime")
                .HasDefaultValueSql("(getdate())");

            entity.HasOne(d => d.Shipment)
                .WithMany()
                .HasForeignKey(d => d.ShipmentId)
                .HasConstraintName("FK__MST_Assignment__ShipmentID");

            entity.HasOne(d => d.Driver)
                .WithMany()
                .HasForeignKey(d => d.DriverId)
                .HasConstraintName("FK__MST_Assignment__DriverID");

            entity.HasOne(d => d.Vehicle)
                .WithMany()
                .HasForeignKey(d => d.VehicleId)
                .HasConstraintName("FK__MST_Assignment__VehicleID");

            entity.HasOne(d => d.Admin)
                .WithMany(p => p.MstAssignments)
                .HasForeignKey(d => d.AdminId)
                .HasConstraintName("FK__MST_Assignment__AdminID");
        });


        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
