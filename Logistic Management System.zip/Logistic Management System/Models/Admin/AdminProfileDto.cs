﻿namespace Logistic_Management_System.Models.Admin
{
    public class AdminProfileDto
    {
        public string Name { get; set; }
        public string EmailId { get; set; }
    }
}
