﻿namespace Logistic_Management_System.Models
{
    public class MstVehicle
    {
        public int VehicleId { get; set; }
        public string? Name { get; set; }
        public string? Type { get; set; }    
        public string? VehicleNo { get; set; }
        public string? Status { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }
        public int? AdminId { get; set; }
        public virtual MstAdmin? Admin { get; set; }
        public int? WarehouseId { get; set; }
        public virtual MstWarehouse? Warehouse { get; set; }
        public virtual ICollection<MstDriver> MstDrivers { get; set; } = new List<MstDriver>();

    }
}
