﻿using System.ComponentModel.DataAnnotations;

namespace Logistic_Management_System.Models.Authentication
{
    public class AdminAuthDto
    {
        [Required]
        public string EmailId { get; set; }

        [Required]
        public string Password { get; set; }
    }
}
