﻿namespace Logistic_Management_System.Models.Authentication
{
    public class JWTAuthDto
    {
        public string Name { get; set; }
        public string EmailId { get; set; }
        public string JWTToken { get; set; }
        public DateTime JWTExpireTime { get; set; }
    }
}
