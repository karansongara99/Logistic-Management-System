﻿namespace Logistic_Management_System.Models
{
    public class MstWarehouse
    {
        public int WarehouseId { get; set; }
        public string? Name { get; set; }
        public string? Address { get; set; }
        public string? Capacity { get; set; }
        public string? Pincode { get; set; }
        public string? ContactNo { get; set; }
        public string? AlternateNo { get; set; }
        public string? ManagerName { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }
        public int? AdminId { get; set; }
        public virtual MstAdmin? Admin { get; set; }

        public virtual ICollection<MstVehicle> MstVehicles { get; set; } = new List<MstVehicle>();

        public virtual ICollection<MstPackage> MstPackages { get; set; } = new List<MstPackage>();




    }
}
