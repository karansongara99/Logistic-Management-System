﻿namespace Logistic_Management_System.Models
{
    public class MstAssignment
    {
        public int AssignmentId{ get; set; }

        public int? ShipmentId{ get; set; }

        public virtual MstShipment? Shipment { get; set; }

        public int? DriverId{ get; set; }

        public virtual MstDriver? Driver { get; set; }

        public int? VehicleId { get; set; }

        public virtual MstVehicle? Vehicle { get; set; }

        public int? AdminId { get; set; }

        public virtual MstAdmin? Admin { get; set; }

        public DateTime? AssignDate { get; set; }

        public DateTime? Created { get; set; }

        public DateTime? Modified { get; set; }
       
    }
}
