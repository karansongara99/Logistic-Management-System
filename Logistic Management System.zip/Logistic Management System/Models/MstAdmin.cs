﻿namespace Logistic_Management_System.Models;

public partial class MstAdmin
{
    public int AdminId { get; set; }

    public string? Name { get; set; }

    public string? Password { get; set; }

    public string? EmailId { get; set; }

    public DateTime? Created { get; set; }

    public DateTime? Modified { get; set; }

    public virtual ICollection<MstCustomer> MstCustomers { get; set; } = new List<MstCustomer>();

    public virtual ICollection<MstShipment> MstShipments { get; set; } = new List<MstShipment>();

    public virtual ICollection<MstWarehouse> MstWarehouses { get; set; } = new List<MstWarehouse>();

    public virtual ICollection<MstVehicle> MstVehicles { get; set; } = new List<MstVehicle>();

    public virtual ICollection<MstPackage> MstPackages { get; set; } = new List<MstPackage>();

    public virtual ICollection<MstDriver> MstDrivers { get; set; } = new List<MstDriver>();

    public virtual ICollection<MstAssignment> MstAssignments { get; set; } = new List<MstAssignment>();
}
