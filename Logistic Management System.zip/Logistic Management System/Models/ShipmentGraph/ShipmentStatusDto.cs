﻿namespace Logistic_Management_System.Models.ShipmentGraph
{
    public class ShipmentStatusDto
    {
        public string Status { get; set; } 
        public int Count { get; set; }
    }
}
