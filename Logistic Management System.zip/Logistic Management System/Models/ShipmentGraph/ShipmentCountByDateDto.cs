﻿namespace Logistic_Management_System.Models.ShipmentGraph
{
    public class ShipmentCountByDateDto
    {
        public DateTime Date { get; set; }
        public int Count { get; set; }
    }
}
