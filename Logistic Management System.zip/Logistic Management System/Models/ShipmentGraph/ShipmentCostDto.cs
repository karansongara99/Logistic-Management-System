﻿namespace Logistic_Management_System.Models.ShipmentGraph
{

        public class ShipmentCostDto
        {
            public DateTime Date { get; set; }
            public int TotalCost { get; set; }
        }
    
}
