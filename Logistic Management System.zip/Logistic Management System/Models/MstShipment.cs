﻿namespace Logistic_Management_System.Models;

public partial class MstShipment
{
    public int ShipmentId { get; set; }

    public string? ShipCode { get; set; }

    public string? Arrival { get; set; }

    public string? Deparature { get; set; }

    public string? Status { get; set; }

    public DateTime? ShipDate { get; set; }

    public DateTime? DeliveryDate { get; set; }

    public DateTime? Created { get; set; }

    public DateTime? Modified { get; set; }

    public int? AdminId { get; set; }

    public int? CustomerId { get; set; }

    public virtual MstAdmin? Admin { get; set; }

    public virtual MstCustomer? Customer { get; set; }

    public virtual ICollection<MstPackage> MstPackages { get; set; } = new List<MstPackage>();


}
