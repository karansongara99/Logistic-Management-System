export const vehicleModel = {
    vehicleId: '',
    vehicleNumber: '',
    vehicleType: '',
    vehicleStatus: '',
    id: null,
};