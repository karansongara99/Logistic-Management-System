export const AdminAuthModel = {
    emailId: '',
    password: '',
};

export class AdminAuthModelClass {
    constructor(emailId, password) {
        this.emailId = emailId;
        this.password = password;
    }

    static fromObject(obj) {
        return new AdminAuthModelClass(obj.emailId, obj.password);
    }

    toObject() {
        return {
            emailId: this.emailId,
            password: this.password,
        };
    }
}