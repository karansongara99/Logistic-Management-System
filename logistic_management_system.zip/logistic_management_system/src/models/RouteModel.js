export const routeModel = {
    routeId: '',
    routeName: '',
    routeAddress: '',
    routeCapacity: '',
    routeStatus: '',
    id: null,
};