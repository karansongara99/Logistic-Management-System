export const AdminProfileModel = {
    name: null,
    emailId: null,
}