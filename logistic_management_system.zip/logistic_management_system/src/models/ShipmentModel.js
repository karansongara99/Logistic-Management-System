export const shipmentModel = {
    shipmentId: '',
    shipCode: '',
    arrival: '',
    deparature: null,
    status: null,
    shipDate: null,
    deliveryDate: null,
    customerId: null,
};
