export const shipmentModel = {
    shipmentId: '',
    shipCode: '',
    arrival: '',
    shipcost: '',
    deparature: null,
    status: null,
    shipDate: null,
    deliveryDate: null,
    customerId: null,
};
