export const warehouseModel = {
    warehouseId: '',
    warehouseName: '',
    warehouseAddress: '',
    warehouseCapacity: '',
    warehouseStatus: '',
    id: null,
};