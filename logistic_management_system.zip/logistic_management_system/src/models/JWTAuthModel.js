export const JWTAuthModel = {
  emailId: '',
  name: '',
  jwtToken: '',
  jwtExpireTime: '',
};