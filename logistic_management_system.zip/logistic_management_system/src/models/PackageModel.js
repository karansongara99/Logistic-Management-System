export const packageModel = {
    mstPackage: {
        packageId: '',
        shipmentId: '',
        warehouseId: '',
        describe: '',
        weight: '',
        status: '',
        totalBox: '',
    }
};