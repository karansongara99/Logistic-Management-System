export const customerModel = {
    fullName: '',
    contactNo: '',
    emailId: '',
    address: '',
    alternateNo: '',
    pincode: '',
    gstNo: '',
    isActive: true,
    id: null,
};
