export const adminRegisterModel = {
    name: '',
    emailId: '',
    password: '',
};

export class AdminRegisterModelClass {
    constructor(name, emailId, password) {
        this.name = name;
        this.emailId = emailId;
        this.password = password;
    }

    static fromObject(obj) {
        return new AdminRegisterModelClass(obj.name, obj.emailId, obj.password);
    }

    toObject() {
        return {
            name: this.name,
            emailId: this.emailId,
            password: this.password,
        };
    }
}