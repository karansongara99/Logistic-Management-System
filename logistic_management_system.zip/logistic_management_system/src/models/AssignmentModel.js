export const assignmentModel = {
    assignmentId: '',
    assignmentDate: '',
    assignmentStatus: '',
    driverId: null,
    vehicleId: null,
    routeId: null,
    id: null,
};


