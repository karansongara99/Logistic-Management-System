export const driverModel = {
    driverId: '',
    driverName: '',
    driverGender: '',
    driverAge: '',
    driverAddress: '',
    driverEmailId: '',
    driverAlternateNo: '',
    driverPincode: '',
    driverStatus: '',   
    id: null,
};