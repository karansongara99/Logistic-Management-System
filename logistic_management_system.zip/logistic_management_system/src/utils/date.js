import dayjs from "dayjs";
import { CONSTANTS } from "../constants/constant";

export const formatDate = (date, format = CONSTANTS.DATE_FORMATS.DEFAULT) => {
    if (!date) return '';
    return dayjs(date).format(format);
}

export const now = () => {
    return dayjs();
}

export const checkBefore = (date, compareDate = now()) => {
    if (!date) return false;
    return dayjs(date).isBefore(compareDate);
}

export const convertToDate = (dateString) => {
    if (!dateString) return null;
    return dayjs(dateString);
}