import { checkBefore, convertToDate, now } from './date'

const SESSION_KEY = 'sessionToken'

export const isAuthenticated = () => {
  return checkTokenExpiration()
}

export const getToken = () => {
  return localStorage.getItem(SESSION_KEY)
}

export const setUserInfo = userInfo => {
  const JSONString = JSON.stringify(userInfo)
  localStorage.setItem(SESSION_KEY, JSONString)
}

export const removeToken = () => {
  localStorage.removeItem(SESSION_KEY)
}

export const getUserInfo = () => {
  const token = getToken()
  if (!token) return null

  try {
    const userInfo = JSON.parse(token)
    return userInfo
  } catch (error) {
    console.error('Error decoding token:', error)
    return null
  }
}

export const getJWTToken = () => {
  const token = getToken()
  if (!token) return null

  try {
    const userInfo = JSON.parse(token)
    return userInfo.jwtToken
  } catch (error) {
    console.error('Error decoding JWT token:', error)
    return null
  }
}

export const checkTokenExpiration = () => {
  const token = getToken()
  if (!token) return false

  try {
    const userInfo = JSON.parse(token)
    const isJWTTokenExpired = checkBefore(now(), convertToDate(userInfo.jwtExpireTime))
    if (isJWTTokenExpired) {
      return true
    }
    removeToken()
    return false
  } catch (error) {
    console.error('Error checking token expiration:', error)
    return true
  }
}
