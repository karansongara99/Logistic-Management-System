import Layout from './components/Layout'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import DashBoard from './components/DashBoard'
import Customer from './pages/Customer/CustomerTable'
import CustomerForm from './pages/Customer/CustomerForm'
import Driver from './pages/Driver/DriverTable'
import DriverForm from './pages/Driver/DriverForm'
import WareHouse from './pages/WareHouse/WareHouseTable'
import WareHouseForm from './pages/WareHouse/WareHouseForm'
import Package from './pages/Package/PackageTable'
import PackageForm from './pages/Package/PackageForm'
import Shipment from './pages/Shipment/ShipmentTable'
import ShipmentForm from './pages/Shipment/ShipmentForm'
import Assignment from './pages/Assignment/AssignmentTable'
import AssignmentForm from './pages/Assignment/AssignmentForm'
import Routeing from './pages/Route/RouteTable'
import RouteForm from './pages/Route/RouteForm'
import Vehicle from './pages/Vehicle/VehicleTable'
import VehicleForm from './pages/Vehicle/VehicleForm'
import Login from './pages/Auth/Login'
import Register from './pages/Auth/Register'
import Profile from './pages/Profile'
import { CONSTANTS } from './constants/constant'
import { Bounce, ToastContainer } from 'react-toastify'
import ProtectedRoute from './components/ProtectedRoute'
import { Container } from './components/Container'

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Public Routes */}
        <Route path={CONSTANTS.ROUTES.LOGIN} element={<Login />} />
        <Route path={CONSTANTS.ROUTES.REGISTER} element={<Register />} />

        {/* Without layout routes */}
        <Route
          element={
            <ProtectedRoute>
              <Container />
            </ProtectedRoute>
          }
        >
          <Route path={CONSTANTS.ROUTES.PROFILE} element={<Profile />} />
        </Route>

        {/* Protected Routes */}
        <Route
          element={
            <ProtectedRoute>
              <Layout />
            </ProtectedRoute>
          }
        >
          <Route index element={<DashBoard />} />

          {/* Customer */}
          <Route
            path={CONSTANTS.ROUTES.CUSTOMER.LIST}
            element={<Customer />}
          />
          <Route
            path={CONSTANTS.ROUTES.CUSTOMER.FORM}
            element={<CustomerForm />}
          />
          <Route
            path={CONSTANTS.ROUTES.CUSTOMER.EDIT}
            element={<CustomerForm />}
          />

          {/* Driver */}
          <Route path={CONSTANTS.ROUTES.DRIVER.LIST} element={<Driver />} />
          <Route
            path={CONSTANTS.ROUTES.DRIVER.FORM}
            element={<DriverForm />}
          />
          <Route
            path={CONSTANTS.ROUTES.DRIVER.EDIT}
            element={<DriverForm />}
          />

          {/* Vehicle */}
          <Route path={CONSTANTS.ROUTES.VEHICLE.LIST} element={<Vehicle />} />
          <Route
            path={CONSTANTS.ROUTES.VEHICLE.FORM}
            element={<VehicleForm />}
          />
          <Route
            path={CONSTANTS.ROUTES.VEHICLE.EDIT}
            element={<VehicleForm />}
          />

          {/* WareHouse */}
          <Route
            path={CONSTANTS.ROUTES.WAREHOUSE.LIST}
            element={<WareHouse />}
          />
          <Route
            path={CONSTANTS.ROUTES.WAREHOUSE.FORM}
            element={<WareHouseForm />}
          />
          <Route
            path={CONSTANTS.ROUTES.WAREHOUSE.EDIT}
            element={<WareHouseForm />}
          />

          {/* Route */}
          <Route path={CONSTANTS.ROUTES.ROUTE.LIST} element={<Routeing />} />
          <Route path={CONSTANTS.ROUTES.ROUTE.FORM} element={<RouteForm />} />
          <Route path={CONSTANTS.ROUTES.ROUTE.EDIT} element={<RouteForm />} />

          {/* Package */}
          <Route path={CONSTANTS.ROUTES.PACKAGE.LIST} element={<Package />} />
          <Route
            path={CONSTANTS.ROUTES.PACKAGE.FORM}
            element={<PackageForm />}
          />
          <Route
            path={CONSTANTS.ROUTES.PACKAGE.EDIT}
            element={<PackageForm />}
          />

          {/* Shipment */}
          <Route
            path={CONSTANTS.ROUTES.SHIPMENT.LIST}
            element={<Shipment />}
          />
          <Route
            path={CONSTANTS.ROUTES.SHIPMENT.FORM}
            element={<ShipmentForm />}
          />
          <Route
            path={CONSTANTS.ROUTES.SHIPMENT.EDIT}
            element={<ShipmentForm />}
          />

          {/* Assignment */}
          <Route
            path={CONSTANTS.ROUTES.ASSIGNMENT.LIST}
            element={<Assignment />}
          />
          <Route
            path={CONSTANTS.ROUTES.ASSIGNMENT.FORM}
            element={<AssignmentForm />}
          />
          <Route
            path={CONSTANTS.ROUTES.ASSIGNMENT.EDIT}
            element={<AssignmentForm />}
          />
        </Route>
      </Routes>

      <ToastContainer
        position='top-right'
        autoClose={5000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick={false}
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme='light'
        transition={Bounce}
      />
    </BrowserRouter>
  )
}

export default App
