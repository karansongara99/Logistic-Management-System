import React, { useEffect, useState } from "react";
import "../../assets/styles/Shipment/ShipmentTable.css";
import { useNavigate } from "react-router-dom";
import { deleteAllShipment, deleteShipment, getShipmentList } from "../../services/ShipmentService";
import { formatDate } from "../../utils/date";
import { CONSTANTS } from "../../constants/constant";
import { DownloadTableExcel } from "react-export-table-to-excel";
import { useRef } from "react";

function ShipmentTable() {
    const navigate = useNavigate();
    const tableRef = useRef(null)
    const exportTableRef = useRef(null)
    const [shipments, setShipments] = useState([]);
    const [filteredShipments, setFilteredShipments] = useState([]);
    const [shipmentCode, setShipmentCode] = useState('');
    const [customerName, setCustomerName] = useState('');

    useEffect(() => {
        getShipments();
    }, []);

    const ExportTable = () => {
        return (
            <table style={{ display: 'none' }} ref={exportTableRef}>
                <thead>
                    <tr>
                        <th>Shipment Code</th>
                        <th>Customer Name</th>
                        <th>Arrival</th>
                        <th>Departure</th>
                        <th>Status</th>
                        <th>Shipment Date</th>
                        <th>Delivery Date</th>
                    </tr>
                </thead>
                <tbody>
                    {filteredShipments.map((shipment, index) => (
                        <tr key={index}>
                            <td>{shipment.shipCode}</td>
                            <td>{shipment.customer.fullName}</td>
                            <td>{shipment.arrival}</td>
                            <td>{shipment.deparature}</td>
                            <td className="status-active">{shipment.status ? 'Delivered' : 'Pending'}</td>
                            <td>{formatDate(shipment.shipDate)}</td>
                            <td>{formatDate(shipment.deliveryDate)}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        )
    }



    const deleteAllShipments = async () => {
        try {
            const result = window.confirm("Are you sure you want to delete all shipments?")
            if (!result) return
            await deleteAllShipment()
            getShipments()
        } catch (error) {
            console.error('Error deleting all shipments:', error)
        }
    }

    const handleDelete = async id => {
        try {
            const result = window.confirm("Are you sure you want to delete this shipment?")
            if (!result) return
            await deleteShipment(id)
            const updatedShipments = shipments.filter(shipment => shipment.shipmentId !== id)
            setShipments(updatedShipments)
            setFilteredShipments(updatedShipments)
        } catch (error) {
            console.error('Error deleting shipment:', error)
        }
    }

    const getShipments = async () => {
        const data = await getShipmentList();
        setShipments(data);
        setFilteredShipments(data); // Set initial filtered list
    };

    const handleEdit = shipmentId => {
        navigate(CONSTANTS.ROUTES.SHIPMENT.EDIT.replace(':id', shipmentId));
    }

    const handleSearch = () => {
        const filtered = shipments.filter(shipment => {
            const matchesCode = shipment.shipCode.toLowerCase().includes(shipmentCode.toLowerCase());
            const matchesCustomer = shipment.customer.fullName.toLowerCase().includes(customerName.toLowerCase());
            return matchesCode && matchesCustomer;
        });
        setFilteredShipments(filtered);
    };

    const handleReset = () => {
        setShipmentCode('');
        setCustomerName('');
        setFilteredShipments(shipments);
    };

    return (
        <div className="content">
            <div className="container">
                {/* Search Section */}
                <div className="search-section">
                    <h3>Search Shipment</h3>
                    <div className="search-fields">
                        <input
                            type="text"
                            id="shipmentCode"
                            placeholder="Shipment Code"
                            value={shipmentCode}
                            onChange={(e) => setShipmentCode(e.target.value)}
                        />
                        <input
                            type="text"
                            id="customerName"
                            placeholder="Customer Name"
                            value={customerName}
                            onChange={(e) => setCustomerName(e.target.value)}
                        />
                        <button className="btn btn-search" onClick={handleSearch}>Search</button>
                        <button className="btn btn-reset" onClick={handleReset}>Reset</button>
                    </div>
                </div>

                {/* Shipment List Table */}
                <div className="table-section">
                    <div className="table-header">
                        <h3>Shipment List</h3>
                        <div className="btn-group">
                            <button onClick={() => navigate(CONSTANTS.ROUTES.SHIPMENT.FORM)} className="btn btn-add">Add Shipment</button>
                            <DownloadTableExcel
                                filename='shipments_table'
                                sheet='shipments'
                                currentTableRef={exportTableRef.current}
                            >
                                <button className='btn btn-success'> Export excel </button>
                            </DownloadTableExcel>
                            <button onClick={deleteAllShipments} className="btn btn-delete-all">Delete All</button>
                        </div>
                    </div>
                    <table ref={tableRef}>
                        <thead>
                            <tr>
                                <th>Shipment Code</th>
                                <th>Customer Name</th>
                                <th>Arrival</th>
                                <th>Departure</th>
                                <th>Status</th>
                                <th>Shipment Date</th>
                                <th>Delivery Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredShipments.map((shipment, index) => (
                                <tr key={index}>
                                    <td>{shipment.shipCode}</td>
                                    <td>{shipment.customer.fullName}</td>
                                    <td>{shipment.arrival}</td>
                                    <td>{shipment.deparature}</td>
                                    <td
                                        className={`status ${shipment.status === 'Delivered'
                                                ? 'red'
                                                : shipment.status === 'Pending'
                                                    ? 'green'
                                                    : ''
                                            }`}
                                    >
                                        {shipment.status}
                                    </td>                                    <td>{formatDate(shipment.shipDate)}</td>
                                    <td>{formatDate(shipment.deliveryDate)}</td>
                                    <td className="action-buttons">
                                        <button className="btn btn-edit" onClick={() => handleEdit(shipment.shipmentId)}>Edit</button>
                                        <button className="btn btn-delete" onClick={() => handleDelete(shipment.shipmentId)}>Delete</button>
                                    </td>
                                </tr>
                            ))}
                            {filteredShipments.length === 0 && (
                                <tr>
                                    <td colSpan="8" style={{ textAlign: "center" }}>No shipments found.</td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                    {ExportTable()}
                </div>
            </div>
        </div>
    );
}

export default ShipmentTable;