import React, { useEffect, useState } from "react";
import "../../assets/styles/Shipment/ShipmentForm.css";
import { useNavigate, useParams } from "react-router-dom";
import {
  getShipmentById,
  updateShipment,
  createShipment,
} from "../../services/ShipmentService";
import { getCustomerList } from "../../services/CustomerService";
import { errorToast, successToast } from "../../services/ToastService";
import { CONSTANTS } from "../../constants/constant";

const initialShipmentModel = {
  shipCode: "",
  customerId: "",
  arrival: "",
  deparature: "",
  status: "",
  shipCost: "",
  shipDate: "",
  deliveryDate: "",
};

function ShipmentForm() {
  const navigate = useNavigate();
  const { id: shipmentId } = useParams();
  const [customers, setCustomers] = useState([]);
  const [formData, setFormData] = useState({ ...initialShipmentModel });

  useEffect(() => {
    fetchCustomers();
    if (shipmentId) {
      loadShipment(shipmentId);
    }
  }, [shipmentId]);

  const fetchCustomers = async () => {
    try {
      const data = await getCustomerList();
      setCustomers(data);
    } catch (error) {
      console.error("Failed to fetch customers", error);
      errorToast("Failed to load customers");
    }
  };

  const loadShipment = async (id) => {
    try {
      const data = await getShipmentById(id);
      const formatDate = (dateString) => {
        if (!dateString) return "";
        const date = new Date(dateString);
        return date.toISOString().split("T")[0];
      };

      setFormData({
        shipCode: data.shipCode || "",
        customerId: data.customerId?.toString() || "",
        arrival: data.arrival || "",
        deparature: data.deparature || "",
        status: data.status || "",
        shipCost: data.shipCost || "",
        shipDate: formatDate(data.shipDate),
        deliveryDate: formatDate(data.deliveryDate),
      });
    } catch (error) {
      console.error("Failed to load shipment", error);
      errorToast("Failed to load shipment");
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSave = async () => {
    try {
      if (
        !formData.shipCode ||
        !formData.customerId ||
        !formData.arrival ||
        !formData.deparature ||
        !formData.status ||
        !formData.shipCost ||
        !formData.shipDate ||
        !formData.deliveryDate
      ) {
        errorToast("Please fill all required fields.");
        return;
      }

      const shipmentPayload = {
        ...formData,
        customerId: parseInt(formData.customerId),
      };

      if (shipmentId) {
        await updateShipment(shipmentId, shipmentPayload);
        successToast("Shipment updated successfully");
      } else {
        await createShipment(shipmentPayload);
        successToast("Shipment created successfully");
      }

      navigate(CONSTANTS.ROUTES.SHIPMENT.LIST);
    } catch (error) {
      console.error("Error saving shipment:", error);
      const errorMsg = error?.response?.data?.message || "Failed to save shipment";
      errorToast(errorMsg);
    }
  };

  return (
    <div className="content">
      <div className="form-container">
        <h2>{shipmentId ? "Edit Shipment" : "Add Shipment"}</h2>

        <div className="form-group">
          <label htmlFor="shipCode">Shipment Code *</label>
          <input
            type="text"
            id="shipCode"
            name="shipCode" // Add name attribute
            placeholder="Enter Shipment Code"
            required
            value={formData.shipCode}
            onChange={handleChange}
          />
        </div>

        <div className="form-group">
          <label htmlFor="customerId">Customer Name *</label>
          <select
            id="customerId"
            name="customerId" // Add name attribute
            required
            value={formData.customerId}
            onChange={handleChange}
          >
            <option value="">Select Customer</option>
            {customers.map((customer) => (
              <option key={customer.customerId} value={customer.customerId}>
                {customer.fullName}
              </option>
            ))}
          </select>
        </div>

        <div className="form-group">
          <label htmlFor="arrival">Arrival *</label>
          <input
            type="text"
            id="arrival"
            name="arrival" // Add name attribute
            placeholder="Enter Arrival"
            required
            value={formData.arrival}
            onChange={handleChange}
          />
        </div>

        <div className="form-group">
          <label htmlFor="deparature">Departure *</label>
          <input
            type="text"
            id="deparature"
            name="deparature" // Add name attribute
            placeholder="Enter Departure"
            required
            value={formData.deparature}
            onChange={handleChange}
          />
        </div>

        <div className="form-group">
          <label htmlFor="status">Status *</label>
          <select
            id="status"
            name="status" // Add name attribute
            required
            value={formData.status}
            onChange={handleChange}
          >
            <option value="">Select Status</option>
            <option value="Delivered">Delivered</option>
            <option value="Pending">Pending</option>
          </select>
        </div>

        <div className="form-group">
          <label htmlFor="shipCost">Ship Cost *</label>
          <input
            type="number"
            id="shipCost"
            name="shipCost" // Add name attribute
            placeholder="Enter Ship Cost"
            required
            value={formData.shipCost}
            onChange={handleChange}
          />
        </div>

        <div className="form-group">
          <label htmlFor="shipDate">Shipment Date *</label>
          <input
            type="date"
            id="shipDate"
            name="shipDate" // Add name attribute
            required
            value={formData.shipDate}
            onChange={handleChange}
          />
        </div>

        <div className="form-group">
          <label htmlFor="deliveryDate">Delivery Date *</label>
          <input
            type="date"
            id="deliveryDate"
            name="deliveryDate" // Add name attribute
            required
            value={formData.deliveryDate}
            onChange={handleChange}
          />
        </div>

        <div className="button-group">
          <button className="save-btn" onClick={handleSave}>
            Save
          </button>
          <button
            className="cancel-btn"
            onClick={() => navigate(CONSTANTS.ROUTES.SHIPMENT.LIST)}
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}

export default ShipmentForm;
