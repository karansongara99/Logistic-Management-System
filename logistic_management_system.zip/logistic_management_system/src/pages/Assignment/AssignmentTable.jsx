import React from "react";
import "../../assets/styles/Assignment/AssignmentTable.css";
import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { getAssignmentList, deleteAllAssignment, deleteAssignment } from "../../services/AssignmentService";
import { formatDate } from "../../utils/date";
import { CONSTANTS } from "../../constants/constant";
import { useRef } from 'react';
import { DownloadTableExcel } from 'react-export-table-to-excel'



function AssignmentTable() {
    const navigate = useNavigate()
    const tableRef = useRef(null)
    const exportTableRef = useRef(null)
    const [assignments, setAssignments] = React.useState([])
    const [searchShipmentCode, setSearchShipmentCode] = React.useState('')
    const [searchDriverName, setSearchDriverName] = React.useState('')
    const [searchVehicleName, setSearchVehicleName] = React.useState('')

    useEffect(() => {
        getAssignments()
    }, [])

    const ExportTable = () => {
        return (
            <table style={{ display: 'none' }} ref={exportTableRef}>
                <thead>
                    <tr>
                        <th>Shipment Code</th>
                        <th>Driver Name</th>
                        <th>Vehicle Name</th>
                        <th>Assignment Date</th>
                    </tr>
                </thead>
                <tbody>
                    {assignments.map((assignment, index) => (
                        <tr key={index}>
                            <td>{assignment.shipment.shipCode}</td>
                            <td>{assignment.driver.name}</td>
                            <td>{assignment.vehicle.name}</td>
                            <td>{formatDate(assignment.assignDate)}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        )
    }

    const handleEdit = (assignmentId) => {
        alert("Edit Assignment")
        navigate(CONSTANTS.ROUTES.ASSIGNMENT.EDIT.replace(":id", assignmentId));
    };

    const getAssignments = async () => {
        const assignments = await getAssignmentList()
        setAssignments(assignments)
    }

    const handleSearch = () => {
        if (searchShipmentCode === '' && searchDriverName === '' && searchVehicleName === '') {
            getAssignments()
            return
        }
        const filtered = assignments.filter(assignment => {
            const matchesShipmentCode = assignment.shipment.shipCode.toLowerCase().includes(searchShipmentCode.toLowerCase());
            const matchesDriverName = assignment.driver.name.toLowerCase().includes(searchDriverName.toLowerCase());
            const matchesVehicleName = assignment.vehicle.name.toLowerCase().includes(searchVehicleName.toLowerCase());
            return matchesShipmentCode && matchesDriverName && matchesVehicleName;
        });
        setAssignments(filtered);
    }

    const handleDelete = async assignmentId => {
        try {
            const result = window.confirm("Are you sure you want to delete this assignment?")
            if (!result) return
            await deleteAssignment(assignmentId)
            getAssignments()
        } catch (error) {
            console.error('Error deleting assignment:', error)
        }
    }

    const deleteAllAssignments = async () => {
        try {
            const result = window.confirm("Are you sure you want to delete all assignments?")
            if (!result) return
            await deleteAllAssignment()
            getAssignments()
        } catch (error) {
            console.error('Error deleting all assignments:', error)
        }
    }

    const resetSearch = () => {
        setSearchShipmentCode('');
        setSearchDriverName('');
        setSearchVehicleName('');
        getAssignments();
    }

    return (
        <div className="content">
            <div className="container">
                {/* Search Section */}
                <div className="search-section">
                    <h3>Search Assignments</h3>
                    <div className="search-fields">
                        <input type="text" id="shipmentCode" placeholder="Shipment Code" value={searchShipmentCode} onChange={(e) => setSearchShipmentCode(e.target.value)} />
                        <input type="text" id="driverName" placeholder="Driver Name" value={searchDriverName} onChange={(e) => setSearchDriverName(e.target.value)} />
                        <input type="text" id="vehicleName" placeholder="Vehicle Name" value={searchVehicleName} onChange={(e) => setSearchVehicleName(e.target.value)} />
                        <button className="btn btn-search" onClick={handleSearch}>Search</button>
                        <button className="btn btn-reset" onClick={() => resetSearch()}>Reset</button>
                    </div>
                </div>
                {/* Customer List Table */}
                <div className="table-section">
                    <div className="table-header">
                        <h3>Assignment List</h3>
                        <div className="btn-group">
                            <button onClick={() => navigate("/assignmentForm")} className="btn btn-add">Add Assignment</button>
                            <DownloadTableExcel
                                filename='assignments_table'
                                sheet='assignments'
                                currentTableRef={exportTableRef.current}
                            >
                                <button className='btn btn-success'> Export excel </button>
                            </DownloadTableExcel>
                            <button onClick={() => deleteAllAssignments()} className="btn btn-delete-all">Delete All</button>
                        </div>
                    </div>
                    <table ref={exportTableRef}>
                        <thead>
                            <tr>
                                <th>Shipment Code</th>
                                <th>Driver Name</th>
                                <th>Vehicle Name</th>
                                <th>Assignment Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {assignments.length === 0 ? (
                                <tr>
                                    <td colSpan="5" className="no-data" style={{ textAlign: "center" }}>No assignments found</td>
                                </tr>
                            ) : (
                                assignments.map((assignment, index) => (
                                    <tr key={index}>
                                        <td>{assignment.shipment.shipCode}</td>
                                        <td>{assignment.driver.name}</td>
                                        <td>{assignment.vehicle.name}</td>
                                        <td>{formatDate(assignment.assignDate)}</td>
                                        <td className="action-buttons">
                                            <button className="btn btn-edit" onClick={() => handleEdit(assignment.assignmentId)}>Edit</button>
                                            <button className="btn btn-delete" onClick={() => handleDelete(assignment.assignmentId)}>Delete</button>
                                        </td>
                                    </tr>
                                )))}
                        </tbody>
                    </table>
                    {ExportTable()}
                </div>
            </div>
        </div>
    );
}

export default AssignmentTable;
