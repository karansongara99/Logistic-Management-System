import React, { useEffect, useState } from "react";
import "../../assets/styles/Assignment/AssignmentForm.css";
import { useNavigate, useParams } from "react-router-dom";
import { errorToast } from "../../services/ToastService";
import { CONSTANTS } from "../../constants/constant";
import { getVehicleList } from "../../services/VehicleService";
import { getDriverList } from "../../services/DriverService";
import { getShipmentList } from "../../services/ShipmentService";
import {
    createAssignment,
    updateAssignment,
    getAssignmentById,
} from "../../services/AssignmentService";

function AssignmentForm() {
    const navigate = useNavigate();
    const { id } = useParams();
    const isEdit = !!id;

    const [vehicles, setVehicles] = useState([]);
    const [drivers, setDrivers] = useState([]);
    const [shipments, setShipments] = useState([]);

    const [vehicleId, setVehicleId] = useState("");
    const [driverId, setDriverId] = useState("");
    const [shipmentId, setShipmentId] = useState("");
    const [assignDate, setAssignDate] = useState("");

    const [errors, setErrors] = useState({});
    const [isSubmitting, setIsSubmitting] = useState(false);

    useEffect(() => {
        if (isEdit) {
            loadAssignmentData(id);
        }
        loadDropdowns();
    }, [id]);

    const loadDropdowns = async () => {
        const [vehicleData, driverData, shipmentData] = await Promise.all([
            getVehicleList(),
            getDriverList(),
            getShipmentList(),
        ]);
        setVehicles(vehicleData);
        setDrivers(driverData);
        setShipments(shipmentData);
    };

    const loadAssignmentData = async (assignmentId) => {
        try {
            const data = await getAssignmentById(assignmentId);
            setVehicleId(data.vehicleId);
            setDriverId(data.driverId);
            setShipmentId(data.shipmentId);
            setAssignDate(data.assignDate?.split("T")[0] || "");
        } catch (error) {
            console.error("Failed to load assignment data", error);
            errorToast("Failed to load assignment.");
        }
    };

    const validate = () => {
        const newErrors = {};
        if (!shipmentId) newErrors.shipmentId = "Shipment is required.";
        if (!driverId) newErrors.driverId = "Driver is required.";
        if (!vehicleId) newErrors.vehicleId = "Vehicle is required.";
        if (!assignDate) newErrors.assignDate = "Assignment date is required.";
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async () => {
        if (!validate()) {
            errorToast("Please fix the errors before submitting.");
            return;
        }

        const payload = {
            vehicleId,
            driverId,
            shipmentId,
            assignDate,
        };

        try {
            setIsSubmitting(true);
            if (isEdit) {
                await updateAssignment(id, payload);
            } else {
                await createAssignment(payload);
            }
            navigate(CONSTANTS.ROUTES.ASSIGNMENT.LIST);
        } catch (error) {
            console.error(error);
            errorToast(
                error?.response?.data || "Failed to submit assignment. Try again."
            );
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="content">
            <div className="form-container">
                <h2>{isEdit ? "Edit Assignment" : "Add Assignment"}</h2>

                <div className="form-group">
                    <label htmlFor="shipmentId">Shipment Code *</label>
                    <select
                        id="shipmentId"
                        className={errors.shipmentId ? "error" : ""}
                        value={shipmentId}
                        onChange={(e) => {
                            setShipmentId(e.target.value);
                            setErrors({ ...errors, shipmentId: "" });
                        }}
                    >
                        <option value="">Select Shipment</option>
                        {shipments.map((s) => (
                            <option key={s.shipmentId} value={s.shipmentId}>
                                {s.shipCode}
                            </option>
                        ))}
                    </select>
                    {errors.shipmentId && <span className="error-msg">{errors.shipmentId}</span>}
                </div>

                <div className="form-group">
                    <label htmlFor="driverId">Driver Name *</label>
                    <select
                        id="driverId"
                        className={errors.driverId ? "error" : ""}
                        value={driverId}
                        onChange={(e) => {
                            setDriverId(e.target.value);
                            setErrors({ ...errors, driverId: "" });
                        }}
                    >
                        <option value="">Select Driver</option>
                        {drivers.map((d) => (
                            <option key={d.driverId} value={d.driverId}>
                                {d.name}
                            </option>
                        ))}
                    </select>
                    {errors.driverId && <span className="error-msg">{errors.driverId}</span>}
                </div>

                <div className="form-group">
                    <label htmlFor="vehicleId">Vehicle Name *</label>
                    <select
                        id="vehicleId"
                        className={errors.vehicleId ? "error" : ""}
                        value={vehicleId}
                        onChange={(e) => {
                            setVehicleId(e.target.value);
                            setErrors({ ...errors, vehicleId: "" });
                        }}
                    >
                        <option value="">Select Vehicle</option>
                        {vehicles.map((v) => (
                            <option key={v.vehicleId} value={v.vehicleId}>
                                {v.name}
                            </option>
                        ))}
                    </select>
                    {errors.vehicleId && <span className="error-msg">{errors.vehicleId}</span>}
                </div>

                <div className="form-group">
                    <label htmlFor="assignDate">Assignment Date *</label>
                    <input
                        type="date"
                        id="assignDate"
                        className={errors.assignDate ? "error" : ""}
                        value={assignDate}
                        onChange={(e) => {
                            setAssignDate(e.target.value);
                            setErrors({ ...errors, assignDate: "" });
                        }}
                    />
                    {errors.assignDate && <span className="error-msg">{errors.assignDate}</span>}
                </div>

                <div className="button-group">
                    <button className="save-btn" onClick={handleSubmit} disabled={isSubmitting}>
                        {isSubmitting ? "Saving..." : "Save"}
                    </button>
                    <button
                        className="cancel-btn"
                        onClick={() => navigate(CONSTANTS.ROUTES.ASSIGNMENT.LIST)}
                    >
                        Cancel
                    </button>
                </div>
            </div>
        </div>
    );
}

export default AssignmentForm;
