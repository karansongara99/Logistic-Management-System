import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import admin from '../assets/images/person.jpg'
import { AdminProfileModel } from '../models/AdminProfileModel'
import { getProfileDetails } from '../services/AdminService'
import { CONSTANTS } from '../constants/constant'
import { AdminLogout } from '../services/AuthService'
import '../assets/styles/Profile.css'

function Profile() {
  const navigate = useNavigate()
  const [profile, setProfile] = useState(AdminProfileModel)
  const [isDarkMode, setIsDarkMode] = useState(false)

  // Fetch profile data on mount
  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const data = await getProfileDetails()
        setProfile(data)
      } catch (error) {
        console.error('Error fetching profile details:', error.message)
      }
    }

    fetchProfile()
  }, [])

  // Toggle dark mode by updating body class
  const toggleTheme = () => {
    document.body.classList.toggle('dark-mode')
    setIsDarkMode(prev => !prev)
  }

  return (
    <div className='profile-container'>
      <div className='profile-page'>
        <div className='profile-card'>
          <img src={admin} alt='Profile' className='profile-img' />
          <h2>{profile.name}</h2>
          <p>Administrator</p>

          <div className='profile-info'>
            <p><strong>Email:</strong> {profile.emailId}</p>
          </div>

          <div className='button-group'>
            <button className='back-btn' onClick={() => navigate(CONSTANTS.ROUTES.HOME)}>
              ← Back to Dashboard
            </button>
            <button className='back-btn' onClick={() => AdminLogout()}>
              Logout
            </button>
            <button className='back-btn' onClick={toggleTheme}>
              {isDarkMode ? '☀️ Light Mode' : '🌙 Dark Mode'}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Profile
