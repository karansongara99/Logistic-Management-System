import React, { useEffect, useState } from "react";
import "../../assets/styles/Package/PackageForm.css";
import { useNavigate, useParams } from "react-router-dom";
import {
    getShipmentList
} from "../../services/ShipmentService";
import {
    createPackage,
    updatePackage,
    getPackageById as fetchPackageById
} from "../../services/PackageService";
import {
    getWarehouseList
} from "../../services/WarehouseService";
import {
    errorToast
} from "../../services/ToastService";
import {
    CONSTANTS
} from "../../constants/constant";

function PackageForm() {
    const navigate = useNavigate();
    const { id } = useParams(); // ✅ Get route param /package/edit/:id
    const isEdit = !!id; // ✅ Determine edit mode

    const [shipmentId, setShipmentId] = useState('');
    const [warehouseId, setWarehouseId] = useState('');
    const [shipments, setShipments] = useState([]);
    const [warehouses, setWarehouses] = useState([]);

    useEffect(() => {
        getShipments();
        getWarehouses();

        if (isEdit) {
            loadPackageData(id);
        }
    }, [id]);

    const loadPackageData = async (packageId) => {
        try {
            const packageData = await fetchPackageById(packageId);
            setShipmentId(packageData.shipmentId);
            setWarehouseId(packageData.warehouseId);
            document.getElementById("describe").value = packageData.describe;
            document.getElementById("weight").value = packageData.weight;
            document.getElementById("status").value = packageData.status;
            document.getElementById("totalBox").value = packageData.totalBox;
        } catch (error) {
            console.error("Failed to fetch package:", error);
            errorToast("Failed to load package details.");
        }
    };

    const getShipments = async () => {
        const shipments = await getShipmentList();
        setShipments(shipments);
    };

    const getWarehouses = async () => {
        const warehouses = await getWarehouseList();
        setWarehouses(warehouses);
    };

    const handleSubmit = async () => {
        try {
            const packageData = {
                shipmentId: shipmentId,
                warehouseId: warehouseId,
                describe: document.getElementById("describe").value,
                weight: document.getElementById("weight").value,
                status: document.getElementById("status").value,
                totalBox: document.getElementById("totalBox").value
            };

            if (isEdit) {
                await updatePackage(id, packageData);
            } else {
                await createPackage(packageData);
            }

            navigate(CONSTANTS.ROUTES.PACKAGE.LIST);
        } catch (error) {
            console.log(error);
            errorToast(error.response?.data || "Failed to save package. Please try again.");
        }
    };

    return (
        <div className="content">
            <div className="form-container">
                <h2>{isEdit ? "Edit Package" : "Add Package"}</h2>
                <div className="form-group">
                    <label htmlFor="shipmentId">Shipment Code *</label>
                    <select id="shipmentId" required value={shipmentId} onChange={(e) => setShipmentId(e.target.value)}>
                        <option value="">Select Shipment</option>
                        {shipments.map((shipment) => (
                            <option key={shipment.shipmentId} value={shipment.shipmentId}>
                                {shipment.shipCode}
                            </option>
                        ))}
                    </select>
                </div>

                <div className="form-group">
                    <label htmlFor="warehouseId">Warehouse Name *</label>
                    <select id="warehouseId" required value={warehouseId} onChange={(e) => setWarehouseId(e.target.value)}>
                        <option value="">Select Warehouse</option>
                        {warehouses.map((warehouse) => (
                            <option key={warehouse.warehouseId} value={warehouse.warehouseId}>
                                {warehouse.name}
                            </option>
                        ))}
                    </select>
                </div>

                <div className="form-group">
                    <label htmlFor="describe">Description *</label>
                    <input type="text" id="describe" placeholder="Enter Description" required />
                </div>

                <div className="form-group">
                    <label htmlFor="weight">Weight *</label>
                    <input type="number" id="weight" placeholder="Enter Weight" required />
                </div>

                <div className="form-group">
                    <label htmlFor="status">Status *</label>
                    <select id="status" required>
                        <option value="">Select Status</option>
                        <option value="In Transit">In Transit</option>
                        <option value="Delivered">Delivered</option>
                    </select>
                </div>

                <div className="form-group">
                    <label htmlFor="totalBox">Total Box *</label>
                    <input type="number" id="totalBox" placeholder="Enter Total Box" required />
                </div>

                <div className="button-group">
                    <button className="save-btn" onClick={handleSubmit}>Save</button>
                    <button onClick={() => navigate("/package")} className="cancel-btn">Cancel</button>
                </div>
            </div>
        </div>
    );
}

export default PackageForm;
