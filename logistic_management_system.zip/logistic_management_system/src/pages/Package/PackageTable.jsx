import React, { useEffect, useState } from "react";
import "../../assets/styles/Package/PackageTable.css";
import { useNavigate } from "react-router-dom";
import { deletePackage, getPackageList, deleteAllPackage } from "../../services/PackageService";
import { CONSTANTS } from "../../constants/constant";
import { DownloadTableExcel } from "react-export-table-to-excel";
import { useRef } from "react";

function PackageTable() {
    const navigate = useNavigate();
    const tableRef = useRef(null)
    const exportTableRef = useRef(null)
    const [packages, setPackages] = useState([]);
    const [filteredPackages, setFilteredPackages] = useState([]);
    const [searchShipmentCode, setSearchShipmentCode] = useState('');
    const [searchDescription, setSearchDescription] = useState('');

    useEffect(() => {
        getPackages();
    }, []);

    const ExportTable = () => {
        return (
            <table style={{ display: 'none' }} ref={exportTableRef}>
                <thead>
                    <tr>
                        <th>Shipment Code</th>
                        <th>Warehouse Name</th>
                        <th>Description</th>
                        <th>Weight</th>
                        <th>Status</th>
                        <th>Total Box</th>
                    </tr>
                </thead>
                <tbody>
                    {filteredPackages.map((pkg, index) => (
                        <tr key={index}>
                            <td>{pkg.shipment?.shipCode}</td>
                            <td>{pkg.warehouse?.name}</td>
                            <td>{pkg.describe}</td>
                            <td>{pkg.weight}</td>
                            <td>{pkg.status}</td>
                            <td>{pkg.totalBox}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        )
    }


    const getPackages = async () => {
        const pkgList = await getPackageList();
        setPackages(pkgList);
        setFilteredPackages(pkgList);
    };

    const handleEdit = packageId => {
        alert("Edit functionality is not implemented yet.")
        navigate(CONSTANTS.ROUTES.PACKAGE.EDIT.replace(':id', packageId));
    }
    const deleteAllPackages = async () => {
        try {
            const result = window.confirm("Are you sure you want to delete all packages?")
            if (!result) return
            await deleteAllPackage()
            getPackages()
        } catch (error) {
            console.error('Error deleting all packages:', error)
        }
    }

    const handleDelete = async id => {
        try {
            const result = window.confirm("Are you sure you want to delete this package?")
            if (!result) return
            await deletePackage(id)
            const updatedPackages = packages.filter(pkg => pkg.packageId !== id)
            setPackages(updatedPackages)
            setFilteredPackages(updatedPackages)
        } catch (error) {
            console.error('Error deleting package:', error)
        }
    }


    const handleSearch = () => {
        if (!searchShipmentCode && !searchDescription) {
            getPackages();
            return;
        }

        const filtered = packages.filter(pkg => {
            const matchesCode = pkg.shipment?.shipCode?.toLowerCase().includes(searchShipmentCode.toLowerCase());
            const matchesDescription = pkg.describe?.toLowerCase().includes(searchDescription.toLowerCase());
            return matchesCode && matchesDescription;
        });

        setFilteredPackages(filtered);
    };

    const resetSearch = () => {
        setSearchShipmentCode('');
        setSearchDescription('');
        getPackages();
    };

    return (
        <div className="content">
            <div className="container">
                {/* Search Section */}
                <div className="search-section">
                    <h3>Search Package</h3>
                    <div className="search-fields">
                        <input
                            type="text"
                            placeholder="Shipment Code"
                            value={searchShipmentCode}
                            onChange={(e) => setSearchShipmentCode(e.target.value)}
                        />
                        <input
                            type="text"
                            placeholder="Description"
                            value={searchDescription}
                            onChange={(e) => setSearchDescription(e.target.value)}
                        />
                        <button className="btn btn-search" onClick={handleSearch}>Search</button>
                        <button className="btn btn-reset" onClick={resetSearch}>Reset</button>
                    </div>
                </div>

                {/* Package List Table */}
                <div className="table-section">
                    <div className="table-header">
                        <h3>Package List</h3>
                        <div className="btn-group">
                            <button onClick={() => navigate("/packageForm")} className="btn btn-add">Add Package</button>
                            <DownloadTableExcel
                                filename='packages_table'
                                sheet='packages'
                                currentTableRef={exportTableRef.current}
                            >
                                <button className='btn btn-success'> Export excel </button>
                            </DownloadTableExcel>
                            <button onClick={deleteAllPackages} className="btn btn-delete-all">Delete All</button>
                        </div>
                    </div>

                    <table ref={tableRef}>
                        <thead>
                            <tr>
                                <th>Shipment Code</th>
                                <th>Warehouse Name</th>
                                <th>Description</th>
                                <th>Weight</th>
                                <th>Status</th>
                                <th>Total Box</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {packages.length === 0 ? (
                                <tr>
                                    <td colSpan="7" className="no-data" style={{ textAlign: "center" }}>No packages found</td>
                                </tr>
                            ) : (
                                filteredPackages.map((pkg, index) => (
                                    <tr key={index}>
                                        <td>{pkg.shipment?.shipCode || "N/A"}</td>
                                        <td>{pkg.warehouse?.name || "N/A"}</td>
                                        <td>{pkg.describe || "N/A"}</td>
                                        <td>{pkg.weight ?? "N/A"}</td>
                                        <td className={`status ${pkg.status === 'Delivered' ? 'red' : pkg.status === 'In Transit' ? 'green' : ''}`}>
                                            {pkg.status || "N/A"}
                                        </td>
                                        <td>{pkg.totalBox ?? "N/A"}</td>
                                        <td className="action-buttons">
                                            <button className="btn btn-edit" onClick={() => handleEdit(pkg.packageId)}>Edit</button>
                                            <button className="btn btn-delete" onClick={() => handleDelete(pkg.packageId)}>Delete</button>
                                        </td>
                                    </tr>
                                )))}
                        </tbody>
                    </table>
                    {ExportTable()}
                </div>
            </div>
        </div>
    );
}

export default PackageTable;
