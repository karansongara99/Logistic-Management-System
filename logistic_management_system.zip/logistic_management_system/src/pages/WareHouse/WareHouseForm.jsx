import React from "react";
import "../../assets/styles/WareHouse/WareHouseForm.css";
import { useNavigate } from "react-router-dom";
import { createWarehouse, updateWareHouse, getWarehouseById,getWarehouseList } from "../../services/WarehouseService";
import { errorToast } from "../../services/ToastService";
import { CONSTANTS } from "../../constants/constant";
import { useParams } from "react-router-dom";
import { useState } from "react";
import { useEffect } from "react";

function WareHouseForm() {
    const navigate = useNavigate();
    const { id } = useParams(); // ✅ Get route param /package/edit/:id
    const isEdit = !!id; // ✅ Determine edit mode

    const [warehouseId, setWarehouseId] = useState('');

    useEffect(() => {
        getWarehouseList();

        if (isEdit) {
            loadWarehouseData(id);
        }
    }, [id]);

    const loadWarehouseData = async (id) => {
        try {
            const warehouseData = await getWarehouseById(id);
            setWarehouseId(warehouseData.warehouseId);
            document.getElementById("warehouseName").value = warehouseData.name;
            document.getElementById("address").value = warehouseData.address;
            document.getElementById("capacity").value = warehouseData.capacity;
            document.getElementById("pincode").value = warehouseData.pincode;
            document.getElementById("contact").value = warehouseData.contactNo;
            document.getElementById("alternateContact").value = warehouseData.alternateNo;
            document.getElementById("managerName").value = warehouseData.managerName;
        } catch (error) {
            console.error("Failed to fetch warehouse:", error);
            errorToast("Failed to load warehouse details.");
        }
    };

     const handleSubmit = async () => {
            try {
                const warehouseData = {
                    name: document.getElementById("warehouseName").value,
                    address: document.getElementById("address").value,
                    capacity: document.getElementById("capacity").value,
                    pincode: document.getElementById("pincode").value,
                    contactNo: document.getElementById("contact").value,
                    alternateNo: document.getElementById("alternateContact").value,
                    managerName: document.getElementById("managerName").value
                };
                if (isEdit) {
                    await updateWareHouse(id, warehouseData);
                } else {
                    await createWarehouse(warehouseData);
                }
                navigate(CONSTANTS.ROUTES.WAREHOUSE.LIST);
            }
            catch (error) {
                console.log(error);
                errorToast(error.response?.data || "Failed to create warehouse. Please try again.");
            }
        }
    
    return (
        <div className="content">
        <div className="form-container">
            <h2>Add WareHouse</h2>
            <div className="form-group">
            <label htmlFor="warehouseName">WareHouse Name *</label>
            <input type="text" id="warehouseName" placeholder="Enter WareHouse Name" required />
            </div>
            <div className="form-group">
            <label htmlFor="address">Address *</label>
            <input type="text" id="address" placeholder="Enter Address" required />
            </div>
            <div className="form-group">
            <label htmlFor="capacity">Capacity *</label>
            <input type="text" id="capacity" placeholder="Enter Capacity" required />
            </div>
            <div className="form-group">
            <label htmlFor="pincode">Pincode *</label>
            <input type="text" id="pincode" placeholder="Enter Pincode" required />
            </div>
            <div className="form-group">
            <label htmlFor="contact">Contact *</label>
            <input type="text" id="contact" placeholder="Enter Contact" required />
            </div>
            <div className="form-group">
            <label htmlFor="alternateContact">Alternate Contact *</label>
            <input type="text" id="alternateContact" placeholder="Enter Alternate Contact" required />
            </div>
            <div className="form-group">
            <label htmlFor="managerName">Manager Name *</label>
            <input type="text" id="managerName" placeholder="Enter Manager Name" required />
            </div>
            <div className="button-group">
            <button className="save-btn" onClick={handleSubmit}>Save</button>
            <button onClick={() => navigate("/warehouse")} className="cancel-btn">Cancel</button>
            </div>
        </div>
        </div>
    );
}

export default WareHouseForm;
