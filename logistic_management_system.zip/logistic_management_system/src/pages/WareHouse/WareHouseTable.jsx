import React, { useEffect, useState } from "react";
import "../../assets/styles/WareHouse/WareHouseTable.css";
import { useNavigate } from "react-router-dom";
import { deleteAllWareHouse, deleteWareHouse, getWarehouseList } from "../../services/WarehouseService";
import { CONSTANTS } from "../../constants/constant";
import { useRef } from "react";
import { DownloadTableExcel } from "react-export-table-to-excel";

function WareHouseTable() {
    const navigate = useNavigate();
    const tableRef = useRef(null)
    const exportTableRef = useRef(null)
    const [warehouses, setWarehouses] = useState([]);
    const [filteredWarehouses, setFilteredWarehouses] = useState([]);
    const [wareHouseName, setWareHouseName] = useState('');
    const [contactNo, setContactNo] = useState('');
    const [managerName, setManagerName] = useState('');
    const [address, setAddress] = useState('');

    useEffect(() => {
        getWarehouses();
    }, []);

    const handleEdit = warehouseId => {
        const result = window.confirm("Are you sure you want to delete this warehouse?")
        if (!result) return
        navigate(CONSTANTS.ROUTES.WAREHOUSE.EDIT.replace(':id', warehouseId));
    }

    const ExportTable = () => {
        return (
            <table style={{ display: 'none' }} ref={exportTableRef}>
                <thead>
                    <tr>
                        <th>WareHouse Name</th>
                        <th>Address</th>
                        <th>Capacity</th>
                        <th>Contact</th>
                        <th>Alternate Contact</th>
                        <th>Manager Name</th>
                        <th>Pincode</th>
                    </tr>
                </thead>
                <tbody>
                    {filteredWarehouses.map((warehouse, index) => (
                        <tr key={index}>
                            <td>{warehouse.name}</td>
                            <td>{warehouse.address}</td>
                            <td>{warehouse.capacity}</td>
                            <td>{warehouse.contactNo}</td>
                            <td>{warehouse.alternateNo}</td>
                            <td>{warehouse.managerName}</td>
                            <td>{warehouse.pincode}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        )
    }


    const handleDelete = async id => {
        try {
            const result = window.confirm("Are you sure you want to delete this warehouse?")
            if (!result) return
            await deleteWareHouse(id)
            const updatedWarehouses = warehouses.filter(warehouse => warehouse.warehouseId !== id)
            setWarehouses(updatedWarehouses)
            setFilteredWarehouses(updatedWarehouses)
        } catch (error) {
            console.error('Error deleting warehouse:', error)
        }
    }

    const deleteAllWarehouses = async () => {
        try {
            const result = window.confirm("Are you sure you want to delete all warehouses?")
            if (!result) return
            await deleteAllWareHouse()
            getWarehouses()
        } catch (error) {
            console.error('Error deleting all warehouses:', error)
        }
    }
    const getWarehouses = async () => {
        try {
            const data = await getWarehouseList();
            setWarehouses(data);
            setFilteredWarehouses(data);
        } catch (error) {
            console.error('Error fetching warehouse list:', error)
        }
    };

    const handleSearch = () => {
        const filtered = warehouses.filter(warehouse => {
            const matchesName = warehouse.name.toLowerCase().includes(wareHouseName.toLowerCase());
            const matchesContact = warehouse.contactNo.toLowerCase().includes(contactNo.toLowerCase());
            const matchesManager = warehouse.managerName.toLowerCase().includes(managerName.toLowerCase());
            const matchesAddress = warehouse.address.toLowerCase().includes(address.toLowerCase());
            return matchesName && matchesContact && matchesManager && matchesAddress;
        });
        setFilteredWarehouses(filtered);
    };

    const handleReset = () => {
        setWareHouseName('');
        setContactNo('');
        setManagerName('');
        setAddress('');
        setFilteredWarehouses(warehouses);
    };

    return (
        <div className="content">
            <div className="container">
                {/* Search Section */}
                <div className="search-section">
                    <h3>Search WareHouse</h3>
                    <div className="search-fields">
                        <input
                            type="text"
                            id="wareHouseName"
                            placeholder="WareHouse Name"
                            value={wareHouseName}
                            onChange={(e) => setWareHouseName(e.target.value)}
                        />
                        <input
                            type="text"
                            id="contactNo"
                            placeholder="Contact No"
                            value={contactNo}
                            onChange={(e) => setContactNo(e.target.value)}
                        />
                        <input
                            type="text"
                            id="managerName"
                            placeholder="Manager Name"
                            value={managerName}
                            onChange={(e) => setManagerName(e.target.value)}
                        />
                        <input
                            type="text"
                            id="address"
                            placeholder="Address"
                            value={address}
                            onChange={(e) => setAddress(e.target.value)}
                        />
                        <button className="btn btn-search" onClick={handleSearch}>Search</button>
                        <button className="btn btn-reset" onClick={handleReset}>Reset</button>
                    </div>
                </div>

                {/* Warehouse List Table */}
                <div className="table-section">
                    <div className="table-header">
                        <h3>WareHouse List</h3>
                        <div className="btn-group">
                            <button onClick={() => navigate("/wareHouseForm")} className="btn btn-add">Add WareHouse</button>
                            <DownloadTableExcel
                                filename='warehouses_table'
                                sheet='warehouses'
                                currentTableRef={exportTableRef.current}
                            >
                                <button className='btn btn-success'> Export excel </button>
                            </DownloadTableExcel>
                            <button onClick={deleteAllWarehouses} className="btn btn-delete-all">Delete All</button>
                        </div>
                    </div>
                    <table ref={tableRef}>
                        <thead>
                            <tr>
                                <th>WareHouse Name</th>
                                <th>Address</th>
                                <th>Capacity</th>
                                <th>Contact</th>
                                <th>Alternate Contact</th>
                                <th>Manager Name</th>
                                <th>Pincode</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {warehouses.length === 0 ? (
                                <tr>
                                    <td colSpan="8" className="no-data" style={{ textAlign: "center" }}>No warehouses found</td>
                                </tr>
                            ) : (
                                filteredWarehouses.map((warehouse, index) => (
                                    <tr key={index}>
                                        <td>{warehouse.name}</td>
                                        <td>{warehouse.address}</td>
                                        <td>{warehouse.capacity}</td>
                                        <td>{warehouse.contactNo}</td>
                                        <td>{warehouse.alternateNo}</td>
                                        <td>{warehouse.managerName}</td>
                                        <td>{warehouse.pincode}</td>
                                        <td className="action-buttons">
                                            <button className="btn btn-edit" onClick={() => handleEdit(warehouse.warehouseId)}>Edit</button>
                                            <button className="btn btn-delete" onClick={() => handleDelete(warehouse.warehouseId)}>Delete</button>
                                        </td>
                                    </tr>
                                )))}
                        </tbody>
                    </table>
                    {ExportTable()}
                </div>
            </div>
        </div>
    );
}

export default WareHouseTable;
