import React from "react";
import "../../assets/styles/Route/RouteTable.css";
import { useNavigate } from "react-router-dom";

function RouteTable() {
    const navigate = useNavigate();
    return (
        <div className="content">
        <div className="container">
            {/* Search Section */}
            <div className="search-section">
            <h3>Search Routes</h3>
            <div className="search-fields">
                <input type="text" id="vehicleName" placeholder="Vehicle Name" />
                <input type="text" id="arrival" placeholder="Arrival" />
                <input type="text" id="departure" placeholder="Departure" />
                <button className="btn btn-search">Search</button>
                <button className="btn btn-reset">Reset</button>
            </div>
            </div>
            {/* Route List Table */}
            <div className="table-section">
            <div className="table-header">
                <h3>Route List</h3>
                <button onClick={() => navigate("/routeForm")} className="btn btn-add">Add Route</button>
            </div>
            <div className="table-controls">
                <label>
                Show
                <select id="entriesPerPage">
                    <option value={10}>10</option>
                    <option value={25}>25</option>
                    <option value={50}>50</option>
                </select>
                entries
                </label>
            </div>
            <table>
                <thead>
                <tr>
                    <th>Vehicle Name</th>
                    <th>Driver Name</th>
                    <th>Arrival</th>
                    <th>Departure</th>
                    <th>Distance</th>
                    <th>Estimated Time</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>Vehicle 1</td>
                    <td>Driver Name 1</td>
                    <td>Arrival 1</td>
                    <td>Departure 1</td>
                    <td>Distance 1</td>
                    <td>02:30</td>
                    <td className="action-buttons">
                    <button className="btn btn-edit">Edit</button>
                    <button className="btn btn-delete">Delete</button>
                    </td>
                </tr>
                <tr>
                    <td>Vehicle 2</td>
                    <td>Driver Name 2</td>
                    <td>Arrival 2</td>
                    <td>Departure 2</td>
                    <td>Distance 2</td>
                    <td>02:30</td>
                    <td className="action-buttons">
                    <button className="btn btn-edit">Edit</button>
                    <button className="btn btn-delete">Delete</button>
                    </td>
                </tr>
                <tr>
                    <td>Vehicle 3</td>
                    <td>Driver Name 3</td>
                    <td>Arrival 3</td>
                    <td>Departure 3</td>
                    <td>Distance 3</td>
                    <td>02:30</td>
                    <td className="action-buttons">
                    <button className="btn btn-edit">Edit</button>
                    <button className="btn btn-delete">Delete</button>
                    </td>
                </tr>
                </tbody>
            </table>
            </div>
        </div>
        </div>
    );
}

export default RouteTable;
