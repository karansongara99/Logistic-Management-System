import React from "react";
import "../../assets/styles/Route/RouteForm.css";
import { useNavigate } from "react-router-dom";

function RouteForm() {
    const navigate = useNavigate();
    return (
        <div className="content">
        <div className="form-container">
            <h2>Add Route</h2>
            <div className="form-group">
            <label htmlFor="vehicleName">Vehicle Name *</label>
            <select id="vehicleName" required>
                <option value="">Select Vehicle</option>
                <option value="Flight">Flight</option>
                <option value="Cargo Ship">Cargo Ship</option>
                <option value="Truck">Truck</option>
            </select>
            </div>
            <div className="form-group">
            <label htmlFor="driverName">Driver Name *</label>
            <select id="driverName" required>
                <option value="">Select Driver</option>
                <option value="Driver 1">Driver 1</option>
                <option value="Driver 2">Driver 2</option>
                <option value="Driver 3">Driver 3</option>
            </select>
            </div>
            <div className="form-group">
            <label htmlFor="arrival">Arrival *</label>
            <input type="text" id="arrival" placeholder="Enter Arrival" required />
            </div>
            <div className="form-group">
            <label htmlFor="departure">Departure *</label>
            <input type="text" id="departure" placeholder="Enter Departure" required />
            </div>
            <div className="form-group">
            <label htmlFor="distance">Distance *</label>
            <input type="text" id="distance" placeholder="Enter Distance" required />
            </div>
            <div className="form-group">
            <label htmlFor="estimatedTime">Estimated Time *</label>
            <input type="time" id="estimatedTime" placeholder="Enter Estimated Time" required />
            </div>
            <div className="button-group">
            <button className="save-btn">Save</button>
            <button onClick={() => navigate("/route")} className="cancel-btn">Cancel</button>
            </div>
        </div>
        </div>
    );
}

export default RouteForm;
