import React, { useState } from 'react';
import '../../assets/styles/Auth/Login.css';
import { useNavigate } from 'react-router-dom';
import { AdminAuthModel } from '../../models/AdminAuthModel';
import { AdminLogin } from '../../services/AuthService';
import { CONSTANTS } from '../../constants/constant';
import { errorToast } from '../../services/ToastService';

function Login() {
  const navigate = useNavigate();
  const [adminAuthState, setAdminAuthState] = useState(AdminAuthModel);

  const handleLogin = async () => {
    try {
      const result = await AdminLogin(adminAuthState.emailId, adminAuthState.password);
      if (result) {
        navigate(CONSTANTS.ROUTES.HOME);
      }
    } catch (error) {
      errorToast(error.message);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setAdminAuthState((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  return (
    <div className='login-wrapper'>
      <div className='login-card'>
        <h1 className='login-title'>Eagle Logistics Admin</h1>
        <p className='login-subtitle'>Sign in to continue</p>

        <input
          type='text'
          name='emailId'
          placeholder='Email address'
          value={adminAuthState.emailId}
          onChange={handleChange}
          className='login-input'
        />
        <input
          type='password'
          name='password'
          placeholder='Password'
          value={adminAuthState.password}
          onChange={handleChange}
          className='login-input'
        />

        <button className='login-btn' onClick={handleLogin}>
          Login
        </button>

        <button className='register-btn' onClick={() => navigate(CONSTANTS.ROUTES.REGISTER)}>
          Go to Register
        </button>
      </div>
    </div>
  );
}

export default Login;
