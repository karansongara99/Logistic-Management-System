import React, { useState } from 'react'
import '../../assets/styles/Auth/Register.css'
import { useNavigate } from 'react-router-dom'
import { CONSTANTS } from '../../constants/constant'
import { AdminRegister } from '../../services/AuthService'
import { adminRegisterModel } from '../../models/AdminRegisterModel'
import { errorToast, successToast } from '../../services/ToastService'

function Register () {
  const navigate = useNavigate()

  const [adminRegisterState, setAdminRegisterState] = useState(adminRegisterModel);

  const handleRegister = async () => {
    try{
      const response = await AdminRegister(adminRegisterState.name, adminRegisterState.emailId, adminRegisterState.password);
      if (response) {
        successToast(response.message);
        navigate(CONSTANTS.ROUTES.LOGIN);

      }
    }
    catch (error) {
      errorToast(error.message);
    }
  }

  const handleChange = (e) => {
    const { name, value } = e.target;
    setAdminRegisterState((prevState) => ({
      ...prevState,
      [name]: value
    }));
  }

  return (
    <div className='register-main'>
      <div className='register'>
        <h1>Eagle Logistics Admin</h1>
        <h2>Create an account</h2>
          <input type='text' placeholder='Name' name='name' value={adminRegisterState.name} onChange={handleChange}/>
          <input type='email' placeholder='Email' name='emailId' value={adminRegisterState.emailId} onChange={handleChange}/>
          <input type='password' placeholder='Password' name='password' value={adminRegisterState.password} onChange={handleChange}/>
          <button type='submit' onClick={() => handleRegister()}>
            Register
          </button>
      </div>
    </div>
  )
}

export default Register
