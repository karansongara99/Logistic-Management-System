import React from "react";
import "../../assets/styles/Customer/CustomerForm.css";
import { useNavigate } from "react-router-dom";

function CustomerForm() {
    const navigate = useNavigate();
    return (
        <div className="content">
        <div className="form-container">
            <h2>Add Customer</h2>
            <div className="form-group">
            <label htmlFor="fullName">Full Name *</label>
            <input type="text" id="fullName" placeholder="Enter Full Name" required />
            </div>
            <div className="form-group">
            <label htmlFor="contactNo">Contact No *</label>
            <input type="tel" id="contactNo" placeholder="Enter Contact Number" required />
            </div>
            <div className="form-group">
            <label htmlFor="address">Address *</label>
            <input type="text" id="address" placeholder="Enter Address" required />
            </div>
            <div className="form-group">
            <label htmlFor="emailId">Email ID *</label>
            <input type="email" id="emailId" placeholder="Enter Email ID" required />
            </div>
            <div className="form-group">
            <label htmlFor="alternateNo">Alternate No *</label>
            <input type="tel" id="alternateNo" placeholder="Enter Alternate Number" required />
            </div>
            <div className="form-group">
            <label htmlFor="pincode">Pincode *</label>
            <input type="text" id="pincode" placeholder="Enter Pincode" required />
            </div>
            <div className="form-group">
            <label htmlFor="gstNo">GST No *</label>
            <input type="text" id="gstNo" placeholder="Enter GST No" required />
            </div>
            <div className="button-group">
            <button className="save-btn">Save</button>
            <button onClick={() => navigate("/customer")} className="cancel-btn">Cancel</button>
            </div>
        </div>
        </div>
    );
}

export default CustomerForm;
