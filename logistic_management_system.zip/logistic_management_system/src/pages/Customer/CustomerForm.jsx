import React, { useEffect, useState } from "react";
import "../../assets/styles/Customer/CustomerForm.css";
import { useNavigate, useParams } from "react-router-dom";
import {
    getCustomerById,
    updateCustomer,
    createCustomer,
} from "../../services/CustomerService";
import { errorToast, successToast } from "../../services/ToastService";
import { CONSTANTS } from "../../constants/constant";
import { customerModel } from "../../models/CustomerModel";

const CustomerForm = () => {
    const navigate = useNavigate();
    const { id: customerId } = useParams();
    const [formData, setFormData] = useState({ ...customerModel });

    useEffect(() => {
    if (customerId) {
        loadCustomer(customerId);
    }
}, [customerId]);

const loadCustomer = async (id) => {
    try {
        const data = await getCustomerById(id);
        const formatDate = (dateString) => {
            if (!dateString) return "";
            const date = new Date(dateString);
            return date.toISOString().split("T")[0];
        };

        setFormData({
            fullName: data.fullName || "",
            contactNo: data.contactNo || "",
            emailId: data.emailId || "",
            address: data.address || "",
            alternateNo: data.alternateNo || "",
            pincode: data.pincode || "",
            gstno: data.gstno || "",
            isActive: data.isActive || true,
            id: data.id || null,
        });
    } catch (error) {
        console.error("Failed to load customer", error);
        errorToast("Failed to load customer");
    }
};

const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
        ...prev,
        [name]: value,
    }));
};

const handleSave = async () => {
    try {
        if (
            !formData.fullName ||
            !formData.contactNo ||
            !formData.emailId ||
            !formData.address ||
            !formData.alternateNo ||
            !formData.pincode ||
            !formData.gstno ||
            !formData.isActive
        ) {
            errorToast("Please fill all required fields.");
            return;
        }

        const customerPayload = {
            ...formData,
        };

        if (customerId) {
            await updateCustomer(customerId, customerPayload);
            successToast("Customer updated successfully");
        } else {
            await createCustomer(customerPayload);
            successToast("Customer created successfully");
        }

        navigate(CONSTANTS.ROUTES.CUSTOMER.LIST);
    } catch (error) {
        console.error("Error saving customer:", error);
        const errorMsg = error?.response?.data?.message || "Failed to save customer";
        errorToast(errorMsg);
    }
};

return (
    <div className="content">
        <div className="form-container">
            <h2>{customerId ? "Edit Customer" : "Add Customer"}</h2>
            <div className="form-group">
                <label htmlFor="fullName">Full Name *</label>
                <input type="text" id="fullName" value={formData.fullName} onChange={handleChange} name="fullName" placeholder="Enter Full Name" required />
            </div>
            <div className="form-group">
                <label htmlFor="contactNo">Contact No *</label>
                <input type="tel" id="contactNo" value={formData.contactNo} onChange={handleChange} name="contactNo" placeholder="Enter Contact Number" required />
            </div>
            <div className="form-group">
                <label htmlFor="address">Address *</label>
                <input type="text" id="address" value={formData.address} onChange={handleChange} name="address" placeholder="Enter Address" required />
            </div>
            <div className="form-group">
                <label htmlFor="emailId">Email ID *</label>
                <input type="email" id="emailId" value={formData.emailId} onChange={handleChange} name="emailId" placeholder="Enter Email ID" required />
            </div>
            <div className="form-group">
                <label htmlFor="alternateNo">Alternate No *</label>
                <input type="tel" id="alternateNo" value={formData.alternateNo} onChange={handleChange} name="alternateNo" placeholder="Enter Alternate Number" required />
            </div>
            <div className="form-group">
                <label htmlFor="pincode">Pincode *</label>
                <input type="text" id="pincode" value={formData.pincode} onChange={handleChange} name="pincode" placeholder="Enter Pincode" required />
            </div>
            <div className="form-group">
                <label htmlFor="gstno">GST No *</label>
                <input type="text" id="gstno" value={formData.gstno} onChange={handleChange} name="gstno" placeholder="Enter GST No" required />
            </div>
            <div className="form-group">
                <label className="checkbox-label">
                    IsStatus 
                    <input 
                        type="checkbox" 
                        checked={formData.isActive} 
                        onChange={(e) => setFormData({...formData, isActive: e.target.checked})} 
                        name="isActive"
                        className="checkbox-input"
                    />
                    <span className="checkbox-custom"></span>
                </label>
            </div>
            <div className="button-group">
                <button className="save-btn" onClick={handleSave}>Save</button>
                <button onClick={() => navigate(CONSTANTS.ROUTES.CUSTOMER.LIST)} className="cancel-btn">Cancel</button>
            </div>
        </div>
    </div>
);

};

export default CustomerForm;
