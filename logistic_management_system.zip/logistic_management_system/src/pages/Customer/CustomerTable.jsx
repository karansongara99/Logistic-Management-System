import React, { useEffect, useState } from 'react';
import '../../assets/styles/Customer/CustomerTable.css';
import { useNavigate } from 'react-router-dom';
import {
  customerSoftDelete,
  getCustomerPagination,
  searchCustomers,
  deleteAllCustomer,
  customerHardDelete
} from '../../services/CustomerService';

function CustomerTable() {
  const navigate = useNavigate();
  const [customerDataResponse, setCustomerDataResponse] = useState({});
  const [page, setPage] = useState(1);
  const [pageSize] = useState(5);
  const [totalPages, setTotalPages] = useState([1]);
  const [search, setSearch] = useState({ fullName: '', contactNo: '' });

  useEffect(() => {
    if (search.fullName || search.contactNo) {
      handleSearch();
    } else {
      getCustomers();
    }
  }, [page]);

  const deleteAllCustomers = async () => {
    try {
      const result = window.confirm("Are you sure you want to delete all customers?")
      if (!result) return
      await deleteAllCustomer()
      getCustomers()
    } catch (error) {
      console.error('Error deleting all customers:', error)
    }
  }

  const getCustomers = async () => {
    try {
      const response = await getCustomerPagination(page, pageSize);
      setCustomerDataResponse(response);
      setTotalPages(
        Array.from({ length: response.totalPages }, (_, i) => i + 1)
      );
    } catch (error) {
      console.error('Failed to fetch customers:', error);
    }
  };

  const handleSearch = async () => {
    try {
      const response = await searchCustomers(search.fullName, search.contactNo);
      setCustomerDataResponse(response);
      setTotalPages([1]); 
      setPage(1);
    } catch (error) {
      console.error('Search failed:', error);
    }
  };

  const handleReset = async () => {
    const result = window.confirm("Are you sure you want to reset?")
    if (!result) return
    setSearch({ fullName: '', contactNo: '' });
    setPage(1);
    await getCustomers();
  };

  const handlePageChange = (newPage) => {
    if (newPage < 1 || newPage > totalPages.length) return;
    setPage(newPage);
  };

  const handleSoftDelete = async (customerId) => {
    try {
      const result = window.confirm("Are you sure you want to delete this customer?")
      if (!result) return
      await customerSoftDelete(customerId);
      if (search.fullName || search.contactNo) {
        await handleSearch();
      } else {
        await getCustomers();
      }
    } catch (error) {
      console.error('Error deleting customer:', error);
    }
  };

  const handleHardDelete = async (customerId) => {
    try {
      const result = window.confirm("Are you sure you want to delete this customer?")
      if (!result) return
      await customerHardDelete(customerId);
      if (search.fullName || search.contactNo) {
        await handleSearch();
      } else {
        await getCustomers();
      }
    } catch (error) {
      console.error('Error deleting customer:', error);
    }
  };

  return (
    <div className='content'>
      <div className='container'>
        {/* Search Section */}
        <div className='search-section'>
          <h3>Search Customer</h3>
          <div className='search-fields'>
            <input
              type='text'
              placeholder='Full Name'
              value={search.fullName}
              onChange={e => setSearch({ ...search, fullName: e.target.value })}
            />
            <input
              type='text'
              placeholder='Contact No'
              value={search.contactNo}
              onChange={e => setSearch({ ...search, contactNo: e.target.value })}
            />
            <button className='btn btn-search' onClick={handleSearch}>Search</button>
            <button className='btn btn-reset' onClick={handleReset}>Reset</button>
          </div>
        </div>

        {/* Customer List Table */}
        <div className='table-section'>
          <div className='table-header'>
            <h3>Customer List</h3>
            <div className='btn-group'>
              <button
                onClick={() => navigate('/customerForm')}
                className='btn btn-add'
              >
                Add Customer
              </button>
              <button
                onClick={deleteAllCustomers}
                className='btn btn-delete-all'
              >
                Delete All
              </button>
            </div>
          </div>
          <br />
          <table>
            <thead>
              <tr>
                <th>Full Name</th>
                <th>Contact No</th>
                <th>Address</th>
                <th>EmailID</th>
                <th>Alternate No</th>
                <th>Pincode</th>
                <th>GST No</th>
                <th>IsActive</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {customerDataResponse?.data?.length > 0 ? (
                customerDataResponse.data.map((customer, index) => (
                  <tr key={customer.customerId || index}>
                    <td>{customer.fullName}</td>
                    <td>{customer.contactNo}</td>
                    <td>{customer.address}</td>
                    <td>{customer.emailId}</td>
                    <td>{customer.alternateNo}</td>
                    <td>{customer.pincode}</td>
                    <td>{customer.gstno}</td>
                    <td className={customer.isActive ? 'status-active' : 'status-inactive'}>
                      {customer.isActive ? 'Yes' : 'No'}
                    </td>
                    <td className='action-buttons'>
                      <button className='btn btn-edit'>Edit</button>
                      <button
                        className='soft-delete'
                        onClick={() => handleSoftDelete(customer.customerId)}
                      >
                        S 🗑
                      </button>
                      <button
                        className='hard-delete'
                        onClick={() => handleHardDelete(customer.customerId)}
                      >
                        H 🗑
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="9" style={{ textAlign: 'center' }}>No customers found.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <br />
        <div className='pagination'>
          <a href='#' onClick={() => handlePageChange(page - 1)}>&laquo;</a>
          {totalPages.map(p => (
            <a
              key={p}
              href='#'
              className={p === page ? 'active' : ''}
              onClick={() => handlePageChange(p)}
            >
              {p}
            </a>
          ))}
          <a href='#' onClick={() => handlePageChange(page + 1)}>&raquo;</a>
        </div>
      </div>
    </div>
  );
}

export default CustomerTable;
