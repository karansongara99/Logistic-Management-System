import React, { useEffect, useState } from "react";
import "../../assets/styles/Driver/DriverTable.css";
import { useNavigate } from "react-router-dom";
import { deleteDriver, deleteAllDriver, getDriverList } from "../../services/DriverService";
import { formatDate } from "../../utils/date";
import { CONSTANTS } from "../../constants/constant";

function DriverTable() {
    const navigate = useNavigate();
    const [drivers, setDrivers] = useState([]);
    const [filteredDrivers, setFilteredDrivers] = useState([]);
    const [searchDriverName, setSearchDriverName] = useState('');
    const [searchPhoneNumber, setSearchPhoneNumber] = useState('');

    useEffect(() => {
        getDrivers();
    }, []);

    const handleEdit = driverId => {
        alert("Edit driver with ID: ");
        navigate(CONSTANTS.ROUTES.DRIVER.EDIT.replace(':id', driverId));
    }

    const getDrivers = async () => {
        const drivers = await getDriverList();
        setDrivers(drivers);
        setFilteredDrivers(drivers);
    };

    const handleDelete = async id => {
        try {
            const result = window.confirm("Are you sure you want to delete this driver?")
            if (!result) return
            await deleteDriver(id)
            const updatedDrivers = drivers.filter(driver => driver.driverId !== id)
            setDrivers(updatedDrivers)
            setFilteredDrivers(updatedDrivers)
        } catch (error) {
            console.error('Error deleting driver:', error)
        }
    }

    const handleSearch = () => {
        if (!searchDriverName && !searchPhoneNumber) {
            getDrivers();
            return;
        }

        const filtered = drivers.filter(driver => {
            const matchesName = driver.name?.toLowerCase().includes(searchDriverName.toLowerCase());
            const matchesPhone = driver.contactNo?.toLowerCase().includes(searchPhoneNumber.toLowerCase());
            return matchesName && matchesPhone;
        });

        setFilteredDrivers(filtered);
    };

    const deleteAllDrivers = async () => {
        try {
            const result = window.confirm("Are you sure you want to delete all drivers?")
            if (!result) return
            await deleteAllDriver()
            getDrivers()
        } catch (error) {
            console.error('Error deleting all drivers:', error)
        }
    }

    const resetSearch = () => {
        setSearchDriverName('');
        setSearchPhoneNumber('');
        getDrivers();
    };

    return (
        <div className="content">
            <div className="container">
                {/* Search Section */}
                <div className="search-section">
                    <h3>Search Driver</h3>
                    <div className="search-fields">
                        <input
                            type="text"
                            placeholder="Driver Name"
                            value={searchDriverName}
                            onChange={(e) => setSearchDriverName(e.target.value)}
                        />
                        <input
                            type="text"
                            placeholder="Phone Number"
                            value={searchPhoneNumber}
                            onChange={(e) => setSearchPhoneNumber(e.target.value)}
                        />
                        <button className="btn btn-search" onClick={handleSearch}>Search</button>
                        <button className="btn btn-reset" onClick={resetSearch}>Reset</button>
                    </div>
                </div>

                {/* Driver List Table */}
                <div className="table-section">
                    <div className="table-header">
                        <h3>Driver List</h3>
                        <div className="btn-group">
                            <button onClick={() => navigate("/driverForm")} className="btn btn-add">Add Driver</button>
                            <button onClick={() => navigate("/driverForm")} className="btn btn-export">Export</button>
                            <button onClick={deleteAllDrivers} className="btn btn-delete-all">Delete All</button>
                        </div>
                    </div>
                    <table>
                        <thead>
                            <tr>
                                <th>Driver Name</th>
                                <th>Vehicle Name</th>
                                <th>Phone Number</th>
                                <th>Address</th>
                                <th>Photo</th>
                                <th>License Number</th>
                                <th>Alternate Number</th>
                                <th>Renewal Date</th>
                                <th>DOB</th>
                                <th>Age</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredDrivers.length === 0 ? (
                                <tr>
                                    <td colSpan="5" className="no-data" style={{ textAlign: "center" }}>No drivers found</td>
                                </tr>
                            ) : (
                                filteredDrivers.map((driver, index) => (
                                    <tr key={index}>
                                        <td>{driver.name}</td>
                                        <td>{driver.vehicle.name}</td>
                                        <td>{driver.contactNo}</td>
                                        <td>{driver.address}</td>
                                        <td>
                                            {driver.photo ? (
                                                <img src={driver.photo} alt="Driver" width="50" height="50" />
                                            ) : (
                                                "N/A"
                                            )}
                                        </td>
                                        <td>{driver.licenceNo}</td>
                                        <td>{driver.alternateNo}</td>
                                        <td>{formatDate(driver.renewDate)}</td>
                                        <td>{formatDate(driver.dob)}</td>
                                        <td>{driver.age}</td>
                                        <td className="action-buttons">
                                            <button className="btn btn-edit" onClick={() => handleEdit(driver.driverId)}>Edit</button>
                                            <button className="btn btn-delete" onClick={() => handleDelete(driver.driverId)}>Delete</button>
                                        </td>
                                    </tr>
                                )))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}

export default DriverTable;
