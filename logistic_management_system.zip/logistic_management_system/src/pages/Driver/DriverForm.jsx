import React, { useEffect, useState } from "react";
import "../../assets/styles/Driver/DriverForm.css";
import { useNavigate } from "react-router-dom";
import { createDriver, updateDriver, getDriverById } from "../../services/DriverService";
import { errorToast } from "../../services/ToastService";
import { CONSTANTS } from "../../constants/constant";
import { getVehicleList } from "../../services/VehicleService";
import { useParams } from "react-router-dom";

function DriverForm() {

    const [selectedFile, setSelectedFile] = useState(null)
    const [base64IMG, setBase64IMG] = useState('')
    const [vehicles, setVehicles] = React.useState([]);
    const [vehicleId, setVehicleId] = React.useState('');
    const { id } = useParams(); // ✅ Get route param /package/edit/:id
    const isEdit = !!id; // ✅ Determine edit mode

    const convertToBase64 = () => {
        const reader = new FileReader()

        reader.readAsDataURL(selectedFile)

        reader.onload = () => {
            console.log('called: ', reader)
            setBase64IMG(reader.result)
        }
    }

    useEffect(() => {
        getVehicles();
    }, []);

    const getVehicles = async () => {
        const vehicles = await getVehicleList();
        setVehicles(vehicles);
    };

    useEffect(() => {
        if (!selectedFile) return
        convertToBase64()
    }, [selectedFile]);

    useEffect(() => {
        if (isEdit) {
            loadDriverData(id);
        }
    }, [id]);

    const loadDriverData = async (driverId) => {
        try {
            const driverData = await getDriverById(driverId);
            setVehicleId(driverData.vehicleId);
            document.getElementById("driverName").value = driverData.name;
            document.getElementById("phoneNumber").value = driverData.contactNo;
            document.getElementById("address").value = driverData.address;
            document.getElementById("licenseNumber").value = driverData.licenceNo;
            document.getElementById("alternateNumber").value = driverData.alternateNo;
            document.getElementById("renewalDate").value = driverData.renewDate;
            document.getElementById("dob").value = driverData.dob;
            document.getElementById("age").value = driverData.age;
        } catch (error) {
            console.error("Failed to fetch driver:", error);
            errorToast("Failed to load driver details.");
        }
    };

    const handleSubmit = async () => {
        try {
            const driverData = {
                name: document.getElementById("driverName").value,
                vehicleId: vehicleId,
                contactNo: document.getElementById("phoneNumber").value,
                address: document.getElementById("address").value,
                photo: base64IMG,
                licenceNo: document.getElementById("licenseNumber").value,
                alternateNo: document.getElementById("alternateNumber").value,
                renewDate: document.getElementById("renewalDate").value,
                dob: document.getElementById("dob").value,
                age: document.getElementById("age").value
            };
            console.log(driverData);
            if (isEdit) {
                await updateDriver(id, driverData);
            } else {
                await createDriver(driverData);
            }
            navigate(CONSTANTS.ROUTES.DRIVER.LIST);
        }
        catch (error) {
            console.log(error);
            errorToast(error.response?.data || "Failed to create driver. Please try again.");
        }
    }
    const navigate = useNavigate();
    return (
        <div className="content">
            <div className="form-container">
                <h2>Add Driver</h2>
                <div className="form-group">
                    <label htmlFor="driverName">Driver Name *</label>
                    <input type="text" id="driverName" placeholder="Enter Driver Name" required />
                </div>
                <div className="form-group">
                    <label htmlFor="driverId">Vehicle Name *</label>
                    <select id="driverId" onChange={(e) => setVehicleId(e.target.value)}>
                        <option value="">Select Vehicle</option>
                        {vehicles.map((vehicle) => (
                            <option key={vehicle.vehicleId} value={vehicle.vehicleId}>
                                {vehicle.name}
                            </option>
                        ))}
                    </select>
                </div>
                <div className="form-group">
                    <label htmlFor="phoneNumber">Phone Number *</label>
                    <input type="tel" id="phoneNumber" placeholder="Enter Phone Number" required />
                </div>
                <div className="form-group">
                    <label htmlFor="address">Address *</label>
                    <input type="text" id="address" placeholder="Enter Address" required />
                </div>
                <div className="form-group">
                    <label htmlFor="avatar">Driver Image *</label>
                    <input type="file" id="avatar" onChange={(e) => setSelectedFile(e.target.files[0])} />
                </div>
                <div className="form-group">
                    <label htmlFor="licenseNumber">License Number *</label>
                    <input type="text" id="licenseNumber" placeholder="Enter License Number" required />
                </div>
                <div className="form-group">
                    <label htmlFor="alternateNumber">Alternate Number *</label>
                    <input type="tel" id="alternateNumber" placeholder="Enter Alternate Number" required />
                </div>
                <div className="form-group">
                    <label htmlFor="renewalDate">Renewal Date *</label>
                    <input type="date" id="renewalDate" placeholder="Enter Renewal Date" required />
                </div>
                <div className="form-group">
                    <label htmlFor="dob">Date of Birth *</label>
                    <input type="date" id="dob" placeholder="Enter Date of Birth" required />
                </div>
                <div className="form-group">
                    <label htmlFor="age">Age *</label>
                    <input type="number" id="age" placeholder="Enter Age" required />
                </div>
                <div className="button-group">
                    <button className="save-btn" onClick={handleSubmit}>Save</button>
                    <button onClick={() => navigate("/driver")} className="cancel-btn">Cancel</button>
                </div>
            </div>
        </div>
    );
}

export default DriverForm;
