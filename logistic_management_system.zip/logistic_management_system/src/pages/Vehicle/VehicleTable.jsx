import React, { useEffect, useState } from 'react'
import '../../assets/styles/Vehicle/VehicleTable.css'
import { useNavigate } from 'react-router-dom'
import {
  deleteAllVehicle,
  deleteVehicle,
  getVehicleList
} from '../../services/VehicleService'
import { CONSTANTS } from '../../constants/constant'
import { DownloadTableExcel } from 'react-export-table-to-excel'
import { useRef } from 'react'

function VehicleTable () {
  const navigate = useNavigate()
  const tableRef = useRef(null)
  const exportTableRef = useRef(null)
  const [vehicles, setVehicles] = useState([])
  const [filteredVehicles, setFilteredVehicles] = useState([])
  const [vehicleName, setVehicleName] = useState('')
  const [vehicleType, setVehicleType] = useState('')
  const [vehicleNumber, setVehicleNumber] = useState('')

  const handleDelete = async id => {
    try {
      await deleteVehicle(id)
      const updatedVehicles = vehicles.filter(
        vehicle => vehicle.vehicleId !== id
      )
      setVehicles(updatedVehicles)
      setFilteredVehicles(updatedVehicles)
    } catch (error) {
      console.error('Error deleting vehicle:', error)
    }
  }

  useEffect(() => {
    getVehicles()
  }, [])

  const handleEdit = vehicleId => {
    navigate(CONSTANTS.ROUTES.VEHICLE.EDIT.replace(':id', vehicleId))
  }

  const getVehicles = async () => {
    const data = await getVehicleList()
    setVehicles(data)
    setFilteredVehicles(data) 
  }

  const handleSearch = () => {
    const filtered = vehicles.filter(vehicle => {
      const nameMatch = vehicle.name
        .toLowerCase()
        .includes(vehicleName.toLowerCase())
      const typeMatch = vehicle.type
        .toLowerCase()
        .includes(vehicleType.toLowerCase())
      const numberMatch = vehicle.vehicleNo
        .toLowerCase()
        .includes(vehicleNumber.toLowerCase())
      return nameMatch && typeMatch && numberMatch
    })
    setFilteredVehicles(filtered)
  }

  const deleteAllVehicles = async () => {
    try {
      if (window.confirm('Are you sure you want to delete all vehicles?')) {
        await deleteAllVehicle()
        getVehicles()
      }
    } catch (error) {
      console.error('Error deleting all vehicles:', error)
    }
  }

  const handleReset = () => {
    setVehicleName('')
    setVehicleType('')
    setVehicleNumber('')
    setFilteredVehicles(vehicles)
  }

  const ExportTable = () => {
    return (
      <table style={{ display: 'none' }} ref={exportTableRef}>
        <thead>
          <tr>
            <th>Vehicle Name</th>
            <th>Vehicle Type</th>
            <th>Vehicle Number</th>
            <th>Vehicle Status</th>
            <th>Warehouse Name</th>
          </tr>
        </thead>
        <tbody>
          {filteredVehicles.map((vehicle, index) => (
            <tr key={index}>
              <td>{vehicle.name}</td>
              <td>{vehicle.type}</td>
              <td>{vehicle.vehicleNo}</td>
              <td>{vehicle.status}</td>
              <td>{vehicle.warehouse.name}</td>
            </tr>
          ))}
        </tbody>
      </table>
    )
  }

  return (
    <>
      <div className='content'>
        <div className='container'>
          {/* Search Section */}
          <div className='search-section'>
            <h3>Search Vehicle</h3>
            <div className='search-fields'>
              <input
                type='text'
                id='vehicleName'
                placeholder='Vehicle Name'
                value={vehicleName}
                onChange={e => setVehicleName(e.target.value)}
              />
              <input
                type='text'
                id='vehicleType'
                placeholder='Vehicle Type'
                value={vehicleType}
                onChange={e => setVehicleType(e.target.value)}
              />
              <input
                type='text'
                id='vehicleNumber'
                placeholder='Vehicle Number'
                value={vehicleNumber}
                onChange={e => setVehicleNumber(e.target.value)}
              />
              <button className='btn btn-search' onClick={handleSearch}>
                Search
              </button>
              <button className='btn btn-reset' onClick={handleReset}>
                Reset
              </button>
            </div>
          </div>

          {/* Vehicle List Table */}
          <div className='table-section'>
            <div className='table-header'>
              <h3>Vehicle List</h3>
              <div className='btn-group'>
                <button
                  onClick={() => navigate('/vehicleForm')}
                  className='btn btn-add'
                >
                  Add Vehicle
                </button>
                <DownloadTableExcel
                  filename='vehicles_table'
                  sheet='vehicles'
                  currentTableRef={exportTableRef.current}
                >
                  <button className='btn btn-success'> Export excel </button>
                </DownloadTableExcel>
            
                <button
                  onClick={deleteAllVehicles}
                  className='btn btn-delete-all'
                >
                  Delete All
                </button>
              </div>
            </div>
            
            {/* Main display table */}
            <table ref={tableRef}>
              <thead>
                <tr>
                  <th>Vehicle Name</th>
                  <th>Vehicle Type</th>
                  <th>Vehicle Number</th>
                  <th>Vehicle Status</th>
                  <th>Warehouse Name</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {filteredVehicles.map((vehicle, index) => (
                  <tr key={index}>
                    <td>{vehicle.name}</td>
                    <td>{vehicle.type}</td>
                    <td>{vehicle.vehicleNo}</td>
                    <td
                      className={`status ${
                        vehicle.status === 'In Maintenance'
                          ? 'red'
                          : vehicle.status === 'Available'
                          ? 'green'
                          : ''
                      }`}
                    >
                      {vehicle.status}
                    </td>
                    <td>{vehicle.warehouse.name}</td>
                    <td className='action-buttons'>
                      <button
                        className='btn btn-edit'
                        onClick={() => handleEdit(vehicle.vehicleId)}
                      >
                        Edit
                      </button>
                      <button
                        className='btn btn-delete'
                        onClick={() => handleDelete(vehicle.vehicleId)}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
                {filteredVehicles.length === 0 && (
                  <tr>
                    <td colSpan='6' style={{ textAlign: 'center' }}>
                      No vehicles found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
            
            {/* Hidden table for Excel export */}
            {ExportTable()}
          </div>
        </div>
      </div>
    </>
  )
}

export default VehicleTable
