import React, { useEffect } from "react";
import "../../assets/styles/Vehicle/VehicleForm.css";
import { useNavigate } from "react-router-dom";
import { createVehicle, updateVehicle, getVehicleById } from "../../services/VehicleService";
import { errorToast } from "../../services/ToastService";
import { CONSTANTS } from "../../constants/constant";
import { getWarehouseList } from "../../services/WarehouseService";
import { useParams } from "react-router-dom";


function VehicleForm() {
    const [warehouses, setWarehouses] = React.useState([]);
    const [warehouseId, setWarehouseId] = React.useState('');
    const { id } = useParams(); // ✅ Get route param /package/edit/:id
    const isEdit = !!id; // ✅ Determine edit mode

    useEffect(() => {
        getWarehouses();

        if (isEdit) {
            loadVehicleData(id);
        }
    }, [id]);

    const getWarehouses = async () => {
        const warehouses = await getWarehouseList();
        setWarehouses(warehouses);
    };

    const loadVehicleData = async (vehicleId) => {
        try {
            const vehicleData = await getVehicleById(vehicleId);
            setWarehouseId(vehicleData.warehouseId);
            document.getElementById("vehicleName").value = vehicleData.name;
            document.getElementById("vehicleType").value = vehicleData.type;
            document.getElementById("vehicleNumber").value = vehicleData.vehicleNo;
            document.getElementById("vehicleStatus").value = vehicleData.status;
        } catch (error) {
            console.error("Failed to fetch vehicle:", error);
            errorToast("Failed to load vehicle details.");
        }
    };

    const handleSubmit = async () => {
        try {
            const vehicleData = {
                name: document.getElementById("vehicleName").value,
                type: document.getElementById("vehicleType").value,
                vehicleNo: document.getElementById("vehicleNumber").value,
                status: document.getElementById("vehicleStatus").value,
                warehouseId: warehouseId,

            };

            if (isEdit) {
                await updateVehicle(id, vehicleData);
            } else {
                await createVehicle(vehicleData);
            }
            navigate(CONSTANTS.ROUTES.VEHICLE.LIST);
        }
        catch (error) {
            console.log(error);
            errorToast(error.response?.data || "Failed to save vehicle. Please try again.");
        }
    }

    const navigate = useNavigate();
    return (
        <div className="content">
            <div className="form-container">
                <h2>Add Vehicle</h2>
                <div className="form-group">
                    <label htmlFor="vehicleName">Vehicle Name *</label>
                    <input type="text" id="vehicleName" placeholder="Enter Vehicle Name" required />
                </div>
                <div className="form-group">
                    <label htmlFor="vehicleType">Vehicle Type *</label>
                    <select id="vehicleType" required>
                        <option value="">Select Vehicle Type</option>
                        <option value="Car">Car</option>
                        <option value="Truck">Truck</option>
                        <option value="Bus">Bus</option>
                    </select>
                </div>
                <div className="form-group">
                    <label htmlFor="vehicleNumber">Vehicle Number *</label>
                    <input type="text" id="vehicleNumber" placeholder="Enter Vehicle Number" required />
                </div>
                <div className="form-group">
                    <label htmlFor="vehicleStatus">Vehicle Status *</label>
                    <select id="vehicleStatus" required>
                        <option value="">Select Vehicle Status</option>
                        <option value="Available">Available</option>
                        <option value="In Maintenance">In Maintenance</option>
                    </select>
                </div>
                <div className="form-group">
                    <label htmlFor="warehouseName">Warehouse Name *</label>
                    <select id="warehouseName" required onChange={(e) => setWarehouseId(e.target.value)}>
                        <option value="">Select Warehouse Name</option>
                        {warehouses.map((warehouse) => (
                            <option key={warehouse.warehouseId} value={warehouse.warehouseId}>{warehouse.name}</option>
                        ))}
                    </select>
                </div>
                <div className="button-group">
                    <button className="save-btn" onClick={handleSubmit}>Save</button>
                    <button onClick={() => navigate("/vehicle")} className="cancel-btn">Cancel</button>
                </div>
            </div>
        </div>
    );
}

export default VehicleForm;
