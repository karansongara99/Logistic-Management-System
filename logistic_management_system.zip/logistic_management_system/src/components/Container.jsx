import { Outlet } from "react-router-dom";
import "../assets/styles/DashBoard.css";

export const Container = () => {
    return (
        <div className="main-content">
          <Outlet />
        </div>
    );
}