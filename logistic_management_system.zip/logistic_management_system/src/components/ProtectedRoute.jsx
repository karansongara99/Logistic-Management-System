import { Navigate } from 'react-router-dom'
import { isAuthenticated } from '../utils/auth'
import { CONSTANTS } from '../constants/constant'

const ProtectedRoute = ({ children }) => {
  const isUserAuthenticated = isAuthenticated()

  if (!isUserAuthenticated) {
    return <Navigate to={CONSTANTS.ROUTES.LOGIN} replace />
  }
  return children
}

export default ProtectedRoute
