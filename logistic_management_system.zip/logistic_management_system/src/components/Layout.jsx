import { Link, Outlet, useNavigate } from "react-router-dom";
import logo from "../assets/images/logo.jpg";
import avatar from "../assets/images/person.jpg";
import "../assets/styles/DashBoard.css";
import { CONSTANTS } from "../constants/constant";

function Layout() {
  const navigate = useNavigate();

  const handleAvatarClick = () => {
    navigate(CONSTANTS.ROUTES.PROFILE);
  };

  return (
    <div className="dashboard">
      {/* Sidebar */}
      <aside className="sidebar">
        <div className="logo">
          <a href={CONSTANTS.ROUTES.HOME}>
            <img src={logo} alt="Logo" />
          </a>
        </div>
        <nav className="menu">
          <Link to={CONSTANTS.ROUTES.CUSTOMER.LIST}>Customer</Link>
          <Link to={CONSTANTS.ROUTES.SHIPMENT.LIST}>Shipment</Link>
          <Link to={CONSTANTS.ROUTES.PACKAGE.LIST}>Package</Link>
          <Link to={CONSTANTS.ROUTES.WAREHOUSE.LIST}>Warehouse</Link>
          <Link to={CONSTANTS.ROUTES.VEHICLE.LIST}>Vehicle</Link>
          <Link to={CONSTANTS.ROUTES.DRIVER.LIST}>Driver</Link>
          {/* <Link to="/route">Route</Link> */}
          <Link to={CONSTANTS.ROUTES.ASSIGNMENT.LIST}>Assignment</Link>
        </nav>
      </aside>

      {/* Main Container */}
      <div className="main">
        {/* Navbar */}
        <header className="navbar">
          <div className="nav-left">
            <h1>Dashboard</h1>
          </div>

          <div className="nav-right">
            <img
              src={avatar}
              alt="Profile"
              className="avatar"
              onClick={handleAvatarClick}
            />
          </div>
        </header>

        {/* Dynamic Content */}
        <div className="main-content">
          <Outlet />
        </div>
      </div>
    </div>
  );
}

export default Layout;
