import '../assets/styles/DashBoard.css';
import { useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { getTotalCustomerCount } from '../services/CustomerService';
import { getTotalShipmentCount, getTodayShipments, getShipCountByDate, getShipStatus, getShipmentCostOverTime } from '../services/ShipmentService';
import { getTotalPackageCount } from '../services/PackageService';
import { getTotalWareHouseCount } from '../services/WareHouseService';
import { getTotalVehicleCount } from '../services/VehicleService';
import { getTotalDriverCount } from '../services/DriverService';
import { getTotalAssignmentCount } from '../services/AssignmentService';
import { BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer } from 'recharts';
import { PieChart, Pie, Cell, Tooltip as PieTooltip, Legend } from 'recharts';
const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff8042', '#a4de6c', '#d0ed57'];


const DashBoard = () => {
  const navigate = useNavigate();

  const [customerCount, setCustomerCount] = useState(0);
  const [shipmentCount, setShipmentCount] = useState(0);
  const [packageCount, setPackageCount] = useState(0);
  const [wareHouseCount, setWareHouseCount] = useState(0);
  const [vehicleCount, setVehicleCount] = useState(0);
  const [driverCount, setDriverCount] = useState(0);
  const [assignmentCount, setAssignmentCount] = useState(0);
  const [todayShipments, setTodayShipments] = useState([]);
  const [shipCountByDate, setShipCountByDate] = useState([]);
  const [statusData, setStatusData] = useState([]);
  const [chartData, setChartData] = useState([]);


  useEffect(() => {
    const fetchCounts = async () => {
      try {
        const customer = await getTotalCustomerCount();
        const shipment = await getTotalShipmentCount();
        const pkg = await getTotalPackageCount();
        const warehouse = await getTotalWareHouseCount();
        const vehicle = await getTotalVehicleCount();
        const driver = await getTotalDriverCount();
        const assignment = await getTotalAssignmentCount();

        setCustomerCount(customer);
        setShipmentCount(shipment);
        setPackageCount(pkg);
        setWareHouseCount(warehouse);
        setVehicleCount(vehicle);
        setDriverCount(driver);
        setAssignmentCount(assignment);
      } catch (error) {
        console.error("Failed to fetch counts:", error);
      }
    };

    const fetchTodayShipments = async () => {
      try {
        const data = await getTodayShipments();
        if (Array.isArray(data)) {
          setTodayShipments(data);
        } else {
          console.warn("Today shipments response is not an array:", data);
          setTodayShipments([]);
        }
      } catch (error) {
        console.error("Failed to fetch today's shipments:", error);
        setTodayShipments([]);
      }
    };

    const fetchShipCountByDate = async () => {
      try {
        const data = await getShipCountByDate();
        if (Array.isArray(data)) {
          setShipCountByDate(data);
        } else {
          console.warn("Ship count by date response is not an array:", data);
          setShipCountByDate([]);
        }
      } catch (error) {
        console.error("Failed to fetch ship count by date:", error);
        setShipCountByDate([]);
      }
    };

    const fetchShipStatus = async () => {
      try {
        const data = await getShipStatus();
        if (Array.isArray(data)) {
          setStatusData(data);
        } else {
          console.warn("Ship status response is not an array:", data);
          setStatusData([]);
        }
      } catch (error) {
        console.error("Failed to fetch ship status:", error);
        setStatusData([]);
      }
    };

    const fetchShipCostAnalysis = async () => {
      try {
        const data = await getShipmentCostOverTime(); 
        if (Array.isArray(data)) {
          const formatted = data.map(d => ({
            date: new Date(d.date).toLocaleDateString(),
            cost: d.totalCost,
          }));
          setChartData(formatted);
        } else {
          console.warn("Ship cost analysis response is not an array:", data);
          setChartData([]);
        }
      } catch (error) {
        console.error("Failed to fetch ship cost analysis:", error);
        setChartData([]);
      }
    };
    

    fetchCounts();
    fetchTodayShipments();
    fetchShipCountByDate();
    fetchShipStatus();
    fetchShipCostAnalysis();
  }, []);

  return (
    <>
      <div className='content'>
        <h2>Welcome to Eagle Logistics Management System</h2>
        <div className='dashboard-cards'>
          <div className='card card-user' onClick={() => navigate('/customer')}>
            <h3>Customer</h3>
            <p>Manage your customers</p>
            <p className='count'>{customerCount}</p>
          </div>
          <div className='card card-shipment' onClick={() => navigate('/shipment')}>
            <h3>Shipment</h3>
            <p>Manage your shipments</p>
            <p className='count'>{shipmentCount}</p>
          </div>
          <div className='card card-package' onClick={() => navigate('/package')}>
            <h3>Package</h3>
            <p>View and manage package</p>
            <p className='count'>{packageCount}</p>
          </div>
          <div className='card card-warehouse' onClick={() => navigate('/warehouse')}>
            <h3>Warehouse</h3>
            <p>View and manage warehouse</p>
            <p className='count'>{wareHouseCount}</p>
          </div>
          <div className='card card-vehicle' onClick={() => navigate('/vehicle')}>
            <h3>Vehicle</h3>
            <p>View and manage vehicle</p>
            <p className='count'>{vehicleCount}</p>
          </div>
          <div className='card card-driver' onClick={() => navigate('/driver')}>
            <h3>Driver</h3>
            <p>View and manage driver</p>
            <p className='count'>{driverCount}</p>
          </div>
          <div className='card card-assignment' onClick={() => navigate('/assignment')}>
            <h3>Assignment</h3>
            <p>View and manage assignment</p>
            <p className='count'>{assignmentCount}</p>
          </div>
        </div>
      </div>

      <br /><br />
      <h2>Top 5 Shipment List</h2>
      <br />
      <div className='shipment-list'>
        <table>
          <thead>
            <tr>
              <th>Shipment Code</th>
              <th>Customer Name</th>
              <th>Shipment Date</th>
              <th>Shipment Status</th>
            </tr>
          </thead>
          <tbody>
            {todayShipments.length > 0 ? (
              todayShipments.map((shipment) => (
                <tr key={shipment.id}>
                  <td>{shipment.shipCode}</td>
                  <td>{shipment.customer?.fullName || 'N/A'}</td>
                  <td>{shipment.shipDate}</td>
                  <td>{shipment.status}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="4" style={{ textAlign: 'center' }}>No shipments today</td>
              </tr>
            )}
          </tbody>
        </table>
      </div><br /><br />
      <div style={{ width: '100%', height: 400 }}>
        <h2>Shipment Status Distribution</h2>
        <ResponsiveContainer>
          <PieChart>
            <Pie
              data={statusData}
              dataKey="count"
              nameKey="status"
              cx="50%"
              cy="50%"
              outerRadius={100}
              fill="#8884d8"
              label
            >
              {statusData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
      </div>
      <br /><br />
      <div style={{ width: '100%', height: 400 }}>
        <h2>Shipments Current Time</h2>
        <br />
        <ResponsiveContainer>
          <BarChart data={shipCountByDate}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="count" fill="green" />
          </BarChart>
        </ResponsiveContainer>
      </div>
      <br /><br /><br />
      <div className="shipment-cost-chart" style={{ width: '100%', height: 400, padding: 20 }}>
        <h2>Shipment Cost Over Time</h2>
        <br />
        <ResponsiveContainer>
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="cost" fill="blue" name="Total Cost" />
          </BarChart>
        </ResponsiveContainer>
      </div>
      <br /><br />
    </>
  );
};

export default DashBoard;
