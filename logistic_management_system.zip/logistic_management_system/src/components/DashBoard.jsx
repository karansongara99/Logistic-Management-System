import '../assets/styles/DashBoard.css';
import { useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { getTotalCustomerCount } from '../services/CustomerService';
import { getTotalShipmentCount, getTodayShipments } from '../services/ShipmentService';
import { getTotalPackageCount } from '../services/PackageService';
import { getTotalWareHouseCount } from '../services/WareHouseService';
import { getTotalVehicleCount } from '../services/VehicleService';
import { getTotalDriverCount } from '../services/DriverService';
import { getTotalAssignmentCount } from '../services/AssignmentService';

const DashBoard = () => {
  const navigate = useNavigate();

  const [customerCount, setCustomerCount] = useState(0);
  const [shipmentCount, setShipmentCount] = useState(0);
  const [packageCount, setPackageCount] = useState(0);
  const [wareHouseCount, setWareHouseCount] = useState(0);
  const [vehicleCount, setVehicleCount] = useState(0);
  const [driverCount, setDriverCount] = useState(0);
  const [assignmentCount, setAssignmentCount] = useState(0);
  const [todayShipments, setTodayShipments] = useState([]);

  useEffect(() => {
    const fetchCounts = async () => {
      try {
        const customer = await getTotalCustomerCount();
        const shipment = await getTotalShipmentCount();
        const pkg = await getTotalPackageCount();
        const warehouse = await getTotalWareHouseCount();
        const vehicle = await getTotalVehicleCount();
        const driver = await getTotalDriverCount();
        const assignment = await getTotalAssignmentCount();

        setCustomerCount(customer);
        setShipmentCount(shipment);
        setPackageCount(pkg);
        setWareHouseCount(warehouse);
        setVehicleCount(vehicle);
        setDriverCount(driver);
        setAssignmentCount(assignment);
      } catch (error) {
        console.error("Failed to fetch counts:", error);
      }
    };

    const fetchTodayShipments = async () => {
      try {
        const data = await getTodayShipments();
        if (Array.isArray(data)) {
          setTodayShipments(data);
        } else {
          console.warn("Today shipments response is not an array:", data);
          setTodayShipments([]);
        }
      } catch (error) {
        console.error("Failed to fetch today's shipments:", error);
        setTodayShipments([]);
      }
    };

    fetchCounts();
    fetchTodayShipments();
  }, []);

  return (
    <>
      <div className='content'>
        <h2>Welcome to Eagle Logistics Management System</h2>
        <div className='dashboard-cards'>
          <div className='card card-user' onClick={() => navigate('/customer')}>
            <h3>Customer</h3>
            <p>Manage your customers</p>
            <p className='count'>{customerCount}</p>
          </div>
          <div className='card card-shipment' onClick={() => navigate('/shipment')}>
            <h3>Shipment</h3>
            <p>Manage your shipments</p>
            <p className='count'>{shipmentCount}</p>
          </div>
          <div className='card card-package' onClick={() => navigate('/package')}>
            <h3>Package</h3>
            <p>View and manage package</p>
            <p className='count'>{packageCount}</p>
          </div>
          <div className='card card-warehouse' onClick={() => navigate('/warehouse')}>
            <h3>Warehouse</h3>
            <p>View and manage warehouse</p>
            <p className='count'>{wareHouseCount}</p>
          </div>
          <div className='card card-vehicle' onClick={() => navigate('/vehicle')}>
            <h3>Vehicle</h3>
            <p>View and manage vehicle</p>
            <p className='count'>{vehicleCount}</p>
          </div>
          <div className='card card-driver' onClick={() => navigate('/driver')}>
            <h3>Driver</h3>
            <p>View and manage driver</p>
            <p className='count'>{driverCount}</p>
          </div>
          <div className='card card-assignment' onClick={() => navigate('/assignment')}>
            <h3>Assignment</h3>
            <p>View and manage assignment</p>
            <p className='count'>{assignmentCount}</p>
          </div>
        </div>
      </div>

      <br /><br />
      <h2>Today Shipment List</h2>
      <br />
      <div className='shipment-list'>
        <table>
          <thead>
            <tr>
              <th>Shipment Code</th>
              <th>Customer Name</th>
              <th>Shipment Date</th>
              <th>Shipment Status</th>
            </tr>
          </thead>
          <tbody>
            {todayShipments.length > 0 ? (
              todayShipments.map((shipment) => (
                <tr key={shipment.id}>
                  <td>{shipment.shipCode}</td>
                  <td>{shipment.customer?.fullName || 'N/A'}</td>
                  <td>{shipment.shipDate}</td>
                  <td>{shipment.status}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="4" style={{ textAlign: 'center' }}>No shipments today</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </>
  );
};

export default DashBoard;
