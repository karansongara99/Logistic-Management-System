import { CONSTANTS } from "../constants/constant";
import { getAPICall, postAPICall, putAPICall, deleteAPICall } from "./APICallSevice";

export const getShipmentList = async () => {
    try {
        const response = await getAPICall(CONSTANTS.API_ENDPOINTS.SHIPMENT.LIST);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to fetch shipment list. Please try again.");
    }
};

export const getByID = async (id) => {
    try {
        const response = await getAPICall(`${CONSTANTS.API_ENDPOINTS.SHIPMENT.GET_BY_ID}/${id}`);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to fetch shipment by id. Please try again.");
    }
};

export const getTotalShipmentCount = async () => {
    try {
        const response = await getAPICall(CONSTANTS.API_ENDPOINTS.SHIPMENT.TOTAL_COUNT);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to fetch shipment count. Please try again.");
    }
};

export const updateShipment = async (id, shipment) => {
    try {
        const response = await putAPICall(`${CONSTANTS.API_ENDPOINTS.SHIPMENT.UPDATE}/${id}`, shipment);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to update shipment. Please try again.");
    }
};

export const getShipmentById = async (id) => {
    try {
        const response = await getAPICall(`${CONSTANTS.API_ENDPOINTS.SHIPMENT.GET_BY_ID}/${id}`);
        if (response.status === 200) {
            return response.data;
        } else {
            throw new Error("Failed to fetch shipment");
        }
    }
    catch (error) {
        throw new Error(error.response?.data?.message || "Failed to fetch shipment by id. Please try again.");
    }
};


export const createShipment = async (shipment) => {
    try {
        const response = await postAPICall(`${CONSTANTS.API_ENDPOINTS.SHIPMENT.CREATE}`, shipment);
        if (response.status === 201) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to create shipment. Please try again.");
    }
};

export const deleteShipment = async (id) => {
    try {
        const response = await deleteAPICall(`${CONSTANTS.API_ENDPOINTS.SHIPMENT.DELETE}/${id}`);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to delete shipment. Please try again.");
    }
};

export const getTodayShipments = async () => {
    try {
        const response = await getAPICall(CONSTANTS.API_ENDPOINTS.SHIPMENT.TODAY_SHIPMENTS);
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data || "Failed to fetch today's shipments. Please try again.");
    }
};

export const deleteAllShipment = async () => {
    try {
        const response = await deleteAPICall(`${CONSTANTS.API_ENDPOINTS.SHIPMENT.DELETEALL}`);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to delete all shipment. Please try again.");
    }
}

export const getShipCountByDate = async () => {
    try {
        const response = await getAPICall(CONSTANTS.API_ENDPOINTS.SHIPMENT.ShipCountByDate);
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data || "Failed to fetch shipment count by date. Please try again.");
    }
}

export const getShipStatus = async () => {
    try {
        const response = await getAPICall(CONSTANTS.API_ENDPOINTS.SHIPMENT.ShipStatus);
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data || "Failed to fetch shipment status. Please try again.");
    }
}

export const getShipmentCostOverTime = async () => {
    try {
        const response = await getAPICall(CONSTANTS.API_ENDPOINTS.SHIPMENT.ShipCostAnalysis);
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data || "Failed to fetch shipment cost analysis. Please try again.");
    }
}
