import { CONSTANTS } from "../constants/constant";
import { getAPICall, postAPICall, putAPICall, deleteAPICall } from "./APICallSevice";

export const getAssignmentList = async () => {
    try {
        const response = await getAPICall(CONSTANTS.API_ENDPOINTS.ASSIGNMENT.LIST);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to fetch assignment list. Please try again.");
    }
};

export const getAssignmentById = async (id) => {
    try {
        const response = await getAPICall(`${CONSTANTS.API_ENDPOINTS.ASSIGNMENT.GET_BY_ID}/${id}`);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to fetch assignment by id. Please try again.");
    }
};

export const createAssignment = async (assignment) => {
    try {
        const response = await postAPICall(`${CONSTANTS.API_ENDPOINTS.ASSIGNMENT.CREATE}`, assignment);
        if (response.status === 201) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to create assignment. Please try again.");
    }
};

export const updateAssignment = async (id, assignment) => {
    try {
        const response = await putAPICall(`${CONSTANTS.API_ENDPOINTS.ASSIGNMENT.UPDATE}/${id}`, assignment);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to update assignment. Please try again.");
    }
};

export const deleteAssignment = async (id) => {
    try {
        const response = await deleteAPICall(`${CONSTANTS.API_ENDPOINTS.ASSIGNMENT.DELETE}/${id}`);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to delete assignment. Please try again.");
    }
};

export const getTotalAssignmentCount = async () => {
    try {
        const response = await getAPICall(CONSTANTS.API_ENDPOINTS.ASSIGNMENT.TOTAL_COUNT);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to fetch assignment count. Please try again.");
    }
};

export const deleteAllAssignment = async () => {
    try {
        const response = await deleteAPICall(`${CONSTANTS.API_ENDPOINTS.ASSIGNMENT.DELETEALL}`);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to delete all assignment. Please try again.");
    }
}

