import { CONSTANTS } from "../constants/constant";
import { getAPICall, postAPICall, putAPICall, deleteAPICall } from "./APICallSevice";

export const getDriverList = async () => {
    try {
        const response = await getAPICall(CONSTANTS.API_ENDPOINTS.DRIVER.LIST);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to fetch driver list. Please try again.");
    }
};

export const getDriverById = async (id) => {
    try {
        const response = await getAPICall(`${CONSTANTS.API_ENDPOINTS.DRIVER.GET_BY_ID}/${id}`);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to fetch driver by id. Please try again.");
    }
};

export const createDriver = async (driver) => {
    try {
        const response = await postAPICall(`${CONSTANTS.API_ENDPOINTS.DRIVER.CREATE}`, driver);
        if (response.status === 201) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to create driver. Please try again.");
    }
};

export const updateDriver = async (id, driver) => {
    try {
        const response = await putAPICall(`${CONSTANTS.API_ENDPOINTS.DRIVER.UPDATE}/${id}`, driver);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to update driver. Please try again.");
    }
};

export const deleteDriver = async (id) => {
    try {
        const response = await deleteAPICall(`${CONSTANTS.API_ENDPOINTS.DRIVER.DELETE}/${id}`);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to delete driver. Please try again.");
    }
};

export const getTotalDriverCount = async () => {
    try {
        const response = await getAPICall(CONSTANTS.API_ENDPOINTS.DRIVER.TOTAL_COUNT);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to fetch driver count. Please try again.");
    }
};

export const deleteAllDriver = async () => {
    try {
        const response = await deleteAPICall(`${CONSTANTS.API_ENDPOINTS.DRIVER.DELETEALL}`);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to delete all driver. Please try again.");
    }
}
