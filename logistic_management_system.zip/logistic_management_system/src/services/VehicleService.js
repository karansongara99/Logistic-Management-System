import { CONSTANTS } from "../constants/constant";
import { getAPICall, postAPICall, putAPICall, deleteAPICall } from "./APICallSevice";

export const getVehicleList = async () => {
    try {
        const response = await getAPICall(CONSTANTS.API_ENDPOINTS.VEHICLE.LIST);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to fetch vehicle list. Please try again.");
    }
};
    
export const getVehicleById = async (id) => {
    try {
        const response = await getAPICall(`${CONSTANTS.API_ENDPOINTS.VEHICLE.GET_BY_ID}/${id}`);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to fetch vehicle by id. Please try again.");
    }
};

export const createVehicle = async (vehicle) => {
    try {
        const response = await postAPICall(`${CONSTANTS.API_ENDPOINTS.VEHICLE.CREATE}`, vehicle);
        if (response.status === 201) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to create vehicle. Please try again.");
    }
};

export const updateVehicle = async (id, vehicle) => {
    try {
        const response = await putAPICall(`${CONSTANTS.API_ENDPOINTS.VEHICLE.UPDATE}/${id}`, vehicle);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to update vehicle. Please try again.");
    }
};

export const deleteVehicle = async (id) => {
    try {
        const response = await deleteAPICall(`${CONSTANTS.API_ENDPOINTS.VEHICLE.DELETE}/${id}`);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to delete vehicle. Please try again.");
    }
};

export const getTotalVehicleCount = async () => {
    try {
        const response = await getAPICall(CONSTANTS.API_ENDPOINTS.VEHICLE.TOTAL_COUNT);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to fetch vehicle count. Please try again.");
    }
};

export const deleteAllVehicle = async () => {
    try {
        const response = await deleteAPICall(`${CONSTANTS.API_ENDPOINTS.VEHICLE.DELETEALL}`);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to delete all vehicle. Please try again.");
    }
}
