import { CONSTANTS } from "../constants/constant";
import { getAPICall } from "./APICallSevice";

export const getProfileDetails = async () => {
    try {
        const response = await getAPICall(`${CONSTANTS.API_ENDPOINTS.ADMIN.PROFILE}`);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to get profile details. Please try again.");
    }
};
