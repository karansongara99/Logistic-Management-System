import { CONSTANTS } from "../constants/constant";
import { AdminAuthModelClass } from "../models/AdminAuthModel";
import { AdminRegisterModelClass } from "../models/AdminRegisterModel";
import { removeToken, setUserInfo } from "../utils/auth";
import { postAPICall } from "./APICallSevice";
import { successToast } from "./ToastService";

export const AdminLogin = async (email, password) => {
    try {
        const adminModelObject = new AdminAuthModelClass(email, password);
        const adminModel = adminModelObject.toObject();
        const response = await postAPICall(CONSTANTS.API_ENDPOINTS.AUTH_API.LOGIN, adminModel);
        if (response.status === 200) {
            const userDetails = response.data;
            setUserInfo(userDetails);
            successToast("Login successful!");
            return userDetails;
        }
    }
    catch {
        throw new Error("Invalid email or password or user not found.");
    }
};

export const AdminRegister = async (name, emailId, password) => {
    try {
        const adminModelObject = new AdminRegisterModelClass(name,emailId,password);
        const adminModel = adminModelObject.toObject();
        const response = await postAPICall(CONSTANTS.API_ENDPOINTS.AUTH_API.REGISTER, adminModel);
        if (response.status === 201) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Registration failed. Please try again.");
    }
};

export const AdminLogout = () => {
    try {
        successToast("You have been logged out successfully.");
        removeToken();
        window.location.href = CONSTANTS.ROUTES.LOGIN;
    } catch (error) {
        console.error("Logout failed:", error);
    }
}