import axios from 'axios'
import { getJWTToken, removeToken } from '../utils/auth'
import { CONSTANTS } from '../constants/constant'
import { errorToast } from './ToastService'

const axiosInstance = axios.create({
  baseURL: CONSTANTS.API_ENDPOINTS.API_BASE_URL,
  timeout: 10000 // Set a timeout for requests
})

axiosInstance.interceptors.request.use(
  config => {
    const token = getJWTToken()
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`
    }
    return config
  },
  error => {
    return Promise.reject(error)
  }
)

axiosInstance.interceptors.response.use(
  response => response,
  error => {
    if (error.response && error.response.status === 401) {
      errorToast('Session expired. Please log in again.')
      removeToken() // remove token from storage

      // 🔁 Redirect to login
      window.location.href = CONSTANTS.ROUTES.LOGIN // force reload and redirect
    }
    return Promise.reject(error)
  }
)

export const postAPICall = async (url, data) => {
  return await axiosInstance.post(url, data)
}

export const getAPICall = async url => {
  return await axiosInstance.get(url)
}

export const putAPICall = async (url, data) => {
  return await axiosInstance.put(url, data)
}

export const deleteAPICall = async url => {
  return await axiosInstance.delete(url)
}

export const patchAPICall = async (url, data) => {
  return await axiosInstance.patch(url, data)
}