import { CONSTANTS } from "../constants/constant";
import { getAPICall, postAPICall, putAPICall, deleteAPICall } from "./APICallSevice";

export const getWarehouseList = async () => {
    try {
        const response = await getAPICall(CONSTANTS.API_ENDPOINTS.WAREHOUSE.LIST);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to fetch warehouse list. Please try again.");
    }
};

export const getWarehouseById = async (id) => {
    try {
        const response = await getAPICall(`${CONSTANTS.API_ENDPOINTS.WAREHOUSE.GET_BY_ID}/${id}`);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to fetch warehouse by id. Please try again.");
    }
};

export const createWarehouse = async (wareHouse) => {
    try {
        const response = await postAPICall(`${CONSTANTS.API_ENDPOINTS.WAREHOUSE.CREATE}`, wareHouse);
        if (response.status === 201) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to create warehouse. Please try again.");
    }
};

export const updateWareHouse = async (id, wareHouse) => {
    try {
        const response = await putAPICall(`${CONSTANTS.API_ENDPOINTS.WAREHOUSE.UPDATE}/${id}`, wareHouse);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to update warehouse. Please try again.");
    }
};

export const deleteWareHouse = async (id) => {
    try {
        const response = await deleteAPICall(`${CONSTANTS.API_ENDPOINTS.WAREHOUSE.DELETE}/${id}`);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to delete warehouse. Please try again.");
    }
};

export const getTotalWareHouseCount = async () => {
    try {
        const response = await getAPICall(CONSTANTS.API_ENDPOINTS.WAREHOUSE.TOTAL_COUNT);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to fetch warehouse count. Please try again.");
    }
};

export const deleteAllWareHouse = async () => {
    try {
        const response = await deleteAPICall(`${CONSTANTS.API_ENDPOINTS.WAREHOUSE.DELETEALL}`);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to delete all warehouse. Please try again.");
    }
}


