import { CONSTANTS } from "../constants/constant";
import { getAPICall, postAPICall, putAPICall, patchAPICall, deleteAPICall } from "./APICallSevice";

export const getCustomerList = async () => {
    try {
        const response = await getAPICall(CONSTANTS.API_ENDPOINTS.CUSTOMER.LIST);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to fetch customer list. Please try again.");
    }
};

export const updateCustomer = async (id, customer) => {
    try {
        const response = await putAPICall(`${CONSTANTS.API_ENDPOINTS.CUSTOMER.UPDATE}/${id}`, customer);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to update customer. Please try again.");
    }
};

export const getCustomerById = async (id) => {
    try {
        const response = await getAPICall(`${CONSTANTS.API_ENDPOINTS.CUSTOMER.GET_BY_ID}/${id}`);
        if (response.status === 200) {
            return response.data;
        } else {
            throw new Error("Failed to fetch customer");
        }
    }
    catch (error) {
        throw new Error(error.response?.data?.message || "Failed to fetch customer by id. Please try again.");
    }
};


export const createCustomer = async (customer) => {
    try {
        const response = await postAPICall(`${CONSTANTS.API_ENDPOINTS.CUSTOMER.CREATE}`, customer);
        if (response.status === 201) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to create customer. Please try again.");
    }
};




export const customerSoftDelete = async (id) => {
    try {
        const response = await patchAPICall(`${CONSTANTS.API_ENDPOINTS.CUSTOMER.SOFT_DELETE}/${id}`);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to delete customer. Please try again.");
    }
};

export const customerHardDelete = async (id) => {
    try {
        const response = await deleteAPICall(`${CONSTANTS.API_ENDPOINTS.CUSTOMER.HARD_DELETE}/${id}`);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to hard delete customer. Please try again.");
    }
}

export const getTotalCustomerCount = async () => 
{ try {
        const response = await getAPICall(CONSTANTS.API_ENDPOINTS.CUSTOMER.TOTAL_COUNT);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to fetch customer count. Please try again.");
    }
}

export const getCustomerPagination = async (page, pageSize) => 
{ try {
        const response = await getAPICall(`${CONSTANTS.API_ENDPOINTS.CUSTOMER.PAGINATION}/${page}/${pageSize}`);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to fetch customer pagination. Please try again.");
    }
}

export const searchCustomers = async (fullName = '', contactNo = '', page = 1, pageSize = 5) => {
  try {
    const params = new URLSearchParams({
      fullName: fullName || '',
      contactNo: contactNo || '',
      page: page.toString(),
      pageSize: pageSize.toString()
    });
    const response = await getAPICall(`${CONSTANTS.API_ENDPOINTS.CUSTOMER.SEARCHING}?${params.toString()}`)
    if (response.status === 200) {
        return response;
    }
  } catch (error) {
    throw new Error(error.response?.data || "Failed to fetch customer search. Please try again.");
  }
}

export const deleteAllCustomer = async () => {
    try {
        const response = await deleteAPICall(`${CONSTANTS.API_ENDPOINTS.CUSTOMER.DELETEALL}`);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to delete all customer. Please try again.");
    }
}
