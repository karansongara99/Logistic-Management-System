import { CONSTANTS } from "../constants/constant";
import { getAPICall, postAPICall, putAPICall, deleteAPICall } from "./APICallSevice";

export const getPackageList = async () => {
    try {
        const response = await getAPICall(CONSTANTS.API_ENDPOINTS.PACKAGE.LIST);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to fetch package list. Please try again.");
    }
};

export const getTotalPackageCount = async () => {
    try {
        const response = await getAPICall(CONSTANTS.API_ENDPOINTS.PACKAGE.TOTAL_COUNT);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to fetch package count. Please try again.");
    }
};

export const getPackageById = async (id) => {
    try {
        const response = await getAPICall(`${CONSTANTS.API_ENDPOINTS.PACKAGE.GET_BY_ID}/${id}`);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to fetch package by id. Please try again.");
    }
};

export const createPackage = async (packageData) => {
    try {
        const response = await postAPICall(`${CONSTANTS.API_ENDPOINTS.PACKAGE.CREATE}`, packageData);
        if (response.status === 201) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to create package. Please try again.");
    }
};

export const updatePackage = async (id, packageData) => {
    try {
        const response = await putAPICall(`${CONSTANTS.API_ENDPOINTS.PACKAGE.UPDATE}/${id}`, packageData);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to update package. Please try again.");
    }
};

export const deletePackage = async (id) => {
    try {
        const response = await deleteAPICall(`${CONSTANTS.API_ENDPOINTS.PACKAGE.DELETE}/${id}`);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to delete package. Please try again.");
    }
};

export const deleteAllPackage = async () => {
    try {
        const response = await deleteAPICall(`${CONSTANTS.API_ENDPOINTS.PACKAGE.DELETEALL}`);
        if (response.status === 200) {
            return response.data;
        }
    }
    catch (error) {
        throw new Error(error.response?.data || "Failed to delete all package. Please try again.");
    }
};
